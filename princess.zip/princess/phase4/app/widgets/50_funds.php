<?php
/** @var array $user */
$uid  = (int) $user['user_id'];
$role = $user['role'];
$mine = $role === 'Staff';
$scope = $mine ? ' AND fr.user_id = ?' : '';
$sp    = $mine ? [$uid] : [];

$awaitingPay = DB::row("SELECT COUNT(*) AS n, COALESCE(SUM(amount_requested), 0) AS amt FROM financial_requests fr WHERE fr.status = 'Approved'$scope", $sp);
$paid        = DB::row("SELECT COUNT(*) AS n, COALESCE(SUM(pay.paid_amount), 0) AS amt FROM payments pay JOIN financial_requests fr ON fr.request_id = pay.request_id WHERE 1 = 1$scope", $sp);
$outstanding = DB::all(
    "SELECT fr.request_id, fr.request_code, fr.amount_requested, pay.payment_date, u.full_name
       FROM financial_requests fr JOIN payments pay ON pay.request_id = fr.request_id JOIN users u ON u.user_id = fr.user_id
      WHERE fr.status = 'Paid'$scope ORDER BY pay.payment_date",
    $sp
);
$overdue = array_filter($outstanding, static fn (array $o): bool => Accountabilities::dueDate($o['payment_date']) < date('Y-m-d'));
$returned = $mine ? DB::val("SELECT COUNT(*) FROM accountabilities WHERE user_id = ? AND status = 'Revision_Requested'", [$uid]) : 0;
?>
<div class="stats">
    <?php if (in_array($role, ['Finance', 'Admin', 'Director'], true)): ?>
        <div class="stat <?= (int) $awaitingPay['n'] > 0 ? 'warn' : 'ok' ?>"><div class="stat-label">Awaiting payment</div><div class="stat-value"><?= (int) $awaitingPay['n'] ?></div><div class="stat-note"><?= e(money($awaitingPay['amt'])) ?><?= $role === 'Finance' ? ' · <a href="' . e(url('modules/payments/index.php')) . '">Pay now</a>' : '' ?></div></div>
    <?php endif; ?>
    <div class="stat"><div class="stat-label"><?= $mine ? 'Funds received' : 'Funds disbursed' ?></div><div class="stat-value"><?= e(money($paid['amt'])) ?></div><div class="stat-note"><?= (int) $paid['n'] ?> payment(s)</div></div>
    <div class="stat <?= $outstanding ? 'warn' : 'ok' ?>"><div class="stat-label"><?= $mine ? 'To account for' : 'Outstanding accountabilities' ?></div><div class="stat-value"><?= count($outstanding) ?></div><div class="stat-note"><?= e(money(array_sum(array_column($outstanding, 'amount_requested')))) ?></div></div>
    <div class="stat <?= $overdue ? 'danger' : 'ok' ?>"><div class="stat-label">Overdue accountabilities</div><div class="stat-value"><?= count($overdue) ?></div><div class="stat-note"><?= $mine && $returned ? (int) $returned . ' returned for correction' : 'Past the ' . (int) Settings::get('accountability_due_days', '14') . '-day limit' ?></div></div>
</div>
<?php if ($mine && $outstanding): ?>
<div class="alert alert-info">
    You have <?= count($outstanding) ?> request(s) with funds that still need to be accounted for.
    <a href="<?= e(url('modules/accountabilities/index.php')) ?>">Go to accountabilities</a>
</div>
<?php endif; ?>
