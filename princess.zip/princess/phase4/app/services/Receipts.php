<?php
declare(strict_types=1);

/**
 * Receipt file storage.
 *
 * Files live in storage/receipts (blocked from the web by .htaccess) under random names and are only
 * ever served through modules/accountabilities/receipt.php after an access check.
 */
final class Receipts
{
    public const MAX_BYTES = 5 * 1024 * 1024;
    private const TYPES = ['application/pdf' => 'pdf', 'image/jpeg' => 'jpg', 'image/png' => 'png'];

    public static function directory(): string
    {
        return APP_ROOT . '/storage/receipts';
    }

    /** Absolute path for a stored file name (any directory part is stripped). */
    public static function absolute(string $stored): string
    {
        return self::directory() . '/' . basename($stored);
    }

    /**
     * Validate and store an uploaded file.
     *
     * @param array $file one entry of $_FILES, already split per item
     * @return array{path: string, name: string, mime: string}
     */
    public static function store(array $file, string $label): array
    {
        $error = (int) $file['error'];
        if ($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE || (int) $file['size'] > self::MAX_BYTES) {
            throw new DomainException("$label: the receipt is larger than 5 MB.");
        }
        if ($error !== UPLOAD_ERR_OK) {
            throw new DomainException("$label: the receipt could not be uploaded. Please try again.");
        }

        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']) ?: '';
        if (!isset(self::TYPES[$mime])) {
            throw new DomainException("$label: only PDF, JPG or PNG receipts are accepted.");
        }

        if (!is_dir(self::directory()) && !mkdir(self::directory(), 0755, true) && !is_dir(self::directory())) {
            throw new RuntimeException('The receipt storage folder is not available.');
        }
        $stored = bin2hex(random_bytes(16)) . '.' . self::TYPES[$mime];
        if (!move_uploaded_file($file['tmp_name'], self::absolute($stored))) {
            throw new RuntimeException('Unable to store the uploaded receipt.');
        }

        $name = preg_replace('/[^\w.\- ()]/u', '_', basename((string) $file['name'])) ?: 'receipt';
        return ['path' => $stored, 'name' => mb_substr($name, 0, 150), 'mime' => $mime];
    }

    public static function delete(?string $stored): void
    {
        if ($stored) {
            $path = self::absolute($stored);
            if (is_file($path)) {
                @unlink($path);
            }
        }
    }
}
