<?php
declare(strict_types=1);

/**
 * Recording the disbursement of approved funds.
 *
 * Only Finance can record a payment, only for a fully approved request, and only once.
 */
final class Payments
{
    public const METHODS = ['Bank Transfer', 'Mobile Money', 'Cash', 'Cheque'];

    public static function awaitingCount(): int
    {
        return (int) DB::val("SELECT COUNT(*) FROM financial_requests WHERE status = 'Approved'");
    }

    public static function forRequest(int $requestId): ?array
    {
        return DB::row(
            'SELECT pay.*, u.full_name AS recorder FROM payments pay JOIN users u ON u.user_id = pay.recorded_by WHERE pay.request_id = ?',
            [$requestId]
        );
    }

    public static function record(int $requestId, array $d): void
    {
        $user = Auth::user();
        if ($user['role'] !== 'Finance') {
            throw new DomainException('Only Finance can record payments.');
        }
        if (!in_array($d['payment_method'], self::METHODS, true)) {
            throw new DomainException('Choose a valid payment method.');
        }
        if ($d['payment_date'] > date('Y-m-d')) {
            throw new DomainException('The payment date cannot be in the future.');
        }
        if ($d['payment_method'] !== 'Cash' && trim((string) $d['payment_reference']) === '') {
            throw new DomainException('A payment reference (transaction ID / cheque number) is required for this method.');
        }

        DB::transaction(function () use ($requestId, $d, $user): void {
            $req = DB::row('SELECT * FROM financial_requests WHERE request_id = ? FOR UPDATE', [$requestId]);
            if (!$req || $req['status'] !== 'Approved') {
                throw new DomainException('Only fully approved requests that have not been paid can be paid.');
            }
            DB::insert(
                'INSERT INTO payments (request_id, payment_date, payment_method, payment_reference, paid_amount, notes, recorded_by) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [$requestId, $d['payment_date'], $d['payment_method'], trim((string) $d['payment_reference']) ?: null, $req['amount_requested'], trim((string) $d['notes']) ?: null, $user['user_id']]
            );
            DB::exec("UPDATE financial_requests SET status = 'Paid' WHERE request_id = ?", [$requestId]);
            Audit::log('Payment recorded', 'Payments', $requestId, money($req['amount_requested']) . " paid for {$req['request_code']} via {$d['payment_method']}");

            $due = Accountabilities::dueDate($d['payment_date']);
            Notify::user(
                (int) $req['user_id'],
                'Funds released',
                money($req['amount_requested']) . " for {$req['request_code']} has been paid. Please submit your accountability with receipts by " . fdate($due) . '.',
                'modules/requests/view.php?id=' . $requestId
            );
        });
    }
}

/** Sidebar counter for the Payments menu item: approved requests waiting to be paid (Finance only). */
function nav_badge_payments(): int
{
    return Auth::role() === 'Finance' ? Payments::awaitingCount() : 0;
}
