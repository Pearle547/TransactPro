<?php
declare(strict_types=1);

/**
 * Accountability for funds received.
 *
 * After a request is paid the requester records how the money was spent — one expenditure item per
 * receipt — and returns any unspent balance. The accountability can only be submitted when:
 *
 *   • every item has a date, vendor, description, amount and a receipt file, and
 *   • total spent (the sum of the items) + balance returned = the amount received.
 *
 * Saving always succeeds first (so nothing the user typed or uploaded is lost); submission is then
 * validated against what was saved.
 */
final class Accountabilities
{
    public static function dueDate(?string $paymentDate): ?string
    {
        if (!$paymentDate) {
            return null;
        }
        return date('Y-m-d', strtotime($paymentDate . ' +' . (int) Settings::get('accountability_due_days', '14') . ' days'));
    }

    public static function forRequest(int $requestId): ?array
    {
        return DB::row('SELECT * FROM accountabilities WHERE request_id = ?', [$requestId]);
    }

    /** @return array<int, array<string, mixed>> */
    public static function items(int $accountabilityId): array
    {
        return DB::all('SELECT * FROM accountability_items WHERE accountability_id = ? ORDER BY item_id', [$accountabilityId]);
    }

    public static function canView(array $acc, array $user): bool
    {
        return $user['role'] !== 'Staff' || (int) $acc['user_id'] === (int) $user['user_id'];
    }

    public static function isEditable(array $acc, array $user): bool
    {
        return (int) $acc['user_id'] === (int) $user['user_id'] && in_array($acc['status'], ['Draft', 'Revision_Requested'], true);
    }

    /**
     * Everything that still prevents submission.
     *
     * @return string[]
     */
    public static function problems(array $acc, array $items): array
    {
        $problems = [];
        if (!$items) {
            return ['Add at least one expenditure item with its receipt.'];
        }
        $total = 0.0;
        foreach ($items as $i => $item) {
            $n = $i + 1;
            $total += (float) $item['amount'];
            if (!$item['item_date']) {
                $problems[] = "Item $n: the date is missing.";
            } elseif ($item['item_date'] > date('Y-m-d')) {
                $problems[] = "Item $n: the date is in the future.";
            }
            if (trim((string) $item['vendor']) === '') {
                $problems[] = "Item $n: the vendor / supplier is missing.";
            }
            if (trim((string) $item['description']) === '') {
                $problems[] = "Item $n: the description is missing.";
            }
            if ((float) $item['amount'] <= 0) {
                $problems[] = "Item $n: the amount must be greater than zero.";
            }
            if (!$item['receipt_path']) {
                $problems[] = "Item $n: no receipt has been attached.";
            }
        }
        $difference = (float) $acc['amount_received'] - $total - (float) $acc['balance_returned'];
        if (abs($difference) > 0.01) {
            $problems[] = 'Total spent (' . money($total) . ') plus balance returned (' . money($acc['balance_returned'])
                . ') must equal the ' . money($acc['amount_received']) . ' you received — difference ' . money(abs($difference)) . '.';
        }
        if ((float) $acc['balance_returned'] > 0 && trim((string) $acc['return_reference']) === '') {
            $problems[] = 'Say how the unspent balance was returned (reference / receipt number).';
        }
        return $problems;
    }

    /**
     * Save the accountability form (drafts and returned accountabilities). Returns the accountability id.
     *
     * @param array $post  the posted form fields
     * @param array $files $_FILES
     */
    public static function save(int $requestId, array $post, array $files): int
    {
        $user     = Auth::user();
        $created  = [];   // files stored by this call; removed again if anything fails
        $obsolete = [];   // replaced / removed files; removed only after the database commit

        try {
            $accId = DB::transaction(function () use ($requestId, $post, $files, $user, &$created, &$obsolete): int {
                $req = DB::row(
                    'SELECT fr.*, pay.paid_amount FROM financial_requests fr JOIN payments pay ON pay.request_id = fr.request_id
                      WHERE fr.request_id = ? FOR UPDATE',
                    [$requestId]
                );
                if (!$req || !RequestWorkflow::isOwner($req, $user) || $req['status'] !== 'Paid') {
                    throw new DomainException('An accountability can only be prepared by the requester, for a request that has been paid and not yet submitted.');
                }
                $acc = DB::row('SELECT * FROM accountabilities WHERE request_id = ? FOR UPDATE', [$requestId]);
                if ($acc && !in_array($acc['status'], ['Draft', 'Revision_Requested'], true)) {
                    throw new DomainException('This accountability has already been submitted.');
                }
                if (!$acc) {
                    $accId    = DB::insert('INSERT INTO accountabilities (request_id, user_id, amount_received) VALUES (?, ?, ?)', [$requestId, $user['user_id'], $req['paid_amount']]);
                    $existing = [];
                } else {
                    $accId    = (int) $acc['accountability_id'];
                    $existing = array_column(self::items($accId), null, 'item_id');
                }

                $ids  = $post['item_id'] ?? [];
                $keep = [];
                foreach (array_keys($ids) as $i) {
                    $label  = 'Item ' . ($i + 1);
                    $itemId = (int) ($ids[$i] ?? 0);
                    $date   = trim((string) ($post['item_date'][$i] ?? ''));
                    $vendor = trim((string) ($post['vendor'][$i] ?? ''));
                    $number = trim((string) ($post['receipt_number'][$i] ?? ''));
                    $desc   = trim((string) ($post['description'][$i] ?? ''));
                    $amount = str_replace(',', '', trim((string) ($post['amount'][$i] ?? '')));
                    $upload = isset($files['receipt']['error'][$i]) && (int) $files['receipt']['error'][$i] !== UPLOAD_ERR_NO_FILE
                        ? ['name' => $files['receipt']['name'][$i], 'tmp_name' => $files['receipt']['tmp_name'][$i], 'error' => $files['receipt']['error'][$i], 'size' => $files['receipt']['size'][$i]]
                        : null;

                    if (!isset($existing[$itemId])) {
                        $itemId = 0;   // unknown id: treat as a new item
                    }
                    if ($itemId === 0 && $date === '' && $vendor === '' && $number === '' && $desc === '' && $amount === '' && $upload === null) {
                        continue;      // completely blank row
                    }
                    if ($date !== '' && !Validator::isDate($date)) {
                        throw new DomainException("$label: the date is not valid.");
                    }
                    if ($amount !== '' && (!is_numeric($amount) || (float) $amount < 0 || (float) $amount > 9999999999999)) {
                        throw new DomainException("$label: the amount must be a positive number.");
                    }
                    $amount = $amount === '' ? '0' : $amount;

                    $file = null;
                    if ($upload !== null) {
                        $file      = Receipts::store($upload, $label);
                        $created[] = $file['path'];
                    }

                    if ($itemId > 0) {
                        $sql    = 'UPDATE accountability_items SET item_date = ?, vendor = ?, receipt_number = ?, description = ?, amount = ?';
                        $params = [$date ?: null, $vendor, $number ?: null, $desc, $amount];
                        if ($file) {
                            $sql      .= ', receipt_path = ?, receipt_name = ?, receipt_mime = ?';
                            $params    = array_merge($params, [$file['path'], $file['name'], $file['mime']]);
                            $obsolete[] = $existing[$itemId]['receipt_path'];
                        }
                        DB::exec($sql . ' WHERE item_id = ? AND accountability_id = ?', array_merge($params, [$itemId, $accId]));
                        $keep[] = $itemId;
                    } else {
                        $keep[] = DB::insert(
                            'INSERT INTO accountability_items (accountability_id, item_date, vendor, receipt_number, description, amount, receipt_path, receipt_name, receipt_mime)
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                            [$accId, $date ?: null, $vendor, $number ?: null, $desc, $amount, $file['path'] ?? null, $file['name'] ?? null, $file['mime'] ?? null]
                        );
                    }
                }

                foreach ($existing as $itemId => $item) {       // rows removed from the form
                    if (!in_array((int) $itemId, $keep, true)) {
                        DB::exec('DELETE FROM accountability_items WHERE item_id = ?', [$itemId]);
                        $obsolete[] = $item['receipt_path'];
                    }
                }

                $returned = str_replace(',', '', trim((string) ($post['balance_returned'] ?? '')));
                if ($returned !== '' && (!is_numeric($returned) || (float) $returned < 0)) {
                    throw new DomainException('The balance returned must be zero or a positive number.');
                }
                $total = (float) DB::val('SELECT COALESCE(SUM(amount), 0) FROM accountability_items WHERE accountability_id = ?', [$accId]);
                DB::exec(
                    'UPDATE accountabilities SET total_spent = ?, balance_returned = ?, return_reference = ?, explanation = ? WHERE accountability_id = ?',
                    [$total, $returned === '' ? 0 : $returned, trim((string) ($post['return_reference'] ?? '')) ?: null, trim((string) ($post['explanation'] ?? '')) ?: null, $accId]
                );
                Audit::log('Accountability saved', 'Accountability', $accId, "Saved accountability for {$req['request_code']} — " . count($keep) . ' item(s), ' . money($total) . ' spent');
                return $accId;
            });
        } catch (Throwable $e) {
            foreach ($created as $stored) {
                Receipts::delete($stored);
            }
            throw $e;
        }

        foreach ($obsolete as $stored) {
            Receipts::delete($stored);
        }
        return $accId;
    }

    public static function submit(int $requestId): void
    {
        $user = Auth::user();
        DB::transaction(function () use ($requestId, $user): void {
            $req = DB::row('SELECT * FROM financial_requests WHERE request_id = ? FOR UPDATE', [$requestId]);
            $acc = DB::row('SELECT * FROM accountabilities WHERE request_id = ? FOR UPDATE', [$requestId]);
            if (!$req || !$acc || !self::isEditable($acc, $user) || $req['status'] !== 'Paid') {
                throw new DomainException('This accountability cannot be submitted.');
            }
            $items    = self::items((int) $acc['accountability_id']);
            $problems = self::problems($acc, $items);
            if ($problems) {
                throw new DomainException(implode(' ', array_slice($problems, 0, 3)) . (count($problems) > 3 ? ' (and ' . (count($problems) - 3) . ' more)' : ''));
            }

            DB::exec("UPDATE accountabilities SET status = 'Submitted', submitted_at = NOW(), reviewed_at = NULL, reviewed_by = NULL WHERE accountability_id = ?", [$acc['accountability_id']]);
            DB::exec("UPDATE financial_requests SET status = 'Accountability_Submitted' WHERE request_id = ?", [$requestId]);
            Audit::log('Accountability submitted', 'Accountability', (int) $acc['accountability_id'], "Submitted accountability for {$req['request_code']}: " . money($acc['total_spent']) . ' spent, ' . money($acc['balance_returned']) . ' returned');
            Notify::role('Finance', 'Accountability awaiting verification', "{$user['full_name']} submitted the accountability for {$req['request_code']}.", 'modules/accountabilities/view.php?id=' . $acc['accountability_id']);
        });
    }
}
