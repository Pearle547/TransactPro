/* Accountability form: add/remove expenditure items and reconcile totals live. */
document.addEventListener('DOMContentLoaded', function () {
    var form = document.getElementById('accountability-form');
    if (!form) { return; }

    var received = parseFloat(form.dataset.received || '0');
    var container = document.getElementById('items');
    var template = document.getElementById('item-template');
    var returned = document.getElementById('balance_returned');
    var box = document.getElementById('reconcile');

    function fmt(n) { return 'UGX ' + Math.round(n).toLocaleString('en-US'); }
    function num(v) { return parseFloat(String(v || '').replace(/,/g, '')) || 0; }

    function renumber() {
        var cards = container.querySelectorAll('[data-item]');
        cards.forEach(function (card, i) {
            card.querySelector('[data-number]').textContent = i + 1;
            card.querySelector('[data-remove]').style.visibility = cards.length > 1 ? 'visible' : 'hidden';
        });
    }

    function reconcile() {
        var spent = 0;
        container.querySelectorAll('[data-amount]').forEach(function (input) { spent += num(input.value); });
        var diff = received - spent - num(returned.value);
        box.className = 'budget-box ' + (Math.abs(diff) < 0.01 ? 'good' : 'bad');
        box.innerHTML = 'Received: <strong>' + fmt(received) + '</strong> &nbsp;·&nbsp; Spent: <strong>' + fmt(spent) + '</strong>' +
            ' &nbsp;·&nbsp; Returned: <strong>' + fmt(num(returned.value)) + '</strong><br>' +
            (Math.abs(diff) < 0.01
                ? 'Reconciled ✓ — the accountability can be submitted once every item has its receipt.'
                : (diff > 0 ? 'Still to account for or return: <strong>' + fmt(diff) + '</strong>'
                            : 'Spent + returned exceeds the amount received by <strong>' + fmt(-diff) + '</strong>'));
    }

    document.getElementById('add-item').addEventListener('click', function () {
        container.appendChild(template.content.cloneNode(true));
        renumber(); reconcile();
        var last = container.querySelectorAll('[data-item]');
        last[last.length - 1].querySelector('input[type=date]').focus();
    });

    container.addEventListener('click', function (event) {
        var btn = event.target.closest('[data-remove]');
        if (!btn) { return; }
        if (container.querySelectorAll('[data-item]').length > 1) {
            btn.closest('[data-item]').remove();
            renumber(); reconcile();
        }
    });
    container.addEventListener('input', reconcile);
    returned.addEventListener('input', reconcile);

    renumber(); reconcile();
});
