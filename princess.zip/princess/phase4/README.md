# TransactPro — Phase 4: Payments, Accountability & Expenditure

Builds on Phases 1–3. Login, users, projects, budgets, plans and the Manager → Finance → (Director ≥ UGX 10M) request approval all still work.

## What is new in this phase
| Area | Features |
| :--- | :--- |
| **Payments** | Finance sees every fully approved request waiting for payment and records the disbursement (date, method, reference). A request can be paid **once**, only when fully approved, only by Finance. The requester is notified and told the accountability deadline |
| **Accountability** | After payment, the requester lists each expense as an **expenditure item** (date, vendor, receipt no., description, amount) with the **receipt file attached** (PDF/JPG/PNG, max 5 MB), returns any unspent balance, and submits |
| **Reconciliation** | *Total spent + balance returned must equal the amount received.* Shown live while typing and enforced again on the server. A returned balance needs a reference. Drafts can be saved at any time without losing uploaded files |
| **Secure receipts** | Files are stored outside public access under random names and opened only through an access-checked page (owner, managers, Finance, Director, Admin) |
| **Expenditure records** | Searchable register of every expense with vendor, receipt and verification status, filterable by project and date |
| **Deadlines** | Each payment starts a 14-day accountability clock (setting `accountability_due_days`). Outstanding and overdue items appear on dashboards and lists |
| Dashboard | Funds awaiting payment, funds disbursed, outstanding and overdue accountabilities |

Status flow of a request: `... → Approved → Paid → Accountability Submitted` (Phase 5 adds verification and closing).

## Install (XAMPP)
1. Copy this folder to `C:\xampp\htdocs\transactpro\phase4\`.
2. Start **Apache** and **MySQL**.
3. phpMyAdmin → **Import** → `database/schema.sql` (creates `transactpro_phase4`).
4. Make sure `storage/receipts/` is writable by Apache (it is by default on XAMPP).
5. Open `http://localhost/transactpro/phase4/`.

Demo accounts (password `password123`): `admin@`, `staff@`, `staff2@`, `manager@`, `finance@`, `director@` + `transactpro.test`.

## Try it
1. Take a request all the way to **Approved** (see Phase 3).
2. **finance** → *Payments* → *Record payment*.
3. **staff** → *Accountabilities* → *Start*. Add items with receipts; the reconciliation box turns green when spent + returned equals the amount received. Submit.
4. **finance** is notified. (Verifying and closing the request arrives in Phase 5.)

## Rules enforced
* Only the requester can account for a request, and only after it is paid.
* No submission without a receipt on **every** item, or if the figures do not reconcile.
* Receipts must really be PDF/JPG/PNG (checked by file content, not just the extension) and ≤ 5 MB.
* Budget stays reserved until the accountability is verified (Phase 5), then any unspent amount is released.
