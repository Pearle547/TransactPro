<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

Auth::require();
if (!is_post()) {
    redirect('modules/accountabilities/index.php');
}

$id  = (int) ($_POST['accountability_id'] ?? 0);
$acc = DB::row('SELECT request_id FROM accountabilities WHERE accountability_id = ?', [$id]);
if ($acc === null) {
    abort(404, 'That accountability does not exist.');
}

try {
    switch ((string) ($_POST['action'] ?? '')) {
        case 'submit':
            Accountabilities::submit((int) $acc['request_id']);
            flash('success', 'Accountability submitted to Finance for verification.');
            break;
        default:
            throw new DomainException('Unknown action.');
    }
} catch (DomainException $e) {
    flash('error', $e->getMessage());
}
redirect('modules/accountabilities/view.php?id=' . $id);
