<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

/**
 * Serve a receipt file. Receipts are stored outside public access; this script is the only way to open one.
 */
$user = Auth::require();
$id   = (int) ($_GET['id'] ?? 0);
$item = DB::row(
    'SELECT i.*, a.user_id AS owner_id FROM accountability_items i JOIN accountabilities a ON a.accountability_id = i.accountability_id WHERE i.item_id = ?',
    [$id]
);
if ($item === null || !$item['receipt_path']) {
    abort(404, 'That receipt does not exist.');
}
if ($user['role'] === 'Staff' && (int) $item['owner_id'] !== (int) $user['user_id']) {
    Audit::log('Access denied', 'Authorization', $id, 'Attempted to open another person\'s receipt');
    abort(404, 'That receipt does not exist.');
}

$path = Receipts::absolute($item['receipt_path']);
if (!is_file($path)) {
    abort(404, 'The receipt file is missing from storage.');
}

$safeName = preg_replace('/[^\w.\- ()]/', '_', (string) $item['receipt_name']) ?: 'receipt';
header_remove('Content-Security-Policy');
header('Content-Type: ' . $item['receipt_mime']);
header('Content-Length: ' . filesize($path));
header('Content-Disposition: inline; filename="' . $safeName . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=0');
readfile($path);
exit;
