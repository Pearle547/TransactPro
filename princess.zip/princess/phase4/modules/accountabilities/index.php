<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user    = Auth::require();
$isStaff = $user['role'] === 'Staff';

$status   = (string) input('status', '');
$statuses = ['Draft', 'Submitted', 'Verified', 'Revision_Requested'];
$where    = ['1 = 1'];
$params   = [];
if ($isStaff) {
    $where[]  = 'a.user_id = ?';
    $params[] = $user['user_id'];
}
if (in_array($status, $statuses, true)) {
    $where[]  = 'a.status = ?';
    $params[] = $status;
}
$whereSql = implode(' AND ', $where);
$page = paginate((int) DB::val("SELECT COUNT(*) FROM accountabilities a WHERE $whereSql", $params), 15);
$rows = DB::all(
    "SELECT a.*, fr.request_code, p.project_code, u.full_name
       FROM accountabilities a
       JOIN financial_requests fr ON fr.request_id = a.request_id
       JOIN projects p ON p.project_id = fr.project_id
       JOIN users u ON u.user_id = a.user_id
      WHERE $whereSql ORDER BY a.accountability_id DESC LIMIT {$page['perPage']} OFFSET {$page['offset']}",
    $params
);

// Paid requests whose accountability has not been submitted yet (the requester's to-do list; Finance monitors all of them)
$dueSql = "SELECT fr.request_id, fr.request_code, fr.amount_requested, pay.payment_date, p.project_code, u.full_name,
                  a.status AS acc_status
             FROM financial_requests fr
             JOIN payments pay ON pay.request_id = fr.request_id
             JOIN projects p ON p.project_id = fr.project_id
             JOIN users u ON u.user_id = fr.user_id
        LEFT JOIN accountabilities a ON a.request_id = fr.request_id
            WHERE fr.status = 'Paid'" . ($isStaff ? ' AND fr.user_id = ?' : '') . ' ORDER BY pay.payment_date';
$due = DB::all($dueSql, $isStaff ? [$user['user_id']] : []);

render_header('Accountabilities', 'accountabilities', ['subtitle' => $isStaff ? 'Account for the money you have received' : 'Track how released funds are being accounted for']);
?>
<div class="card">
    <div class="card-head"><h3><?= $isStaff ? 'Funds you still need to account for' : 'Outstanding accountabilities' ?> (<?= count($due) ?>)</h3></div>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Request</th><?php if (!$isStaff): ?><th>Staff member</th><?php endif; ?><th>Project</th><th class="num">Amount received</th><th>Paid</th><th>Due by</th><th>Progress</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($due as $d): $dueDate = Accountabilities::dueDate($d['payment_date']); $overdue = $dueDate < date('Y-m-d'); ?>
                <tr>
                    <td class="code"><a href="<?= e(url('modules/requests/view.php?id=' . (int) $d['request_id'])) ?>"><?= e($d['request_code']) ?></a></td>
                    <?php if (!$isStaff): ?><td><?= e($d['full_name']) ?></td><?php endif; ?>
                    <td><?= e($d['project_code']) ?></td>
                    <td class="num"><?= e(money($d['amount_requested'])) ?></td>
                    <td class="nowrap"><?= e(fdate($d['payment_date'])) ?></td>
                    <td class="nowrap"><?= e(fdate($dueDate)) ?> <?= $overdue ? badge('overdue', 'Overdue') : '' ?></td>
                    <td><?= $d['acc_status'] ? badge($d['acc_status']) : '<span class="muted">Not started</span>' ?></td>
                    <td class="text-right"><?php if ($isStaff): ?><a class="btn btn-sm btn-primary" href="form.php?request_id=<?= (int) $d['request_id'] ?>"><?= $d['acc_status'] ? 'Continue' : 'Start' ?></a><?php endif; ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$due): ?><tr><td colspan="8" class="table-empty">Nothing outstanding — all released funds have been accounted for.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card">
    <div class="card-head"><h3>Accountabilities</h3></div>
    <form class="filters" method="get">
        <div class="field"><label for="status">Status</label>
            <select class="input" id="status" name="status" data-autosubmit>
                <option value="">All statuses</option>
                <?php foreach ($statuses as $s): ?><option value="<?= $s ?>"<?= selected($status === $s) ?>><?= e(status_label($s)) ?></option><?php endforeach; ?>
            </select></div>
        <a class="btn" href="index.php">Reset</a>
    </form>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Request</th><?php if (!$isStaff): ?><th>Staff member</th><?php endif; ?><th>Project</th><th class="num">Received</th><th class="num">Spent</th><th class="num">Returned</th><th>Status</th><th>Submitted</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $a): ?>
                <tr>
                    <td class="code"><?= e($a['request_code']) ?></td>
                    <?php if (!$isStaff): ?><td><?= e($a['full_name']) ?></td><?php endif; ?>
                    <td><?= e($a['project_code']) ?></td>
                    <td class="num"><?= e(money($a['amount_received'])) ?></td>
                    <td class="num"><?= e(money($a['total_spent'])) ?></td>
                    <td class="num"><?= e(money($a['balance_returned'])) ?></td>
                    <td><?= badge($a['status']) ?></td>
                    <td class="nowrap"><?= e(fdate($a['submitted_at'])) ?></td>
                    <td class="text-right"><a class="btn btn-sm" href="view.php?id=<?= (int) $a['accountability_id'] ?>">Open</a></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?><tr><td colspan="9" class="table-empty">No accountabilities found.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
    <?= pager($page) ?>
</div>
<?php
render_footer();
