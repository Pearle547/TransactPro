<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user      = Auth::require(['Staff']);
$requestId = (int) ($_GET['request_id'] ?? $_POST['request_id'] ?? 0);

$req = DB::row(
    'SELECT fr.*, pay.paid_amount, pay.payment_date, p.project_code, p.project_name, bl.line_code
       FROM financial_requests fr
       JOIN payments pay ON pay.request_id = fr.request_id
       JOIN projects p ON p.project_id = fr.project_id
       JOIN budget_lines bl ON bl.budget_line_id = fr.budget_line_id
      WHERE fr.request_id = ?',
    [$requestId]
);
if ($req === null || !RequestWorkflow::isOwner($req, $user)) {
    abort(404, 'That request does not exist.');
}
$acc = Accountabilities::forRequest($requestId);
if ($req['status'] !== 'Paid' || ($acc && !Accountabilities::isEditable($acc, $user))) {
    flash('info', 'This accountability is not open for editing.');
    redirect($acc ? 'modules/accountabilities/view.php?id=' . $acc['accountability_id'] : 'modules/requests/view.php?id=' . $requestId);
}

if (is_post()) {
    try {
        $accId = Accountabilities::save($requestId, $_POST, $_FILES);
    } catch (DomainException $e) {
        flash('error', $e->getMessage());
        redirect('modules/accountabilities/form.php?request_id=' . $requestId);
    }
    if (!isset($_POST['submit'])) {
        flash('success', 'Draft saved.');
        redirect('modules/accountabilities/form.php?request_id=' . $requestId);
    }
    try {
        Accountabilities::submit($requestId);
    } catch (DomainException $e) {
        flash('error', 'Saved, but not submitted yet: ' . $e->getMessage());
        redirect('modules/accountabilities/form.php?request_id=' . $requestId);
    }
    flash('success', 'Accountability submitted to Finance for verification.');
    redirect('modules/accountabilities/view.php?id=' . $accId);
}

$items = $acc ? Accountabilities::items((int) $acc['accountability_id']) : [];
if (!$items) {
    $items = [['item_id' => 0, 'item_date' => '', 'vendor' => '', 'receipt_number' => '', 'description' => '', 'amount' => '', 'receipt_path' => null, 'receipt_name' => null]];
}
$lastReview = null;
if ($acc && $acc['status'] === 'Revision_Requested') {
    $hist       = Approvals::history('accountability', (int) $acc['accountability_id']);
    $lastReview = $hist ? end($hist) : null;
}
$received = (float) $req['paid_amount'];
$dueDate  = Accountabilities::dueDate($req['payment_date']);

/** Render one expenditure item. $n is only used for the visible label; the server re-numbers rows. */
function item_row(array $it, int $n): void
{
    ?>
    <div class="item-card" data-item>
        <div class="item-head"><span>Expenditure item <span data-number><?= $n ?></span></span><button class="btn btn-sm btn-danger" type="button" data-remove>Remove</button></div>
        <input type="hidden" name="item_id[]" value="<?= (int) $it['item_id'] ?>">
        <div class="form-grid">
            <div class="field"><label>Date <span class="req">*</span></label><input class="input" type="date" name="item_date[]" value="<?= e($it['item_date']) ?>" max="<?= date('Y-m-d') ?>"></div>
            <div class="field"><label>Vendor / supplier <span class="req">*</span></label><input class="input" name="vendor[]" value="<?= e($it['vendor']) ?>" maxlength="200"></div>
            <div class="field"><label>Receipt / invoice no.</label><input class="input" name="receipt_number[]" value="<?= e($it['receipt_number'] ?? '') ?>" maxlength="100"></div>
            <div class="field"><label>Amount (UGX) <span class="req">*</span></label><input class="input" name="amount[]" data-amount inputmode="decimal" value="<?= $it['amount'] !== '' && (float) $it['amount'] == 0 ? '' : e($it['amount']) ?>"></div>
            <div class="field full"><label>What was bought / paid for <span class="req">*</span></label><input class="input" name="description[]" value="<?= e($it['description']) ?>" maxlength="500"></div>
            <div class="field full">
                <label>Receipt file (PDF, JPG or PNG, max 5 MB) <span class="req">*</span></label>
                <?php if (!empty($it['receipt_path']) && (int) $it['item_id'] > 0): ?>
                    <span class="hint">Attached: <a href="<?= e(url('modules/accountabilities/receipt.php?id=' . (int) $it['item_id'])) ?>" target="_blank" rel="noopener"><?= e($it['receipt_name']) ?></a> — choose a file only if you want to replace it.</span>
                <?php endif; ?>
                <input class="input" type="file" name="receipt[]" accept="application/pdf,image/jpeg,image/png">
            </div>
        </div>
    </div>
    <?php
}

render_header('Account for ' . $req['request_code'], 'accountabilities', ['subtitle' => $req['project_code'] . ' · ' . $req['line_code']]);
?>
<?php if ($lastReview): ?>
    <div class="alert alert-warning"><strong><?= e($lastReview['full_name']) ?> returned this accountability:</strong> <?= e($lastReview['comments']) ?></div>
<?php endif; ?>
<div class="panel-note">
    You received <strong><?= e(money($received)) ?></strong> on <?= e(fdate($req['payment_date'])) ?>. List every expense with its receipt, and return any unspent balance.
    <strong>Total spent + balance returned must equal <?= e(money($received)) ?>.</strong> Please submit by <strong><?= e(fdate($dueDate)) ?></strong>.
</div>

<form method="post" enctype="multipart/form-data" id="accountability-form" data-once data-received="<?= e((string) $received) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="request_id" value="<?= $requestId ?>">

    <div class="card">
        <div class="card-head"><h3>Expenditure items</h3><button class="btn btn-sm" type="button" id="add-item">+ Add item</button></div>
        <div class="card-body" id="items">
            <?php foreach ($items as $n => $it) { item_row($it, $n + 1); } ?>
        </div>
    </div>

    <div class="card">
        <div class="card-head"><h3>Reconciliation</h3></div>
        <div class="card-body">
            <div class="form-grid">
                <div class="field">
                    <label for="balance_returned">Balance returned to JESE (UGX)</label>
                    <input class="input" id="balance_returned" name="balance_returned" inputmode="decimal" value="<?= e($acc && (float) $acc['balance_returned'] > 0 ? $acc['balance_returned'] : '') ?>" placeholder="0">
                </div>
                <div class="field">
                    <label for="return_reference">Return reference</label>
                    <input class="input" id="return_reference" name="return_reference" value="<?= e($acc['return_reference'] ?? '') ?>" maxlength="100" placeholder="Deposit slip / receipt no. (needed if a balance is returned)">
                </div>
                <div class="field full"><div class="budget-box" id="reconcile">Add your items to reconcile.</div></div>
                <div class="field full">
                    <label for="explanation">Explanation / notes</label>
                    <textarea class="input" id="explanation" name="explanation"><?= e($acc['explanation'] ?? '') ?></textarea>
                </div>
            </div>
            <div class="form-actions">
                <a class="btn" href="<?= e(url('modules/accountabilities/index.php')) ?>">Close</a>
                <button class="btn" type="submit" name="draft" value="1">Save draft</button>
                <button class="btn btn-primary" type="submit" name="submit" value="1" data-confirm="Submit this accountability to Finance? You will not be able to change it unless it is returned.">Submit to Finance</button>
            </div>
        </div>
    </div>
</form>

<template id="item-template"><?php item_row(['item_id' => 0, 'item_date' => '', 'vendor' => '', 'receipt_number' => '', 'description' => '', 'amount' => '', 'receipt_path' => null, 'receipt_name' => null], 0); ?></template>
<?php
render_footer(['accountability-form.js']);
