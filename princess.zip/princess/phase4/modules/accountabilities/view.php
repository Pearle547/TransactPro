<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user = Auth::require();
$id   = (int) ($_GET['id'] ?? 0);
$acc  = DB::row(
    'SELECT a.*, fr.request_code, fr.project_id, fr.status AS request_status, fr.purpose, p.project_code, p.project_name, bl.line_code,
            u.full_name AS staff_name, pay.payment_date, pay.payment_method, pay.payment_reference, rv.full_name AS reviewer
       FROM accountabilities a
       JOIN financial_requests fr ON fr.request_id = a.request_id
       JOIN projects p ON p.project_id = fr.project_id
       JOIN budget_lines bl ON bl.budget_line_id = fr.budget_line_id
       JOIN users u ON u.user_id = a.user_id
       JOIN payments pay ON pay.request_id = fr.request_id
  LEFT JOIN users rv ON rv.user_id = a.reviewed_by
      WHERE a.accountability_id = ?',
    [$id]
);
if ($acc === null || !Accountabilities::canView($acc, $user)) {
    abort(404, 'That accountability does not exist.');
}

$items    = Accountabilities::items($id);
$history  = Approvals::history('accountability', $id);
$editable = Accountabilities::isEditable($acc, $user);
$problems = $editable ? Accountabilities::problems($acc, $items) : [];
$dueDate  = Accountabilities::dueDate($acc['payment_date']);

$actions = $editable ? '<a class="btn btn-primary" href="' . e(url('modules/accountabilities/form.php?request_id=' . (int) $acc['request_id'])) . '">Edit accountability</a>' : '';
render_header('Accountability ' . $acc['request_code'], 'accountabilities', ['subtitle' => $acc['staff_name'] . ' · ' . $acc['project_code'], 'actions' => $actions]);
?>
<div class="stats">
    <div class="stat"><div class="stat-label">Amount received</div><div class="stat-value"><?= e(money($acc['amount_received'])) ?></div><div class="stat-note">Paid <?= e(fdate($acc['payment_date'])) ?> · <?= e($acc['payment_method']) ?></div></div>
    <div class="stat danger"><div class="stat-label">Total spent</div><div class="stat-value"><?= e(money($acc['total_spent'])) ?></div><div class="stat-note"><?= count($items) ?> item(s)</div></div>
    <div class="stat accent"><div class="stat-label">Balance returned</div><div class="stat-value"><?= e(money($acc['balance_returned'])) ?></div><div class="stat-note"><?= e($acc['return_reference'] ?: 'No reference') ?></div></div>
    <?php $diff = (float) $acc['amount_received'] - (float) $acc['total_spent'] - (float) $acc['balance_returned']; ?>
    <div class="stat <?= abs($diff) < 0.01 ? 'ok' : 'warn' ?>"><div class="stat-label">Reconciliation</div><div class="stat-value"><?= abs($diff) < 0.01 ? 'Balanced' : e(money(abs($diff))) ?></div><div class="stat-note"><?= abs($diff) < 0.01 ? 'Spent + returned = received' : 'Unaccounted difference' ?></div></div>
</div>

<div class="grid grid-main">
    <div>
        <?php if ($editable && $problems): ?>
            <div class="alert alert-warning">
                <strong>Not ready to submit yet:</strong>
                <ul style="margin:.4rem 0 0 1.1rem;padding:0"><?php foreach ($problems as $p): ?><li><?= e($p) ?></li><?php endforeach; ?></ul>
            </div>
        <?php elseif ($editable): ?>
            <div class="card"><div class="card-body">
                <p>Everything is in order. Submit this accountability to Finance for verification.</p>
                <form method="post" action="action.php" data-once>
                    <?= csrf_field() ?><input type="hidden" name="accountability_id" value="<?= $id ?>">
                    <button class="btn btn-primary" type="submit" name="action" value="submit">Submit to Finance</button>
                </form>
            </div></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-head"><h3>Expenditure items</h3><?= badge($acc['status']) ?></div>
            <div class="card-body flush table-wrap">
                <table class="table">
                    <thead><tr><th>#</th><th>Date</th><th>Vendor</th><th>Description</th><th>Receipt no.</th><th class="num">Amount</th><th>Receipt</th></tr></thead>
                    <tbody>
                    <?php foreach ($items as $n => $it): ?>
                        <tr>
                            <td><?= $n + 1 ?></td>
                            <td class="nowrap"><?= e(fdate($it['item_date'])) ?></td>
                            <td><?= e($it['vendor']) ?></td>
                            <td><?= e($it['description']) ?></td>
                            <td><?= e($it['receipt_number'] ?: '—') ?></td>
                            <td class="num"><?= e(money($it['amount'])) ?></td>
                            <td><?= $it['receipt_path'] ? '<a class="btn btn-sm" target="_blank" rel="noopener" href="' . e(url('modules/accountabilities/receipt.php?id=' . (int) $it['item_id'])) . '">View</a>' : '<span class="badge badge-rejected">Missing</span>' ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$items): ?><tr><td colspan="7" class="table-empty">No items recorded yet.</td></tr><?php endif; ?>
                    </tbody>
                    <?php if ($items): ?><tfoot><tr><td colspan="5">Total spent</td><td class="num"><?= e(money($acc['total_spent'])) ?></td><td></td></tr></tfoot><?php endif; ?>
                </table>
            </div>
        </div>

        <?php if ($acc['explanation']): ?>
        <div class="card"><div class="card-head"><h3>Explanation</h3></div><div class="card-body prose"><?= e($acc['explanation']) ?></div></div>
        <?php endif; ?>

        <?php foreach (glob(__DIR__ . '/panels/*.php') ?: [] as $panel) { include $panel; } ?>
    </div>

    <div>
        <div class="card">
            <div class="card-head"><h3>Details</h3></div>
            <div class="card-body">
                <dl class="kv">
                    <div class="wide"><dt>Request</dt><dd><a href="<?= e(url('modules/requests/view.php?id=' . (int) $acc['request_id'])) ?>"><?= e($acc['request_code']) ?></a> <?= badge($acc['request_status']) ?></dd></div>
                    <div class="wide"><dt>Project / line</dt><dd><?= e($acc['project_code'] . ' · ' . $acc['line_code']) ?></dd></div>
                    <div class="wide"><dt>Purpose</dt><dd class="prose"><?= e($acc['purpose']) ?></dd></div>
                    <div><dt>Due by</dt><dd><?= e(fdate($dueDate)) ?></dd></div>
                    <div><dt>Submitted</dt><dd><?= e(fdatetime($acc['submitted_at'])) ?></dd></div>
                    <?php if ($acc['reviewer']): ?><div class="wide"><dt>Reviewed by</dt><dd><?= e($acc['reviewer']) ?>, <?= e(fdatetime($acc['reviewed_at'])) ?></dd></div><?php endif; ?>
                </dl>
            </div>
        </div>
        <div class="card">
            <div class="card-head"><h3>Review history</h3></div>
            <div class="card-body"><?= Approvals::timeline($history, $acc['submitted_at'] ? ['Submitted by ' . $acc['staff_name'], $acc['submitted_at']] : null) ?></div>
        </div>
    </div>
</div>
<?php
render_footer();
