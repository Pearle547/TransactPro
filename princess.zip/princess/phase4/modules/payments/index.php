<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user  = Auth::require(['Admin', 'Finance', 'Director']);
$canPay = $user['role'] === 'Finance';

$awaiting = DB::all(
    "SELECT fr.request_id, fr.request_code, fr.amount_requested, fr.approved_at, p.project_code, u.full_name AS requester
       FROM financial_requests fr JOIN projects p ON p.project_id = fr.project_id JOIN users u ON u.user_id = fr.user_id
      WHERE fr.status = 'Approved' ORDER BY fr.approved_at"
);

$method = (string) input('method', '');
$from   = (string) input('from', '');
$to     = (string) input('to', '');
$where  = ['1 = 1'];
$params = [];
if (in_array($method, Payments::METHODS, true)) {
    $where[]  = 'pay.payment_method = ?';
    $params[] = $method;
}
if (Validator::isDate($from)) {
    $where[]  = 'pay.payment_date >= ?';
    $params[] = $from;
}
if (Validator::isDate($to)) {
    $where[]  = 'pay.payment_date <= ?';
    $params[] = $to;
}
$whereSql = implode(' AND ', $where);
$page     = paginate((int) DB::val("SELECT COUNT(*) FROM payments pay WHERE $whereSql", $params), 15);
$history  = DB::all(
    "SELECT pay.*, fr.request_code, fr.status AS request_status, u.full_name AS requester, p.project_code, rec.full_name AS recorder
       FROM payments pay
       JOIN financial_requests fr ON fr.request_id = pay.request_id
       JOIN users u ON u.user_id = fr.user_id
       JOIN projects p ON p.project_id = fr.project_id
       JOIN users rec ON rec.user_id = pay.recorded_by
      WHERE $whereSql ORDER BY pay.payment_id DESC LIMIT {$page['perPage']} OFFSET {$page['offset']}",
    $params
);

render_header('Payments', 'payments', ['subtitle' => 'Disburse approved requests and keep the payment record']);
?>
<div class="card">
    <div class="card-head"><h3>Approved — awaiting payment (<?= count($awaiting) ?>)</h3></div>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Request</th><th>Requester</th><th>Project</th><th class="num">Amount</th><th>Approved</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($awaiting as $r): ?>
                <tr>
                    <td class="code"><a href="<?= e(url('modules/requests/view.php?id=' . (int) $r['request_id'])) ?>"><?= e($r['request_code']) ?></a></td>
                    <td><?= e($r['requester']) ?></td>
                    <td><?= e($r['project_code']) ?></td>
                    <td class="num"><?= e(money($r['amount_requested'])) ?></td>
                    <td class="nowrap"><?= e(time_ago($r['approved_at'])) ?></td>
                    <td class="text-right"><?php if ($canPay): ?><a class="btn btn-sm btn-primary" href="form.php?request_id=<?= (int) $r['request_id'] ?>">Record payment</a><?php endif; ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$awaiting): ?><tr><td colspan="6" class="table-empty">No approved requests are waiting for payment.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card">
    <div class="card-head"><h3>Payment history</h3></div>
    <form class="filters" method="get">
        <div class="field"><label for="method">Method</label>
            <select class="input" id="method" name="method" data-autosubmit>
                <option value="">All methods</option>
                <?php foreach (Payments::METHODS as $m): ?><option<?= selected($method === $m) ?>><?= e($m) ?></option><?php endforeach; ?>
            </select></div>
        <div class="field"><label for="from">From</label><input class="input" type="date" id="from" name="from" value="<?= e($from) ?>"></div>
        <div class="field"><label for="to">To</label><input class="input" type="date" id="to" name="to" value="<?= e($to) ?>"></div>
        <button class="btn" type="submit">Filter</button>
        <a class="btn" href="index.php">Reset</a>
    </form>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Date</th><th>Request</th><th>Paid to</th><th>Project</th><th>Method</th><th>Reference</th><th class="num">Amount</th><th>Recorded by</th></tr></thead>
            <tbody>
            <?php foreach ($history as $h): ?>
                <tr>
                    <td class="nowrap"><?= e(fdate($h['payment_date'])) ?></td>
                    <td class="code"><a href="<?= e(url('modules/requests/view.php?id=' . (int) $h['request_id'])) ?>"><?= e($h['request_code']) ?></a></td>
                    <td><?= e($h['requester']) ?></td>
                    <td><?= e($h['project_code']) ?></td>
                    <td><?= e($h['payment_method']) ?></td>
                    <td><?= e($h['payment_reference'] ?: '—') ?></td>
                    <td class="num"><?= e(money($h['paid_amount'])) ?></td>
                    <td><?= e($h['recorder']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$history): ?><tr><td colspan="8" class="table-empty">No payments recorded.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
    <?= pager($page) ?>
</div>
<?php
render_footer();
