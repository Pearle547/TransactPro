<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user      = Auth::require(['Finance']);
$requestId = (int) ($_GET['request_id'] ?? $_POST['request_id'] ?? 0);
$req       = DB::row(
    'SELECT fr.*, p.project_code, p.project_name, bl.line_code, u.full_name AS requester
       FROM financial_requests fr JOIN projects p ON p.project_id = fr.project_id
       JOIN budget_lines bl ON bl.budget_line_id = fr.budget_line_id JOIN users u ON u.user_id = fr.user_id
      WHERE fr.request_id = ?',
    [$requestId]
);
if ($req === null) {
    abort(404, 'That request does not exist.');
}
if ($req['status'] !== 'Approved') {
    flash('error', 'Only fully approved requests that have not been paid can be paid.');
    redirect('modules/requests/view.php?id=' . $requestId);
}

if (is_post()) {
    $data = [
        'payment_date'      => (string) input('payment_date', ''),
        'payment_method'    => (string) input('payment_method', ''),
        'payment_reference' => (string) input('payment_reference', ''),
        'notes'             => (string) input('notes', ''),
    ];
    $errors = Validator::validate($data, [
        'payment_date'      => 'required|date',
        'payment_method'    => 'required|in:' . implode(',', Payments::METHODS),
        'payment_reference' => 'max:100',
        'notes'             => 'max:1000',
    ], ['payment_date' => 'Payment date', 'payment_method' => 'Payment method', 'payment_reference' => 'Reference']);
    if (!$errors) {
        try {
            Payments::record($requestId, $data);
            flash('success', 'Payment recorded. ' . $req['requester'] . ' has been asked to account for the funds.');
            redirect('modules/requests/view.php?id=' . $requestId);
        } catch (DomainException $e) {
            $errors['payment_reference'] = $e->getMessage();
        }
    }
    remember_form($data, $errors);
    redirect('modules/payments/form.php?request_id=' . $requestId);
}

render_header('Record payment', 'payments', ['subtitle' => $req['request_code'] . ' · ' . $req['requester']]);
?>
<div class="grid grid-main">
    <div class="card">
        <div class="card-head"><h3>Payment details</h3></div>
        <div class="card-body">
            <form method="post" data-once>
                <?= csrf_field() ?>
                <input type="hidden" name="request_id" value="<?= $requestId ?>">
                <div class="form-grid">
                    <div class="field">
                        <label for="payment_date">Payment date <span class="req">*</span></label>
                        <input class="input<?= has_error('payment_date') ? ' invalid' : '' ?>" type="date" id="payment_date" name="payment_date" value="<?= e(old('payment_date', date('Y-m-d'))) ?>" max="<?= date('Y-m-d') ?>" required>
                        <?= field_error('payment_date') ?>
                    </div>
                    <div class="field">
                        <label for="payment_method">Method <span class="req">*</span></label>
                        <select class="input<?= has_error('payment_method') ? ' invalid' : '' ?>" id="payment_method" name="payment_method" required>
                            <?php foreach (Payments::METHODS as $m): ?><option<?= selected(old('payment_method', 'Bank Transfer') === $m) ?>><?= e($m) ?></option><?php endforeach; ?>
                        </select>
                        <?= field_error('payment_method') ?>
                    </div>
                    <div class="field full">
                        <label for="payment_reference">Reference / transaction ID</label>
                        <input class="input<?= has_error('payment_reference') ? ' invalid' : '' ?>" id="payment_reference" name="payment_reference" value="<?= e(old('payment_reference')) ?>" placeholder="Bank reference, mobile money ID or cheque number">
                        <span class="hint">Required for every method except Cash.</span>
                        <?= field_error('payment_reference') ?>
                    </div>
                    <div class="field full">
                        <label for="notes">Notes</label>
                        <textarea class="input" id="notes" name="notes"><?= e(old('notes')) ?></textarea>
                    </div>
                </div>
                <div class="form-actions">
                    <a class="btn" href="<?= e(url('modules/requests/view.php?id=' . $requestId)) ?>">Cancel</a>
                    <button class="btn btn-success" type="submit" data-confirm="Confirm that <?= e(money($req['amount_requested'])) ?> has been paid? This cannot be undone.">Confirm payment</button>
                </div>
            </form>
        </div>
    </div>
    <div class="card">
        <div class="card-head"><h3>Request</h3></div>
        <div class="card-body">
            <dl class="kv">
                <div class="wide"><dt>Amount to pay</dt><dd style="font-size:1.4rem"><?= e(money($req['amount_requested'])) ?></dd></div>
                <div class="wide"><dt>Requester</dt><dd><?= e($req['requester']) ?></dd></div>
                <div class="wide"><dt>Project</dt><dd><?= e($req['project_code'] . ' — ' . $req['project_name']) ?></dd></div>
                <div class="wide"><dt>Budget line</dt><dd><?= e($req['line_code']) ?></dd></div>
                <div class="wide"><dt>Purpose</dt><dd class="prose"><?= e($req['purpose']) ?></dd></div>
            </dl>
        </div>
    </div>
</div>
<?php
render_footer();
