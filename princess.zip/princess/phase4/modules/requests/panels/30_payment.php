<?php
/** @var array $req @var array $user @var int $id */
$payment = Payments::forRequest($id);

if ($req['status'] === 'Approved' && $user['role'] === 'Finance'): ?>
<div class="card">
    <div class="card-head"><h3>Payment</h3></div>
    <div class="card-body">
        <p>This request is fully approved and waiting for payment of <strong><?= e(money($req['amount_requested'])) ?></strong>.</p>
        <a class="btn btn-primary" href="<?= e(url('modules/payments/form.php?request_id=' . $id)) ?>">Record payment</a>
    </div>
</div>
<?php elseif ($payment): ?>
<div class="card">
    <div class="card-head"><h3>Payment</h3><?= badge('paid', 'Paid') ?></div>
    <div class="card-body">
        <dl class="kv cols-3">
            <div><dt>Amount paid</dt><dd><?= e(money($payment['paid_amount'])) ?></dd></div>
            <div><dt>Date</dt><dd><?= e(fdate($payment['payment_date'])) ?></dd></div>
            <div><dt>Method</dt><dd><?= e($payment['payment_method']) ?></dd></div>
            <div><dt>Reference</dt><dd><?= e($payment['payment_reference'] ?: '—') ?></dd></div>
            <div><dt>Recorded by</dt><dd><?= e($payment['recorder']) ?></dd></div>
            <div><dt>Accountability due</dt><dd><?= e(fdate(Accountabilities::dueDate($payment['payment_date']))) ?></dd></div>
        </dl>
    </div>
</div>
<?php endif; ?>
