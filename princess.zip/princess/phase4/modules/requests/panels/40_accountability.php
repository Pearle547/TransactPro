<?php
/** @var array $req @var array $user @var int $id */
$acc = Accountabilities::forRequest($id);
$mayView = $acc && Accountabilities::canView($acc, $user);

if (RequestWorkflow::isOwner($req, $user) && $req['status'] === 'Paid'): ?>
<div class="card">
    <div class="card-head"><h3>Accountability</h3><?= $acc ? badge($acc['status']) : '' ?></div>
    <div class="card-body">
        <p>Funds were released to you. Record how they were spent, attach every receipt and return any balance.</p>
        <a class="btn btn-primary" href="<?= e(url('modules/accountabilities/form.php?request_id=' . $id)) ?>"><?= $acc ? 'Continue accountability' : 'Start accountability' ?></a>
    </div>
</div>
<?php elseif ($mayView): ?>
<div class="card">
    <div class="card-head"><h3>Accountability</h3><?= badge($acc['status']) ?></div>
    <div class="card-body">
        <dl class="kv cols-3">
            <div><dt>Spent</dt><dd><?= e(money($acc['total_spent'])) ?></dd></div>
            <div><dt>Returned</dt><dd><?= e(money($acc['balance_returned'])) ?></dd></div>
            <div><dt>Submitted</dt><dd><?= e(fdatetime($acc['submitted_at'])) ?></dd></div>
        </dl>
        <a class="btn mt" href="<?= e(url('modules/accountabilities/view.php?id=' . (int) $acc['accountability_id'])) ?>">Open accountability</a>
    </div>
</div>
<?php endif; ?>
