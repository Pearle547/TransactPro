<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user    = Auth::require();
$isStaff = $user['role'] === 'Staff';

$projectId = (int) input('project', 0);
$from      = (string) input('from', '');
$to        = (string) input('to', '');
$q         = (string) input('q', '');

$where  = ["a.status <> 'Draft'"];   // only expenditure that has been submitted (or verified) counts as a record
$params = [];
if ($isStaff) {
    $where[]  = 'a.user_id = ?';
    $params[] = $user['user_id'];
}
if ($projectId > 0) {
    $where[]  = 'fr.project_id = ?';
    $params[] = $projectId;
}
if (Validator::isDate($from)) {
    $where[]  = 'i.item_date >= ?';
    $params[] = $from;
}
if (Validator::isDate($to)) {
    $where[]  = 'i.item_date <= ?';
    $params[] = $to;
}
if ($q !== '') {
    $where[]  = '(i.vendor LIKE ? OR i.description LIKE ? OR i.receipt_number LIKE ?)';
    $params[] = $params[] = $params[] = "%$q%";
}
$whereSql = implode(' AND ', $where);
$join = 'FROM accountability_items i
         JOIN accountabilities a ON a.accountability_id = i.accountability_id
         JOIN financial_requests fr ON fr.request_id = a.request_id
         JOIN projects p ON p.project_id = fr.project_id
         JOIN budget_lines bl ON bl.budget_line_id = fr.budget_line_id
         JOIN users u ON u.user_id = a.user_id';

$total = (float) DB::val("SELECT COALESCE(SUM(i.amount), 0) $join WHERE $whereSql", $params);
$page  = paginate((int) DB::val("SELECT COUNT(*) $join WHERE $whereSql", $params), 20);
$rows  = DB::all(
    "SELECT i.*, a.accountability_id, a.status AS acc_status, fr.request_code, p.project_code, bl.line_code, u.full_name
       $join WHERE $whereSql ORDER BY i.item_date DESC, i.item_id DESC LIMIT {$page['perPage']} OFFSET {$page['offset']}",
    $params
);
$projects = DB::all('SELECT project_id, project_code FROM projects ORDER BY project_code');

render_header('Expenditure', 'expenditures', ['subtitle' => 'Every expense recorded against released funds, with its receipt']);
?>
<div class="stats">
    <div class="stat danger"><div class="stat-label">Total expenditure shown</div><div class="stat-value"><?= e(money($total)) ?></div><div class="stat-note"><?= number_format($page['total']) ?> record(s) matching the filters</div></div>
</div>
<div class="card">
    <form class="filters" method="get">
        <div class="field grow"><label for="q">Search</label><input class="input" id="q" name="q" value="<?= e($q) ?>" placeholder="Vendor, description or receipt no."></div>
        <div class="field"><label for="project">Project</label>
            <select class="input" id="project" name="project" data-autosubmit>
                <option value="">All projects</option>
                <?php foreach ($projects as $p): ?><option value="<?= (int) $p['project_id'] ?>"<?= selected($projectId === (int) $p['project_id']) ?>><?= e($p['project_code']) ?></option><?php endforeach; ?>
            </select></div>
        <div class="field"><label for="from">From</label><input class="input" type="date" id="from" name="from" value="<?= e($from) ?>"></div>
        <div class="field"><label for="to">To</label><input class="input" type="date" id="to" name="to" value="<?= e($to) ?>"></div>
        <button class="btn btn-primary" type="submit">Filter</button>
        <a class="btn" href="index.php">Reset</a>
    </form>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Date</th><th>Vendor</th><th>Description</th><?php if (!$isStaff): ?><th>Spent by</th><?php endif; ?><th>Project / line</th><th>Request</th><th class="num">Amount</th><th>Verification</th><th>Receipt</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="nowrap"><?= e(fdate($r['item_date'])) ?></td>
                    <td><?= e($r['vendor']) ?></td>
                    <td><?= e($r['description']) ?></td>
                    <?php if (!$isStaff): ?><td><?= e($r['full_name']) ?></td><?php endif; ?>
                    <td><?= e($r['project_code']) ?> · <?= e($r['line_code']) ?></td>
                    <td class="code"><a href="<?= e(url('modules/accountabilities/view.php?id=' . (int) $r['accountability_id'])) ?>"><?= e($r['request_code']) ?></a></td>
                    <td class="num"><?= e(money($r['amount'])) ?></td>
                    <td><?= badge($r['acc_status']) ?></td>
                    <td><?= $r['receipt_path'] ? '<a class="btn btn-sm" target="_blank" rel="noopener" href="' . e(url('modules/accountabilities/receipt.php?id=' . (int) $r['item_id'])) . '">View</a>' : '—' ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?><tr><td colspan="9" class="table-empty">No expenditure records found.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
    <?= pager($page) ?>
</div>
<?php
render_footer();
