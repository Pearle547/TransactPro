<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$me      = Auth::require(['Admin']);
$id      = (int) ($_GET['id'] ?? 0);
$editing = $id > 0;
$target  = $editing ? DB::row('SELECT * FROM users WHERE user_id = ?', [$id]) : null;
if ($editing && $target === null) {
    abort(404, 'That user does not exist.');
}
$isSelf = $editing && $id === (int) $me['user_id'];

if (is_post()) {
    $data = [
        'full_name'  => (string) input('full_name', ''),
        'email'      => strtolower((string) input('email', '')),
        'phone'      => (string) input('phone', ''),
        'department' => (string) input('department', ''),
        'role'       => (string) input('role', ''),
        'status'     => (string) input('status', 'Active'),
        'must_change_password' => isset($_POST['must_change_password']) ? 1 : 0,
    ];
    $password = (string) ($_POST['password'] ?? '');

    if ($isSelf) {   // administrators cannot demote or deactivate themselves
        $data['role']   = $target['role'];
        $data['status'] = $target['status'];
    }

    $errors = Validator::validate($data, [
        'full_name'  => 'required|max:100',
        'email'      => 'required|email|max:100',
        'phone'      => 'max:20',
        'department' => 'max:100',
        'role'       => 'required|in:' . implode(',', ROLES),
        'status'     => 'required|in:Active,Inactive',
    ]);

    if (!isset($errors['email']) && DB::val('SELECT COUNT(*) FROM users WHERE email = ? AND user_id <> ?', [$data['email'], $id]) > 0) {
        $errors['email'] = 'Another user already has this email address.';
    }

    if (!$editing || $password !== '') {
        if ($password === '') {
            $errors['password'] = 'A temporary password is required for a new user.';
        } elseif (($problem = Auth::passwordError($password)) !== null) {
            $errors['password'] = $problem;
        }
    }

    if ($editing && $target['role'] === 'Admin' && $target['status'] === 'Active'
        && ($data['role'] !== 'Admin' || $data['status'] !== 'Active')) {
        $otherAdmins = (int) DB::val("SELECT COUNT(*) FROM users WHERE role = 'Admin' AND status = 'Active' AND user_id <> ?", [$id]);
        if ($otherAdmins === 0) {
            $errors['role'] = 'The system must keep at least one active administrator.';
        }
    }

    if ($errors) {
        unset($data['must_change_password']);
        remember_form($data + ['must_change_password' => $_POST['must_change_password'] ?? ''], $errors);
        redirect('modules/users/form.php' . ($editing ? "?id=$id" : ''));
    }

    DB::transaction(function () use ($editing, $id, $data, $password, $target): void {
        if ($editing) {
            DB::exec(
                'UPDATE users SET full_name = ?, email = ?, phone = ?, department = ?, role = ?, status = ?, must_change_password = ? WHERE user_id = ?',
                [$data['full_name'], $data['email'], $data['phone'] ?: null, $data['department'] ?: null, $data['role'], $data['status'], $data['must_change_password'], $id]
            );
            $note = [];
            if ($target['role'] !== $data['role']) {
                $note[] = "role {$target['role']} → {$data['role']}";
            }
            if ($target['status'] !== $data['status']) {
                $note[] = "status {$target['status']} → {$data['status']}";
            }
            if ($password !== '') {
                DB::exec('UPDATE users SET password_hash = ?, failed_attempts = 0, locked_until = NULL WHERE user_id = ?', [password_hash($password, PASSWORD_DEFAULT), $id]);
                $note[] = 'password reset';
            }
            Audit::log('User updated', 'Users', $id, "Updated {$data['email']}" . ($note ? ' (' . implode('; ', $note) . ')' : ''));
        } else {
            $newId = DB::insert(
                'INSERT INTO users (full_name, email, password_hash, role, phone, department, status, must_change_password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [$data['full_name'], $data['email'], password_hash($password, PASSWORD_DEFAULT), $data['role'], $data['phone'] ?: null, $data['department'] ?: null, $data['status'], $data['must_change_password']]
            );
            Audit::log('User created', 'Users', $newId, "Created {$data['email']} with role {$data['role']}");
        }
    });

    flash('success', $editing ? 'User updated.' : 'User created. They will be asked to change the temporary password at first sign-in.');
    redirect('modules/users/index.php');
}

$v = static fn (string $key, mixed $fallback = '') => old($key, $target[$key] ?? $fallback);

render_header($editing ? 'Edit user' : 'New user', 'users', [
    'subtitle' => $editing ? $target['email'] : 'Create a new system account',
]);
?>
<div class="card">
    <div class="card-body">
        <form method="post" data-once>
            <?= csrf_field() ?>
            <div class="form-grid">
                <div class="field">
                    <label for="full_name">Full name <span class="req">*</span></label>
                    <input class="input<?= has_error('full_name') ? ' invalid' : '' ?>" id="full_name" name="full_name" value="<?= e($v('full_name')) ?>" required>
                    <?= field_error('full_name') ?>
                </div>
                <div class="field">
                    <label for="email">Email address <span class="req">*</span></label>
                    <input class="input<?= has_error('email') ? ' invalid' : '' ?>" type="email" id="email" name="email" value="<?= e($v('email')) ?>" required>
                    <?= field_error('email') ?>
                </div>
                <div class="field">
                    <label for="phone">Phone</label>
                    <input class="input<?= has_error('phone') ? ' invalid' : '' ?>" id="phone" name="phone" value="<?= e($v('phone')) ?>">
                    <?= field_error('phone') ?>
                </div>
                <div class="field">
                    <label for="department">Department</label>
                    <input class="input" id="department" name="department" value="<?= e($v('department')) ?>">
                    <?= field_error('department') ?>
                </div>
                <div class="field">
                    <label for="role">Role <span class="req">*</span></label>
                    <select class="input<?= has_error('role') ? ' invalid' : '' ?>" id="role" name="role" <?= $isSelf ? 'disabled' : 'required' ?>>
                        <?php foreach (ROLES as $r): ?><option<?= selected($v('role', 'Staff') === $r) ?>><?= e($r) ?></option><?php endforeach; ?>
                    </select>
                    <?= field_error('role') ?>
                    <?php if ($isSelf): ?><span class="hint">You cannot change your own role.</span><?php endif; ?>
                </div>
                <div class="field">
                    <label for="status">Status</label>
                    <select class="input" id="status" name="status" <?= $isSelf ? 'disabled' : '' ?>>
                        <option<?= selected($v('status', 'Active') === 'Active') ?>>Active</option>
                        <option<?= selected($v('status', 'Active') === 'Inactive') ?>>Inactive</option>
                    </select>
                    <span class="hint">Inactive users cannot sign in but their history is kept.</span>
                </div>
                <div class="field">
                    <label for="password"><?= $editing ? 'Reset password' : 'Temporary password <span class="req">*</span>' ?></label>
                    <input class="input<?= has_error('password') ? ' invalid' : '' ?>" type="text" id="password" name="password" autocomplete="off" <?= $editing ? '' : 'required' ?>>
                    <span class="hint"><?= $editing ? 'Leave blank to keep the current password.' : 'Share this with the user securely.' ?> Minimum <?= (int) config('security.min_password_length') ?> characters with letters and numbers.</span>
                    <?= field_error('password') ?>
                </div>
                <div class="field">
                    <label>&nbsp;</label>
                    <label class="check"><input type="checkbox" name="must_change_password" value="1"<?= checked((bool) $v('must_change_password', $editing ? 0 : 1)) ?>> Require password change at next sign-in</label>
                </div>
            </div>
            <div class="form-actions">
                <a class="btn" href="<?= e(url('modules/users/index.php')) ?>">Cancel</a>
                <button class="btn btn-primary" type="submit"><?= $editing ? 'Save changes' : 'Create user' ?></button>
            </div>
        </form>
    </div>
</div>
<?php
render_footer();
