<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

Auth::require(['Admin']);

$q      = (string) input('q', '');
$role   = (string) input('role', '');
$status = (string) input('status', '');

$where  = ['1 = 1'];
$params = [];
if ($q !== '') {
    $where[]  = '(full_name LIKE ? OR email LIKE ? OR department LIKE ?)';
    $params[] = $params[] = $params[] = "%$q%";
}
if (in_array($role, ROLES, true)) {
    $where[]  = 'role = ?';
    $params[] = $role;
}
if (in_array($status, ['Active', 'Inactive'], true)) {
    $where[]  = 'status = ?';
    $params[] = $status;
}
$whereSql = implode(' AND ', $where);

$page  = paginate((int) DB::val("SELECT COUNT(*) FROM users WHERE $whereSql", $params), 15);
$users = DB::all(
    "SELECT user_id, full_name, email, role, department, status, last_login, (locked_until IS NOT NULL AND locked_until > NOW()) AS is_locked
       FROM users WHERE $whereSql ORDER BY full_name LIMIT {$page['perPage']} OFFSET {$page['offset']}",
    $params
);

render_header('User management', 'users', [
    'subtitle' => 'Create accounts and control who can do what',
    'actions'  => '<a class="btn btn-primary" href="' . e(url('modules/users/form.php')) . '">+ New user</a>',
]);
?>
<div class="card">
    <form class="filters" method="get">
        <div class="field grow"><label for="q">Search</label><input class="input" id="q" name="q" value="<?= e($q) ?>" placeholder="Name, email or department"></div>
        <div class="field"><label for="role">Role</label>
            <select class="input" id="role" name="role" data-autosubmit>
                <option value="">All roles</option>
                <?php foreach (ROLES as $r): ?><option<?= selected($role === $r) ?>><?= e($r) ?></option><?php endforeach; ?>
            </select></div>
        <div class="field"><label for="status">Status</label>
            <select class="input" id="status" name="status" data-autosubmit>
                <option value="">All</option>
                <option<?= selected($status === 'Active') ?>>Active</option>
                <option<?= selected($status === 'Inactive') ?>>Inactive</option>
            </select></div>
        <button class="btn" type="submit">Filter</button>
        <a class="btn" href="index.php">Reset</a>
    </form>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Department</th><th>Status</th><th>Last sign-in</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($users as $u): ?>
                <tr>
                    <td><strong><?= e($u['full_name']) ?></strong></td>
                    <td><?= e($u['email']) ?></td>
                    <td><span class="badge badge-role"><?= e($u['role']) ?></span></td>
                    <td><?= e($u['department'] ?: '—') ?></td>
                    <td><?= badge($u['status']) ?><?= (int) $u['is_locked'] ? ' ' . badge('locked', 'Locked') : '' ?></td>
                    <td class="nowrap"><?= e($u['last_login'] ? time_ago($u['last_login']) : 'Never') ?></td>
                    <td class="text-right"><a class="btn btn-sm" href="form.php?id=<?= (int) $u['user_id'] ?>">Edit</a></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$users): ?><tr><td colspan="7" class="table-empty">No users match your filters.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
    <?= pager($page) ?>
</div>
<?php
render_footer();
