<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

Auth::require(['Admin']);

$q        = (string) input('q', '');
$module   = (string) input('module', '');
$userId   = (int) input('user', 0);
$dateFrom = (string) input('from', '');
$dateTo   = (string) input('to', '');

$where  = ['1 = 1'];
$params = [];
if ($q !== '') {
    $where[]  = '(a.action LIKE ? OR a.description LIKE ?)';
    $params[] = $params[] = "%$q%";
}
if ($module !== '') {
    $where[]  = 'a.module = ?';
    $params[] = $module;
}
if ($userId > 0) {
    $where[]  = 'a.user_id = ?';
    $params[] = $userId;
}
if (Validator::isDate($dateFrom)) {
    $where[]  = 'a.created_at >= ?';
    $params[] = $dateFrom . ' 00:00:00';
}
if (Validator::isDate($dateTo)) {
    $where[]  = 'a.created_at <= ?';
    $params[] = $dateTo . ' 23:59:59';
}
$whereSql = implode(' AND ', $where);

$page = paginate((int) DB::val("SELECT COUNT(*) FROM audit_logs a WHERE $whereSql", $params), 25);
$logs = DB::all(
    "SELECT a.*, u.full_name, u.role FROM audit_logs a LEFT JOIN users u ON u.user_id = a.user_id
      WHERE $whereSql ORDER BY a.audit_id DESC LIMIT {$page['perPage']} OFFSET {$page['offset']}",
    $params
);
$modules = DB::all('SELECT DISTINCT module FROM audit_logs ORDER BY module');
$people  = DB::all('SELECT user_id, full_name FROM users ORDER BY full_name');

render_header('Audit log', 'audit', ['subtitle' => 'A permanent record of who did what, and when']);
?>
<div class="card">
    <form class="filters" method="get">
        <div class="field grow"><label for="q">Search</label><input class="input" id="q" name="q" value="<?= e($q) ?>" placeholder="Action or description"></div>
        <div class="field"><label for="module">Module</label>
            <select class="input" id="module" name="module">
                <option value="">All modules</option>
                <?php foreach ($modules as $m): ?><option<?= selected($module === $m['module']) ?>><?= e($m['module']) ?></option><?php endforeach; ?>
            </select></div>
        <div class="field"><label for="user">User</label>
            <select class="input" id="user" name="user">
                <option value="">Everyone</option>
                <?php foreach ($people as $p): ?><option value="<?= (int) $p['user_id'] ?>"<?= selected($userId === (int) $p['user_id']) ?>><?= e($p['full_name']) ?></option><?php endforeach; ?>
            </select></div>
        <div class="field"><label for="from">From</label><input class="input" type="date" id="from" name="from" value="<?= e($dateFrom) ?>"></div>
        <div class="field"><label for="to">To</label><input class="input" type="date" id="to" name="to" value="<?= e($dateTo) ?>"></div>
        <button class="btn btn-primary" type="submit">Filter</button>
        <a class="btn" href="index.php">Reset</a>
    </form>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Date &amp; time</th><th>User</th><th>Action</th><th>Module</th><th>Record</th><th>Details</th><th>IP address</th></tr></thead>
            <tbody>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td class="nowrap"><?= e(fdatetime($log['created_at'])) ?></td>
                    <td><?= e($log['full_name'] ?? 'System') ?><?= $log['role'] ? ' <small class="muted">(' . e($log['role']) . ')</small>' : '' ?></td>
                    <td><strong><?= e($log['action']) ?></strong></td>
                    <td><?= e($log['module']) ?></td>
                    <td><?= $log['record_id'] ? '#' . (int) $log['record_id'] : '—' ?></td>
                    <td><?= e($log['description']) ?></td>
                    <td class="muted"><?= e($log['ip_address']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$logs): ?><tr><td colspan="7" class="table-empty">No audit entries match your filters.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
    <?= pager($page) ?>
</div>
<?php
render_footer();
