# TransactPro — Phase 1: Secure Access & User Administration

Digital Financial Transaction and Approval System for **JESE**.

## What this phase delivers
| Area | Features |
| :--- | :--- |
| Authentication | Email + password login, session fixation protection, idle timeout (30 min), account lock-out after 5 failed attempts (15 min), generic error messages |
| Role-based access | Five roles — Admin, Staff, Manager, Finance, Director — enforced on every page |
| Users (Admin) | Create / edit / deactivate users, reset passwords, force password change at first sign-in, protection against removing the last administrator |
| Profile | Every user can change their own password |
| Audit trail | Every sign-in, failed attempt, user change and denied access is logged and searchable by the Admin |
| Dashboard | Role-aware welcome page; administrators see usage and security statistics |

## Install (XAMPP)
1. Copy this folder to `C:\xampp\htdocs\transactpro\phase1\`.
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. Open phpMyAdmin → **Import** → choose `database/schema.sql` → **Go**
   (this creates the database `transactpro_phase1` with demo users).
4. If your MySQL root user has a password, edit `app/config.php`.
5. Browse to `http://localhost/transactpro/phase1/`.

## Demo accounts — password for all: `password123`
| Role | Email |
| :--- | :--- |
| Admin | admin@transactpro.test |
| Staff | staff@transactpro.test, staff2@transactpro.test |
| Manager | manager@transactpro.test |
| Finance | finance@transactpro.test |
| Director | director@transactpro.test |

> Change these passwords (or delete the accounts) before any real use.

## Security design
* PDO prepared statements everywhere (no SQL injection).
* `password_hash()` / `password_verify()` — passwords are never stored in clear text.
* CSRF token verified automatically on **every** POST request.
* Output escaped with `e()`; strict Content-Security-Policy (no inline scripts).
* The `app/` and `database/` folders are blocked from the web by `.htaccess`.

## Code layout
```
app/        bootstrap, config, core classes (DB, Auth, Csrf, Audit, Validator), layout, widgets
assets/     css + js
modules/    users, audit
database/   schema.sql
```
Later phases add new folders/files on top of this one — nothing here is thrown away.
