-- TransactPro — Phase 1 database schema (cumulative)
-- Run in MySQL Workbench (File > Run SQL Script) or phpMyAdmin Import. Never drops anything: to start over, drop transactpro_phase1 yourself first

SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS transactpro_phase1 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE transactpro_phase1;

-- =====================================================================
-- Phase 1 — Authentication, users and audit trail
-- =====================================================================

CREATE TABLE users (
    user_id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    full_name            VARCHAR(100) NOT NULL,
    email                VARCHAR(100) NOT NULL,
    password_hash        VARCHAR(255) NOT NULL,
    role                 ENUM('Admin','Staff','Manager','Finance','Director') NOT NULL,
    phone                VARCHAR(20) NULL,
    department           VARCHAR(100) NULL,
    status               ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
    must_change_password TINYINT(1) NOT NULL DEFAULT 0,
    failed_attempts      TINYINT UNSIGNED NOT NULL DEFAULT 0,
    locked_until         DATETIME NULL,
    last_login           DATETIME NULL,
    created_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id),
    UNIQUE KEY uq_users_email (email),
    KEY idx_users_role_status (role, status)
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
    audit_id    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id     INT UNSIGNED NULL,
    action      VARCHAR(100) NOT NULL,
    module      VARCHAR(100) NOT NULL,
    record_id   INT UNSIGNED NULL,
    description TEXT NULL,
    ip_address  VARCHAR(45) NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (audit_id),
    KEY idx_audit_user (user_id),
    KEY idx_audit_module (module),
    KEY idx_audit_created (created_at),
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Demo accounts. Every account uses the password:  password123
INSERT INTO users (full_name, email, password_hash, role, phone, department, status) VALUES
('System Administrator', 'admin@transactpro.test',    '$2y$10$bnyUsWj.UgNBNzcK6nsuheTeu1n9Mjrr8KR0KceaO0gQGeh98cVq6', 'Admin',    '0700000001', 'IT',               'Active'),
('John Staff',           'staff@transactpro.test',    '$2y$10$bnyUsWj.UgNBNzcK6nsuheTeu1n9Mjrr8KR0KceaO0gQGeh98cVq6', 'Staff',    '0700000002', 'Field Operations', 'Active'),
('Grace Staff',          'staff2@transactpro.test',   '$2y$10$bnyUsWj.UgNBNzcK6nsuheTeu1n9Mjrr8KR0KceaO0gQGeh98cVq6', 'Staff',    '0700000006', 'Field Operations', 'Active'),
('Alice Manager',        'manager@transactpro.test',  '$2y$10$bnyUsWj.UgNBNzcK6nsuheTeu1n9Mjrr8KR0KceaO0gQGeh98cVq6', 'Manager',  '0700000003', 'Field Operations', 'Active'),
('Bob Finance',          'finance@transactpro.test',  '$2y$10$bnyUsWj.UgNBNzcK6nsuheTeu1n9Mjrr8KR0KceaO0gQGeh98cVq6', 'Finance',  '0700000004', 'Finance',          'Active'),
('Charlie Director',     'director@transactpro.test', '$2y$10$bnyUsWj.UgNBNzcK6nsuheTeu1n9Mjrr8KR0KceaO0gQGeh98cVq6', 'Director', '0700000005', 'Executive',        'Active');
