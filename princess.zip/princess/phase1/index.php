<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';

redirect(Auth::check() ? 'dashboard.php' : 'login.php');
