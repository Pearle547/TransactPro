/* TransactPro — global behaviour (no inline scripts are used anywhere, to keep the CSP strict). */
document.addEventListener('DOMContentLoaded', function () {
    var sidebar = document.getElementById('sidebar');
    var backdrop = document.getElementById('sidebar-backdrop');
    var toggle = document.getElementById('menu-toggle');

    function setMenu(open) {
        if (!sidebar) { return; }
        sidebar.classList.toggle('open', open);
        if (backdrop) { backdrop.classList.toggle('open', open); }
    }
    if (toggle) { toggle.addEventListener('click', function () { setMenu(!sidebar.classList.contains('open')); }); }
    if (backdrop) { backdrop.addEventListener('click', function () { setMenu(false); }); }

    // Ask for confirmation before submitting forms / clicking elements marked with data-confirm
    document.addEventListener('submit', function (event) {
        var message = event.target.getAttribute('data-confirm');
        if (message && !window.confirm(message)) { event.preventDefault(); }
    });
    document.addEventListener('click', function (event) {
        var el = event.target.closest('[data-confirm]');
        if (el && el.tagName !== 'FORM' && !window.confirm(el.getAttribute('data-confirm'))) { event.preventDefault(); }
    });

    // Print buttons (no inline handlers are allowed by the CSP)
    document.addEventListener('click', function (event) {
        if (event.target.closest('[data-print]')) { window.print(); }
    });

    // Prevent double submission
    document.querySelectorAll('form[data-once]').forEach(function (form) {
        form.addEventListener('submit', function () {
            form.querySelectorAll('button[type=submit]').forEach(function (b) { setTimeout(function () { b.disabled = true; }, 0); });
        });
    });

    // Auto-submit filter selects
    document.querySelectorAll('[data-autosubmit]').forEach(function (el) {
        el.addEventListener('change', function () { el.form.submit(); });
    });
});
