<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';

$user  = Auth::require();
$force = (int) $user['must_change_password'] === 1;

if (is_post()) {
    $current = (string) ($_POST['current_password'] ?? '');
    $new     = (string) ($_POST['new_password'] ?? '');
    $confirm = (string) ($_POST['confirm_password'] ?? '');
    $errors  = [];

    $hash = (string) DB::val('SELECT password_hash FROM users WHERE user_id = ?', [$user['user_id']]);
    if (!password_verify($current, $hash)) {
        $errors['current_password'] = 'Your current password is incorrect.';
    }
    if (($problem = Auth::passwordError($new)) !== null) {
        $errors['new_password'] = $problem;
    } elseif (password_verify($new, $hash)) {
        $errors['new_password'] = 'Choose a password different from your current one.';
    }
    if ($new !== $confirm) {
        $errors['confirm_password'] = 'The two passwords do not match.';
    }

    if ($errors) {
        remember_form([], $errors);
        redirect('profile.php' . ($force ? '?force=1' : ''));
    }

    DB::exec('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE user_id = ?', [password_hash($new, PASSWORD_DEFAULT), $user['user_id']]);
    Audit::log('Password changed', 'Authentication', (int) $user['user_id'], 'User changed their own password');
    session_regenerate_id(true);
    flash('success', 'Your password has been updated.');
    redirect('dashboard.php');
}

render_header('My profile', 'profile', ['subtitle' => 'Your account details and password']);
?>
<?php if ($force): ?>
    <div class="alert alert-warning">Your account uses a temporary password. Please set a new one to continue.</div>
<?php endif; ?>
<div class="grid grid-2">
    <div class="card">
        <div class="card-head"><h3>Account details</h3></div>
        <div class="card-body">
            <dl class="kv">
                <div><dt>Full name</dt><dd><?= e($user['full_name']) ?></dd></div>
                <div><dt>Role</dt><dd><span class="badge badge-role"><?= e($user['role']) ?></span></dd></div>
                <div><dt>Email</dt><dd><?= e($user['email']) ?></dd></div>
                <div><dt>Phone</dt><dd><?= e($user['phone'] ?: '—') ?></dd></div>
                <div><dt>Department</dt><dd><?= e($user['department'] ?: '—') ?></dd></div>
                <div><dt>Previous sign-in</dt><dd><?= e(fdatetime($user['last_login'])) ?></dd></div>
            </dl>
            <p class="hint mt">To change your name, email or role, contact the system administrator.</p>
        </div>
    </div>
    <div class="card">
        <div class="card-head"><h3>Change password</h3></div>
        <div class="card-body">
            <form method="post" data-once>
                <?= csrf_field() ?>
                <div class="field">
                    <label for="current_password">Current password</label>
                    <input class="input<?= has_error('current_password') ? ' invalid' : '' ?>" type="password" id="current_password" name="current_password" required autocomplete="current-password">
                    <?= field_error('current_password') ?>
                </div>
                <div class="field mt">
                    <label for="new_password">New password</label>
                    <input class="input<?= has_error('new_password') ? ' invalid' : '' ?>" type="password" id="new_password" name="new_password" required autocomplete="new-password">
                    <span class="hint">At least <?= (int) config('security.min_password_length') ?> characters, with letters and numbers.</span>
                    <?= field_error('new_password') ?>
                </div>
                <div class="field mt">
                    <label for="confirm_password">Confirm new password</label>
                    <input class="input<?= has_error('confirm_password') ? ' invalid' : '' ?>" type="password" id="confirm_password" name="confirm_password" required autocomplete="new-password">
                    <?= field_error('confirm_password') ?>
                </div>
                <div class="form-actions"><button class="btn btn-primary" type="submit">Update password</button></div>
            </form>
        </div>
    </div>
</div>
<?php
render_footer();
