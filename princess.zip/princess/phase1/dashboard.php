<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';

$user = Auth::require();

render_header('Dashboard', 'dashboard');

// Widgets are small self-contained files. Each phase of the system adds its own.
foreach (glob(APP_ROOT . '/app/widgets/*.php') ?: [] as $widget) {
    include $widget;
}

render_footer();
