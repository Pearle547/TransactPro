<?php
/** @var array $user */
$hour     = (int) date('G');
$greeting = $hour < 12 ? 'Good morning' : ($hour < 17 ? 'Good afternoon' : 'Good evening');
?>
<div class="card welcome">
    <div class="card-body">
        <h2><?= e($greeting) ?>, <?= e(explode(' ', $user['full_name'])[0]) ?>.</h2>
        <p><?= e(role_description($user['role'])) ?></p>
        <div class="meta">
            Signed in as <strong><?= e($user['role']) ?></strong><?= $user['department'] ? ' · ' . e($user['department']) : '' ?>
            · Previous sign-in: <?= e(fdatetime($user['last_login'])) ?>
        </div>
    </div>
</div>
