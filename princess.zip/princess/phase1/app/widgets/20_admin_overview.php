<?php
if (!Auth::is('Admin')) {
    return;
}

$activeUsers   = (int) DB::val("SELECT COUNT(*) FROM users WHERE status = 'Active'");
$inactiveUsers = (int) DB::val("SELECT COUNT(*) FROM users WHERE status = 'Inactive'");
$logins7d      = (int) DB::val("SELECT COUNT(*) FROM audit_logs WHERE action = 'Login' AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$failed7d      = (int) DB::val("SELECT COUNT(*) FROM audit_logs WHERE action IN ('Login failed','Account locked') AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$byRole        = DB::all("SELECT role, COUNT(*) AS total FROM users WHERE status = 'Active' GROUP BY role ORDER BY total DESC");
$recent        = DB::all('SELECT a.*, u.full_name FROM audit_logs a LEFT JOIN users u ON u.user_id = a.user_id ORDER BY a.audit_id DESC LIMIT 8');
?>
<div class="stats">
    <div class="stat"><div class="stat-label">Active users</div><div class="stat-value"><?= $activeUsers ?></div><div class="stat-note"><?= $inactiveUsers ?> inactive</div></div>
    <div class="stat ok"><div class="stat-label">Sign-ins (7 days)</div><div class="stat-value"><?= $logins7d ?></div><div class="stat-note">Successful logins</div></div>
    <div class="stat <?= $failed7d > 0 ? 'warn' : 'accent' ?>"><div class="stat-label">Failed sign-ins (7 days)</div><div class="stat-value"><?= $failed7d ?></div><div class="stat-note">Wrong passwords &amp; lockouts</div></div>
</div>

<div class="grid grid-main">
    <div class="card">
        <div class="card-head"><h3>Recent system activity</h3><a class="btn btn-sm" href="<?= e(url('modules/audit/index.php')) ?>">Full audit log</a></div>
        <div class="card-body flush table-wrap">
            <table class="table">
                <thead><tr><th>When</th><th>User</th><th>Action</th><th>Details</th></tr></thead>
                <tbody>
                <?php foreach ($recent as $row): ?>
                    <tr>
                        <td class="nowrap"><?= e(time_ago($row['created_at'])) ?></td>
                        <td><?= e($row['full_name'] ?? 'System') ?></td>
                        <td><?= e($row['action']) ?></td>
                        <td><?= e($row['description']) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$recent): ?><tr><td colspan="4" class="table-empty">No activity recorded yet.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card">
        <div class="card-head"><h3>Users by role</h3><a class="btn btn-sm" href="<?= e(url('modules/users/index.php')) ?>">Manage</a></div>
        <div class="card-body flush table-wrap">
            <table class="table">
                <tbody>
                <?php foreach ($byRole as $row): ?>
                    <tr><td><span class="badge badge-role"><?= e($row['role']) ?></span></td><td class="num"><?= (int) $row['total'] ?></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
