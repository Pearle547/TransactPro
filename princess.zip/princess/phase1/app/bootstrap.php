<?php
declare(strict_types=1);

/**
 * Application bootstrap. Every page includes this file first.
 */

define('APP_ROOT', dirname(__DIR__));

date_default_timezone_set('Africa/Kampala');

$GLOBALS['config'] = require __DIR__ . '/config.php';

require_once __DIR__ . '/core/helpers.php';
require_once __DIR__ . '/core/Database.php';
require_once __DIR__ . '/core/Auth.php';
require_once __DIR__ . '/core/Csrf.php';
require_once __DIR__ . '/core/Audit.php';
require_once __DIR__ . '/core/Validator.php';
require_once __DIR__ . '/core/layout.php';

// Domain services. Each phase of the system adds its own files here.
foreach (glob(__DIR__ . '/services/*.php') ?: [] as $service) {
    require_once $service;
}

ini_set('display_errors', config('debug') ? '1' : '0');
error_reporting(E_ALL);

set_exception_handler(static function (Throwable $e): void {
    error_log((string) $e);
    if (config('debug')) {
        http_response_code(500);
        echo '<pre>' . e((string) $e) . '</pre>';
        return;
    }
    abort(500, 'An unexpected error occurred. Please try again or contact the system administrator.');
});

header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'self'");

Auth::start();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    Csrf::verify();
}
