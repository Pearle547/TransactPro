<?php
declare(strict_types=1);

/**
 * Page chrome: sidebar, top bar, flash messages and guest (signed-out) pages.
 */

/** Navigation entries visible to the current user. A link only appears if its target page exists in this phase. */
function nav_sections(): array
{
    $role     = Auth::role();
    $sections = require APP_ROOT . '/app/nav.php';
    $visible  = [];
    foreach ($sections as $section) {
        $items = [];
        foreach ($section['items'] as [$title, $path, $icon, $roles, $key]) {
            if (!is_file(APP_ROOT . '/' . strtok($path, '?'))) {
                continue;
            }
            if ($roles !== null && !in_array($role, $roles, true)) {
                continue;
            }
            $badge = function_exists('nav_badge_' . $key) ? (int) ('nav_badge_' . $key)() : 0;
            $items[] = compact('title', 'path', 'icon', 'key', 'badge');
        }
        if ($items) {
            $visible[] = ['label' => $section['label'], 'items' => $items];
        }
    }
    return $visible;
}

/**
 * Render the top of a signed-in page.
 *
 * @param array{subtitle?: string, actions?: string} $opts
 */
function render_header(string $title, string $active = '', array $opts = []): void
{
    $user   = Auth::user();
    $unread = class_exists('Notify') ? Notify::unreadCount((int) $user['user_id']) : null;
    $initials = '';
    foreach (array_slice(preg_split('/\s+/', trim($user['full_name'])) ?: [], 0, 2) as $part) {
        $initials .= mb_strtoupper(mb_substr($part, 0, 1));
    }
    ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title) ?> · <?= e(config('app_name')) ?></title>
    <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>
<body>
<div class="app">
    <aside class="sidebar" id="sidebar">
        <a class="brand" href="<?= e(url('dashboard.php')) ?>">
            <span class="brand-mark">T</span>
            <span><strong><?= e(config('app_name')) ?></strong><small><?= e(config('org_name')) ?></small></span>
        </a>
        <nav class="nav" aria-label="Main navigation">
            <?php foreach (nav_sections() as $section): ?>
                <div class="nav-label"><?= e($section['label']) ?></div>
                <?php foreach ($section['items'] as $item): ?>
                    <a class="nav-link<?= $item['key'] === $active ? ' active' : '' ?>" href="<?= e(url($item['path'])) ?>">
                        <?= icon($item['icon']) ?><span><?= e($item['title']) ?></span>
                        <?php if ($item['badge'] > 0): ?><em class="nav-badge"><?= $item['badge'] ?></em><?php endif; ?>
                    </a>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </nav>
    </aside>
    <div class="sidebar-backdrop" id="sidebar-backdrop"></div>

    <div class="main">
        <header class="topbar">
            <button class="icon-btn menu-btn" id="menu-toggle" type="button" aria-label="Toggle navigation"><?= icon('menu') ?></button>
            <div class="topbar-title">
                <h1><?= e($title) ?></h1>
                <?php if (!empty($opts['subtitle'])): ?><p><?= e($opts['subtitle']) ?></p><?php endif; ?>
            </div>
            <div class="topbar-right">
                <?php if ($unread !== null): ?>
                    <a class="icon-btn bell" href="<?= e(url('modules/notifications/index.php')) ?>" aria-label="Notifications">
                        <?= icon('bell') ?><?php if ($unread > 0): ?><em><?= $unread > 99 ? '99+' : $unread ?></em><?php endif; ?>
                    </a>
                <?php endif; ?>
                <a class="user-chip" href="<?= e(url('profile.php')) ?>" title="My profile">
                    <span class="avatar"><?= e($initials) ?></span>
                    <span class="user-chip-text"><strong><?= e($user['full_name']) ?></strong><small><?= e($user['role']) ?></small></span>
                </a>
                <form method="post" action="<?= e(url('logout.php')) ?>">
                    <?= csrf_field() ?>
                    <button class="icon-btn" type="submit" title="Sign out" aria-label="Sign out"><?= icon('logout') ?></button>
                </form>
            </div>
        </header>

        <main class="content">
            <?php foreach (take_flashes() as [$type, $message]): ?>
                <div class="alert alert-<?= e($type) ?>" role="alert"><?= e($message) ?></div>
            <?php endforeach; ?>
            <?php if (!empty($opts['actions'])): ?>
                <div class="page-actions"><?= $opts['actions'] ?></div>
            <?php endif; ?>
<?php
}

function render_footer(array $scripts = []): void
{
    ?>
        </main>
        <footer class="footer">&copy; <?= date('Y') ?> <?= e(config('org_name')) ?> · <?= e(config('app_name')) ?> Digital Financial Transaction &amp; Approval System</footer>
    </div>
</div>
<script src="<?= e(asset('js/app.js')) ?>"></script>
<?php foreach ($scripts as $script): ?>
<script src="<?= e(asset('js/' . $script)) ?>"></script>
<?php endforeach; ?>
</body>
</html>
<?php
}

function render_guest_header(string $title): void
{
    ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title) ?> · <?= e(config('app_name')) ?></title>
    <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>
<body class="guest">
<?php
}

function render_guest_footer(): void
{
    ?>
</body>
</html>
<?php
}
