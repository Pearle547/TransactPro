<?php
declare(strict_types=1);

/**
 * Minimal server-side validator.
 *
 * Rules are pipe separated: required|email|max:100|min:8|in:a,b|numeric|min_value:1|max_value:9|date|same:other
 */
final class Validator
{
    /** @return array<string, string> field => first error message */
    public static function validate(array $data, array $rules, array $labels = []): array
    {
        $errors = [];
        foreach ($rules as $field => $ruleString) {
            $label = $labels[$field] ?? ucfirst(str_replace('_', ' ', $field));
            $value = $data[$field] ?? '';
            $value = is_string($value) ? trim($value) : $value;
            $isEmpty = $value === '' || $value === null;

            foreach (explode('|', $ruleString) as $rule) {
                [$name, $arg] = array_pad(explode(':', $rule, 2), 2, null);

                if ($name === 'required') {
                    if ($isEmpty) {
                        $errors[$field] = "$label is required.";
                        break;
                    }
                    continue;
                }
                if ($isEmpty) {
                    continue;   // optional field left blank
                }

                $error = match ($name) {
                    'email'     => filter_var($value, FILTER_VALIDATE_EMAIL) ? null : "$label must be a valid email address.",
                    'max'       => mb_strlen((string) $value) <= (int) $arg ? null : "$label must not exceed $arg characters.",
                    'min'       => mb_strlen((string) $value) >= (int) $arg ? null : "$label must be at least $arg characters.",
                    'numeric'   => is_numeric($value) ? null : "$label must be a number.",
                    'min_value' => (is_numeric($value) && (float) $value >= (float) $arg) ? null : "$label must be at least " . number_format((float) $arg) . '.',
                    'max_value' => (is_numeric($value) && (float) $value <= (float) $arg) ? null : "$label must not exceed " . number_format((float) $arg) . '.',
                    'in'        => in_array((string) $value, explode(',', (string) $arg), true) ? null : "$label has an invalid value.",
                    'date'      => self::isDate((string) $value) ? null : "$label must be a valid date.",
                    'same'      => $value === ($data[$arg] ?? null) ? null : "$label does not match.",
                    default     => null,
                };
                if ($error !== null) {
                    $errors[$field] = $error;
                    break;
                }
            }
        }
        return $errors;
    }

    public static function isDate(string $value): bool
    {
        $d = DateTime::createFromFormat('Y-m-d', $value);
        return $d !== false && $d->format('Y-m-d') === $value;
    }
}
