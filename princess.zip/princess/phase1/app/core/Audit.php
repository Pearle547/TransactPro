<?php
declare(strict_types=1);

/**
 * Audit trail. Every significant action is recorded with the user who performed it.
 */
final class Audit
{
    public static function log(string $action, string $module, ?int $recordId, string $description, ?int $userId = null): void
    {
        DB::run(
            'INSERT INTO audit_logs (user_id, action, module, record_id, description, ip_address) VALUES (?, ?, ?, ?, ?, ?)',
            [$userId ?? Auth::id(), $action, $module, $recordId, $description, $_SERVER['REMOTE_ADDR'] ?? '']
        );
    }
}
