<?php
declare(strict_types=1);

/**
 * General purpose helper functions.
 */

const ROLES = ['Admin', 'Staff', 'Manager', 'Finance', 'Director'];

function config(string $key, mixed $default = null): mixed
{
    $value = $GLOBALS['config'];
    foreach (explode('.', $key) as $part) {
        if (!is_array($value) || !array_key_exists($part, $value)) {
            return $default;
        }
        $value = $value[$part];
    }
    return $value;
}

/** Escape a value for safe HTML output. */
function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** URL path of the application folder relative to the web root (e.g. "/transactpro/phase1"). */
function base_path(): string
{
    static $base = null;
    if ($base !== null) {
        return $base;
    }
    $docRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
    $root    = realpath(APP_ROOT) ?: '';
    $base    = '';
    if ($docRoot !== '' && $root !== '' && stripos($root, $docRoot) === 0) {
        $base = rtrim(str_replace('\\', '/', substr($root, strlen($docRoot))), '/');
    }
    return $base;
}

function url(string $path = ''): string
{
    return base_path() . '/' . ltrim($path, '/');
}

function asset(string $path): string
{
    return url('assets/' . ltrim($path, '/')) . '?v=' . config('version');
}

function redirect(string $path): never
{
    header('Location: ' . url($path));
    exit;
}

function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

/** Trimmed request value (POST first, then GET). */
function input(string $key, mixed $default = null): mixed
{
    $value = $_POST[$key] ?? $_GET[$key] ?? $default;
    return is_string($value) ? trim($value) : $value;
}

/** Path of the current request relative to the application folder, e.g. "/modules/users/index.php?page=2". */
function current_path(): string
{
    $uri  = $_SERVER['REQUEST_URI'] ?? '/';
    $base = base_path();
    return ($base !== '' && str_starts_with($uri, $base)) ? substr($uri, strlen($base)) : $uri;
}

/** Accept only simple application-relative paths for post-login redirects. */
function safe_next(?string $next): ?string
{
    if ($next !== null && preg_match('#^/[A-Za-z0-9_\-./?=&%]*$#', $next) && !str_starts_with($next, '//')) {
        return ltrim($next, '/');
    }
    return null;
}

/* ---------------------------------------------------------------- flash messages & form state */

function flash(string $type, string $message): void
{
    $_SESSION['_flash'][] = [$type, $message];
}

function take_flashes(): array
{
    $messages = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return $messages;
}

/** Remember submitted values and validation errors across a redirect. */
function remember_form(array $old, array $errors): void
{
    $_SESSION['_form'] = ['old' => $old, 'errors' => $errors];
}

function form_state(): array
{
    static $state = null;
    if ($state === null) {
        $state = $_SESSION['_form'] ?? ['old' => [], 'errors' => []];
        unset($_SESSION['_form']);
    }
    return $state;
}

function old(string $key, mixed $default = ''): mixed
{
    $state = form_state();
    return array_key_exists($key, $state['old']) ? $state['old'][$key] : $default;
}

function field_error(string $key): string
{
    $error = form_state()['errors'][$key] ?? null;
    return $error ? '<span class="error-text">' . e($error) . '</span>' : '';
}

function has_error(string $key): bool
{
    return isset(form_state()['errors'][$key]);
}

/* ---------------------------------------------------------------- formatting */

function money(mixed $amount, string $currency = 'UGX'): string
{
    return $currency . ' ' . number_format((float) $amount, 0);
}

function fdate(?string $date): string
{
    return $date ? date('d M Y', strtotime($date)) : '—';
}

function fdatetime(?string $date): string
{
    return $date ? date('d M Y, H:i', strtotime($date)) : '—';
}

function time_ago(?string $date): string
{
    if (!$date) {
        return '—';
    }
    $seconds = max(0, time() - strtotime($date));
    return match (true) {
        $seconds < 60     => 'just now',
        $seconds < 3600   => floor($seconds / 60) . ' min ago',
        $seconds < 86400  => floor($seconds / 3600) . ' h ago',
        $seconds < 604800 => floor($seconds / 86400) . ' d ago',
        default           => fdate($date),
    };
}

function status_label(string $status): string
{
    return str_replace('_', ' ', $status);
}

function badge(string $status, ?string $label = null): string
{
    $slug = strtolower(str_replace('_', '-', $status));
    return '<span class="badge badge-' . e($slug) . '">' . e($label ?? status_label($status)) . '</span>';
}

function selected(bool $condition): string
{
    return $condition ? ' selected' : '';
}

function checked(bool $condition): string
{
    return $condition ? ' checked' : '';
}

function role_description(string $role): string
{
    return match ($role) {
        'Admin'    => 'Manage users, projects, budgets and system settings, and review the audit trail.',
        'Staff'    => 'Plan activities, request funds, and account for money you have received.',
        'Manager'  => 'Review financial plans and fund requests submitted by your team.',
        'Finance'  => 'Review plans and requests, control budgets, process payments and verify accountabilities.',
        'Director' => 'Give final approval to high-value requests and oversee organisational spending.',
        default    => '',
    };
}

/* ---------------------------------------------------------------- pagination */

function paginate(int $total, int $perPage = 15): array
{
    $pages = max(1, (int) ceil($total / $perPage));
    $page  = min(max(1, (int) ($_GET['page'] ?? 1)), $pages);
    return ['page' => $page, 'perPage' => $perPage, 'offset' => ($page - 1) * $perPage, 'pages' => $pages, 'total' => $total];
}

function pager(array $p): string
{
    if ($p['pages'] <= 1) {
        return '';
    }
    $link = static function (int $page, string $label, bool $active = false, bool $disabled = false): string {
        if ($disabled) {
            return '<span class="disabled">' . $label . '</span>';
        }
        $query = http_build_query(array_merge($_GET, ['page' => $page]));
        return '<a href="?' . e($query) . '"' . ($active ? ' class="active"' : '') . '>' . $label . '</a>';
    };
    $html = '<nav class="pager" aria-label="Pagination">';
    $html .= $link($p['page'] - 1, '&laquo; Prev', false, $p['page'] <= 1);
    $start = max(1, $p['page'] - 2);
    $end   = min($p['pages'], $p['page'] + 2);
    for ($i = $start; $i <= $end; $i++) {
        $html .= $link($i, (string) $i, $i === $p['page']);
    }
    $html .= $link($p['page'] + 1, 'Next &raquo;', false, $p['page'] >= $p['pages']);
    return $html . '<span class="pager-info">' . number_format($p['total']) . ' records</span></nav>';
}

/* ---------------------------------------------------------------- icons */

function icon(string $name): string
{
    static $paths = [
        'home'      => '<path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
        'users'     => '<circle cx="9" cy="8" r="4"/><path d="M2 21c0-4 3-7 7-7s7 3 7 7"/><path d="M17 4a4 4 0 0 1 0 8M22 21c0-3-2-5-4-6"/>',
        'user'      => '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-7 8-7s8 3 8 7"/>',
        'folder'    => '<path d="M3 6a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
        'wallet'    => '<rect x="3" y="6" width="18" height="14" rx="2"/><path d="M3 10h18M16 15h2"/>',
        'file'      => '<path d="M6 2h8l5 5v15H6z"/><path d="M14 2v5h5M9 13h6M9 17h6"/>',
        'send'      => '<path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/>',
        'check'     => '<circle cx="12" cy="12" r="10"/><path d="M8 12l3 3 5-6"/>',
        'card'      => '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/>',
        'receipt'   => '<path d="M5 2h14v20l-3-2-2 2-2-2-2 2-2-2-3 2z"/><path d="M9 7h6M9 11h6"/>',
        'chart'     => '<path d="M3 3v18h18"/><path d="M7 15l4-5 3 3 5-7"/>',
        'shield'    => '<path d="M12 2l8 3v6c0 5-3.5 9-8 11-4.5-2-8-6-8-11V5z"/>',
        'bell'      => '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 8 3 8H3s3-1 3-8"/><path d="M10 21a2 2 0 0 0 4 0"/>',
        'settings'  => '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
        'logout'    => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
        'clipboard' => '<rect x="5" y="4" width="14" height="18" rx="2"/><path d="M9 2h6v4H9zM9 12h6M9 16h6"/>',
        'menu'      => '<path d="M3 6h18M3 12h18M3 18h18"/>',
        'download'  => '<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',
    ];
    return '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
        . ($paths[$name] ?? '') . '</svg>';
}

/* ---------------------------------------------------------------- errors */

function abort(int $code, string $message = ''): never
{
    http_response_code($code);
    $titles = [403 => 'Access denied', 404 => 'Page not found', 419 => 'Request could not be verified', 500 => 'Something went wrong'];
    $title  = $titles[$code] ?? 'Error';
    $defaults = [
        403 => 'You do not have permission to view this page.',
        404 => 'The page or record you are looking for does not exist.',
        419 => 'Your session may have expired, or the upload was too large. Please go back, refresh the page and try again.',
    ];
    $message = $message !== '' ? $message : ($defaults[$code] ?? '');

    $signedIn = false;
    try {
        $signedIn = Auth::check();
    } catch (Throwable) {
    }

    if ($signedIn) {
        render_header($title);
        echo '<div class="card"><div class="card-body empty"><h2>' . e($code . ' — ' . $title) . '</h2><p>' . e($message) . '</p>'
            . '<a class="btn btn-primary" href="' . e(url('dashboard.php')) . '">Back to dashboard</a></div></div>';
        render_footer();
    } else {
        render_guest_header($title);
        echo '<div class="guest-card"><h1>' . e($title) . '</h1><p>' . e($message) . '</p>'
            . '<a class="btn btn-primary" href="' . e(url('login.php')) . '">Go to sign in</a></div>';
        render_guest_footer();
    }
    exit;
}

function json_response(mixed $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}
