<?php
declare(strict_types=1);

/**
 * Authentication, session handling and role-based access control.
 */
final class Auth
{
    private static ?array $user = null;
    private static bool $userLoaded = false;

    public static function start(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        ini_set('session.use_strict_mode', '1');
        session_name((string) config('session.name'));
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => base_path() . '/',
            'httponly' => true,
            'samesite' => 'Lax',
            'secure'   => $https,
        ]);
        session_start();

        $idle = (int) config('session.idle_timeout');
        if (isset($_SESSION['uid'], $_SESSION['last_seen']) && time() - (int) $_SESSION['last_seen'] > $idle) {
            self::destroy();
            session_start();
            $_SESSION['_timed_out'] = true;
        }
        $_SESSION['last_seen'] = time();
    }

    /** Attempt a login. Returns an error message, or null on success. */
    public static function attempt(string $email, string $password): ?string
    {
        $generic = 'Invalid email or password.';
        $user = DB::row(
            'SELECT *, (locked_until IS NOT NULL AND locked_until > NOW()) AS is_locked FROM users WHERE email = ?',
            [strtolower(trim($email))]
        );
        if ($user === null) {
            return $generic;
        }
        if ((int) $user['is_locked'] === 1) {
            Audit::log('Login blocked', 'Authentication', (int) $user['user_id'], 'Sign-in attempt on a locked account', (int) $user['user_id']);
            return 'This account is temporarily locked after too many failed attempts. Please try again later.';
        }

        if (!password_verify($password, $user['password_hash'])) {
            $max      = (int) config('security.max_failed_logins');
            $minutes  = (int) config('security.lockout_minutes');
            $failures = (int) $user['failed_attempts'] + 1;
            if ($failures >= $max) {
                DB::exec('UPDATE users SET failed_attempts = 0, locked_until = DATE_ADD(NOW(), INTERVAL ' . $minutes . ' MINUTE) WHERE user_id = ?', [$user['user_id']]);
                Audit::log('Account locked', 'Authentication', (int) $user['user_id'], "Account locked after $max failed sign-in attempts", (int) $user['user_id']);
            } else {
                DB::exec('UPDATE users SET failed_attempts = ? WHERE user_id = ?', [$failures, $user['user_id']]);
                Audit::log('Login failed', 'Authentication', (int) $user['user_id'], 'Incorrect password', (int) $user['user_id']);
            }
            return $generic;
        }

        if ($user['status'] !== 'Active') {
            return 'This account has been deactivated. Please contact the system administrator.';
        }

        session_regenerate_id(true);
        $_SESSION['uid']       = (int) $user['user_id'];
        $_SESSION['last_seen'] = time();
        DB::exec('UPDATE users SET failed_attempts = 0, locked_until = NULL, last_login = NOW() WHERE user_id = ?', [$user['user_id']]);
        Audit::log('Login', 'Authentication', (int) $user['user_id'], 'User signed in', (int) $user['user_id']);
        self::$userLoaded = false;
        return null;
    }

    public static function logout(): void
    {
        if (self::check()) {
            Audit::log('Logout', 'Authentication', self::id(), 'User signed out');
        }
        self::destroy();
    }

    private static function destroy(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', ['expires' => time() - 3600, 'path' => $p['path'], 'httponly' => true, 'samesite' => 'Lax']);
        }
        session_destroy();
        self::$user       = null;
        self::$userLoaded = false;
    }

    /** The signed-in user, re-read from the database on every request so role/status changes apply immediately. */
    public static function user(): ?array
    {
        if (!self::$userLoaded) {
            self::$userLoaded = true;
            self::$user = null;
            if (!empty($_SESSION['uid'])) {
                $user = DB::row(
                    'SELECT user_id, full_name, email, role, phone, department, status, must_change_password, last_login
                       FROM users WHERE user_id = ?',
                    [$_SESSION['uid']]
                );
                if ($user !== null && $user['status'] === 'Active') {
                    self::$user = $user;
                } else {
                    unset($_SESSION['uid']);
                }
            }
        }
        return self::$user;
    }

    public static function check(): bool
    {
        return self::user() !== null;
    }

    public static function id(): ?int
    {
        $user = self::user();
        return $user ? (int) $user['user_id'] : null;
    }

    public static function role(): ?string
    {
        return self::user()['role'] ?? null;
    }

    public static function is(string ...$roles): bool
    {
        return in_array(self::role(), $roles, true);
    }

    /** Require a signed-in user, optionally restricted to the given roles. */
    public static function require(array $roles = []): array
    {
        $user = self::user();
        if ($user === null) {
            $next = urlencode(current_path());
            redirect('login.php' . (is_post() ? '' : '?next=' . $next));
        }
        if ((int) $user['must_change_password'] === 1 && basename($_SERVER['SCRIPT_NAME']) !== 'profile.php') {
            flash('warning', 'You must change your temporary password before continuing.');
            redirect('profile.php?force=1');
        }
        if ($roles && !in_array($user['role'], $roles, true)) {
            Audit::log('Access denied', 'Authorization', null, 'Attempted to open ' . current_path() . ' without permission');
            abort(403);
        }
        return $user;
    }

    /** Returns an error message if the password is too weak, otherwise null. */
    public static function passwordError(string $password): ?string
    {
        $min = (int) config('security.min_password_length');
        if (strlen($password) < $min) {
            return "Password must be at least $min characters long.";
        }
        if (!preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
            return 'Password must contain both letters and numbers.';
        }
        return null;
    }
}
