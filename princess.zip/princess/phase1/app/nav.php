<?php
/**
 * Sidebar navigation.
 *
 * Each item: [title, path, icon, allowed roles (null = everyone), active key].
 * An item is shown only when the page exists in the current phase and the user's role is allowed.
 * A function named nav_badge_{key}() may be defined by a service to show a counter next to an item.
 */
$all = null;
$finance = ['Admin', 'Finance'];

return [
    ['label' => 'Overview', 'items' => [
        ['Dashboard', 'dashboard.php', 'home', $all, 'dashboard'],
        ['Notifications', 'modules/notifications/index.php', 'bell', $all, 'notifications'],
    ]],
    ['label' => 'Planning', 'items' => [
        ['Projects', 'modules/projects/index.php', 'folder', $all, 'projects'],
        ['Budget lines', 'modules/budgets/index.php', 'wallet', ['Admin', 'Finance', 'Manager', 'Director'], 'budgets'],
        ['Financial plans', 'modules/plans/index.php', 'file', $all, 'plans'],
    ]],
    ['label' => 'Funds', 'items' => [
        ['Fund requests', 'modules/requests/index.php', 'send', $all, 'requests'],
        ['Approvals', 'modules/approvals/index.php', 'check', ['Admin', 'Manager', 'Finance', 'Director'], 'approvals'],
        ['Payments', 'modules/payments/index.php', 'card', ['Admin', 'Finance', 'Director'], 'payments'],
    ]],
    ['label' => 'Accountability', 'items' => [
        ['Accountabilities', 'modules/accountabilities/index.php', 'clipboard', $all, 'accountabilities'],
        ['Expenditure', 'modules/expenditures/index.php', 'receipt', $all, 'expenditures'],
    ]],
    ['label' => 'Insights', 'items' => [
        ['Reports', 'modules/reports/index.php', 'chart', ['Admin', 'Finance', 'Director'], 'reports'],
    ]],
    ['label' => 'Administration', 'items' => [
        ['Users', 'modules/users/index.php', 'users', ['Admin'], 'users'],
        ['Audit log', 'modules/audit/index.php', 'shield', ['Admin'], 'audit'],
        ['Settings', 'modules/settings/index.php', 'settings', ['Admin'], 'settings'],
    ]],
];
