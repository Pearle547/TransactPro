<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';

if (is_post()) {
    Auth::logout();
    Auth::start();
    flash('success', 'You have been signed out.');
}
redirect('login.php');
