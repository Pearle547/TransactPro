<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';

if (Auth::check()) {
    redirect('dashboard.php');
}

$error = null;
$email = '';

if (is_post()) {
    $email = (string) input('email', '');
    $error = Auth::attempt($email, (string) ($_POST['password'] ?? ''));
    if ($error === null) {
        redirect(safe_next($_GET['next'] ?? null) ?? 'dashboard.php');
    }
}

$timedOut = !empty($_SESSION['_timed_out']);
unset($_SESSION['_timed_out']);

render_guest_header('Sign in');
?>
<div class="login-wrap">
    <section class="login-art">
        <div class="brand">
            <span class="brand-mark">T</span>
            <span><strong><?= e(config('app_name')) ?></strong><small><?= e(config('org_name')) ?></small></span>
        </div>
        <div>
            <h2>One place for every shilling, from plan to proof of spend.</h2>
            <p>Digital financial planning, fund requests, multi-level approvals and accountability — with a complete audit trail.</p>
            <ul>
                <li>Role-based access for every officer</li>
                <li>Budget and approval controls enforced by the system</li>
                <li>Every action traced to the person responsible</li>
            </ul>
        </div>
        <small>&copy; <?= date('Y') ?> <?= e(config('org_name')) ?>. Authorised users only — activity is monitored.</small>
    </section>

    <section class="login-panel">
        <div class="login-box">
            <h1>Welcome back</h1>
            <p class="muted">Sign in to your <?= e(config('app_name')) ?> account.</p>

            <?php if ($timedOut): ?>
                <div class="alert alert-warning">You were signed out after a period of inactivity. Please sign in again.</div>
            <?php endif; ?>
            <?php foreach (take_flashes() as [$type, $message]): ?>
                <div class="alert alert-<?= e($type) ?>"><?= e($message) ?></div>
            <?php endforeach; ?>
            <?php if ($error): ?>
                <div class="alert alert-error" role="alert"><?= e($error) ?></div>
            <?php endif; ?>

            <form method="post" autocomplete="on" data-once>
                <?= csrf_field() ?>
                <div class="field">
                    <label for="email">Email address</label>
                    <input class="input" type="email" id="email" name="email" value="<?= e($email) ?>" required autofocus autocomplete="username">
                </div>
                <div class="field mt">
                    <label for="password">Password</label>
                    <input class="input" type="password" id="password" name="password" required autocomplete="current-password">
                </div>
                <button class="btn btn-primary mt" type="submit" style="width:100%">Sign in</button>
            </form>
            <p class="hint mt">Forgot your password? Ask the system administrator to reset it for you.</p>
        </div>
    </section>
</div>
<?php
render_guest_footer();
