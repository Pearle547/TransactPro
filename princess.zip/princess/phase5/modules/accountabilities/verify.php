<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

Auth::require(['Finance']);
if (!is_post()) {
    redirect('modules/accountabilities/index.php');
}

$id       = (int) ($_POST['accountability_id'] ?? 0);
$comments = (string) ($_POST['comments'] ?? '');

try {
    switch ((string) ($_POST['action'] ?? '')) {
        case 'verify':
            Verification::verify($id, $comments);
            flash('success', 'Accountability verified. The request is now closed and any unspent balance has been released to the budget line.');
            break;
        case 'return':
            Verification::returnForCorrection($id, $comments);
            flash('success', 'The accountability was returned to the requester for correction.');
            break;
        default:
            throw new DomainException('Unknown action.');
    }
} catch (DomainException $e) {
    flash('error', $e->getMessage());
}
redirect('modules/accountabilities/view.php?id=' . $id);
