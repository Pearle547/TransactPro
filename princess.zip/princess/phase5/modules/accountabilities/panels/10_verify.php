<?php
/** @var array $acc @var array $items @var array $user @var int $id */
if (!Verification::canReview($acc, $user)) {
    return;
}
$problems = Accountabilities::problems($acc, $items);
$receipts = count(array_filter($items, static fn (array $i): bool => (bool) $i['receipt_path']));
?>
<div class="card">
    <div class="card-head"><h3>Finance verification</h3></div>
    <div class="card-body">
        <ul style="margin:0 0 1rem 1.1rem;padding:0">
            <li>Receipts attached: <strong><?= $receipts ?> of <?= count($items) ?></strong> item(s) <?= $receipts === count($items) ? '✓' : '✗' ?></li>
            <li>Reconciliation: <?= e(money($acc['total_spent'])) ?> spent + <?= e(money($acc['balance_returned'])) ?> returned = <?= e(money((float) $acc['total_spent'] + (float) $acc['balance_returned'])) ?>
                (received <?= e(money($acc['amount_received'])) ?>) <?= $problems ? '✗' : '✓' ?></li>
        </ul>
        <?php if ($problems): ?>
            <div class="alert alert-error">This accountability has problems and cannot be verified: <?= e(implode(' ', $problems)) ?></div>
        <?php endif; ?>
        <p class="hint">Open each receipt and confirm it supports the amount claimed. Verifying closes the request and releases <?= e(money((float) $acc['amount_received'] - (float) $acc['total_spent'])) ?> back to the budget line.</p>
        <form method="post" action="verify.php" data-once>
            <?= csrf_field() ?>
            <input type="hidden" name="accountability_id" value="<?= $id ?>">
            <div class="field">
                <label for="comments">Comments</label>
                <textarea class="input" id="comments" name="comments" placeholder="Required when returning for correction"></textarea>
            </div>
            <div class="form-actions">
                <button class="btn btn-warning" type="submit" name="action" value="return">Return for correction</button>
                <button class="btn btn-success" type="submit" name="action" value="verify" <?= $problems ? 'disabled' : '' ?> data-confirm="Verify this accountability and close the request?">Verify &amp; close request</button>
            </div>
        </form>
    </div>
</div>
