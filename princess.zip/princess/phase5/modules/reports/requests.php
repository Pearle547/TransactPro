<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

Auth::require(['Admin', 'Finance', 'Director']);

$f      = Reports::requestFilters();
$totals = Reports::requestTotals($f);
$page   = paginate((int) $totals['n'], 20);
$rows   = Reports::requests($f, $page['perPage'], $page['offset']);
$projects = DB::all('SELECT project_id, project_code FROM projects ORDER BY project_code');

$export = e(url('modules/reports/export.php?' . http_build_query(['report' => 'requests'] + array_filter($f, static fn ($v) => $v !== '' && $v !== 0))));
render_header('Fund requests report', 'reports', [
    'subtitle' => number_format((int) $totals['n']) . ' request(s) match the filters',
    'actions'  => '<a class="btn" href="' . $export . '">' . icon('download') . ' Export CSV</a><button class="btn" type="button" data-print>Print</button>',
]);
?>
<div class="stats">
    <div class="stat"><div class="stat-label">Requested</div><div class="stat-value"><?= e(money($totals['requested'])) ?></div></div>
    <div class="stat accent"><div class="stat-label">Paid out</div><div class="stat-value"><?= e(money($totals['paid'])) ?></div></div>
    <div class="stat ok"><div class="stat-label">Verified spend</div><div class="stat-value"><?= e(money($totals['utilised'])) ?></div></div>
</div>
<div class="card">
    <form class="filters" method="get">
        <div class="field grow"><label for="q">Search</label><input class="input" id="q" name="q" value="<?= e($f['q']) ?>" placeholder="Code, requester or purpose"></div>
        <div class="field"><label for="project">Project</label>
            <select class="input" id="project" name="project">
                <option value="">All projects</option>
                <?php foreach ($projects as $p): ?><option value="<?= (int) $p['project_id'] ?>"<?= selected($f['project'] === (int) $p['project_id']) ?>><?= e($p['project_code']) ?></option><?php endforeach; ?>
            </select></div>
        <div class="field"><label for="status">Status</label>
            <select class="input" id="status" name="status">
                <option value="">All statuses</option>
                <?php foreach (Reports::REQUEST_STATUSES as $s): ?><option value="<?= $s ?>"<?= selected($f['status'] === $s) ?>><?= e(status_label($s)) ?></option><?php endforeach; ?>
            </select></div>
        <div class="field"><label for="from">From</label><input class="input" type="date" id="from" name="from" value="<?= e($f['from']) ?>"></div>
        <div class="field"><label for="to">To</label><input class="input" type="date" id="to" name="to" value="<?= e($f['to']) ?>"></div>
        <button class="btn btn-primary" type="submit">Apply</button>
        <a class="btn" href="requests.php">Reset</a>
    </form>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Code</th><th>Requester</th><th>Project / line</th><th class="num">Requested</th><th>Status</th><th>Approved</th><th>Paid</th><th class="num">Verified spend</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="code"><?= e($r['request_code']) ?></td>
                    <td><?= e($r['requester']) ?></td>
                    <td><?= e($r['project_code']) ?> · <?= e($r['line_code']) ?></td>
                    <td class="num"><?= e(money($r['amount_requested'])) ?></td>
                    <td><?= badge($r['status']) ?></td>
                    <td class="nowrap"><?= e(fdate($r['approved_at'])) ?></td>
                    <td class="nowrap"><?= e(fdate($r['payment_date'])) ?></td>
                    <td class="num"><?= $r['amount_utilised'] !== null ? e(money($r['amount_utilised'])) : '—' ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?><tr><td colspan="8" class="table-empty">No requests match these filters.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
    <?= pager($page) ?>
</div>
<?php
render_footer();
