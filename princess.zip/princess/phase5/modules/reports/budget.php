<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

Auth::require(['Admin', 'Finance', 'Director']);

$projectId = (int) input('project', 0);
$lines     = Budget::lines($projectId > 0 ? $projectId : null);
$projects  = DB::all('SELECT project_id, project_code, project_name FROM projects ORDER BY project_name');
$t = ['allocated_amount' => 0.0, 'committed' => 0.0, 'utilised' => 0.0, 'available' => 0.0];
foreach ($lines as $l) {
    foreach ($t as $k => $_) {
        $t[$k] += (float) $l[$k];
    }
}

render_header('Budget utilisation report', 'reports', [
    'subtitle' => 'Available = allocated − committed − spent',
    'actions'  => '<a class="btn" href="' . e(url('modules/reports/export.php?report=budget' . ($projectId ? '&project=' . $projectId : ''))) . '">' . icon('download') . ' Export CSV</a><button class="btn" type="button" data-print>Print</button>',
]);
?>
<div class="card">
    <form class="filters" method="get">
        <div class="field grow"><label for="project">Project</label>
            <select class="input" id="project" name="project" data-autosubmit>
                <option value="">All projects</option>
                <?php foreach ($projects as $p): ?><option value="<?= (int) $p['project_id'] ?>"<?= selected($projectId === (int) $p['project_id']) ?>><?= e($p['project_code'] . ' — ' . $p['project_name']) ?></option><?php endforeach; ?>
            </select></div>
    </form>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Project</th><th>Line</th><th>Description</th><th class="num">Allocated</th><th class="num">Committed</th><th class="num">Spent</th><th class="num">Available</th><th>Used</th></tr></thead>
            <tbody>
            <?php foreach ($lines as $l): $pct = Budget::usedPercent($l); ?>
                <tr>
                    <td><?= e($l['project_code']) ?></td>
                    <td class="code"><?= e($l['line_code']) ?></td>
                    <td><?= e($l['description']) ?></td>
                    <td class="num"><?= e(money($l['allocated_amount'])) ?></td>
                    <td class="num"><?= e(money($l['committed'])) ?></td>
                    <td class="num"><?= e(money($l['utilised'])) ?></td>
                    <td class="num"><strong><?= e(money($l['available'])) ?></strong></td>
                    <td class="nowrap"><div class="progress<?= $pct > 90 ? ' danger' : ($pct > 70 ? ' warn' : '') ?>"><span style="width:<?= round($pct, 1) ?>%"></span></div> <small><?= round($pct) ?>%</small></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$lines): ?><tr><td colspan="8" class="table-empty">No budget lines.</td></tr><?php endif; ?>
            </tbody>
            <?php if ($lines): ?>
            <tfoot><tr><td colspan="3">Total</td>
                <td class="num"><?= e(money($t['allocated_amount'])) ?></td><td class="num"><?= e(money($t['committed'])) ?></td>
                <td class="num"><?= e(money($t['utilised'])) ?></td><td class="num"><?= e(money($t['available'])) ?></td><td></td></tr></tfoot>
            <?php endif; ?>
        </table>
    </div>
</div>
<?php
render_footer();
