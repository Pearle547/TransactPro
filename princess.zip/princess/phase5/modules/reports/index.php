<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

Auth::require(['Admin', 'Finance', 'Director']);

$reports = [
    ['requests.php',    'Fund requests',               'Every request with requester, status, payment and verified spend. Filter by project, status, date and requester.', 'send'],
    ['budget.php',      'Budget utilisation',          'Allocated, committed, spent and available funds for every budget line.', 'wallet'],
    ['projects.php',    'Project summary',             'Funding, disbursements and outstanding accountabilities per project and donor.', 'folder'],
    ['outstanding.php', 'Outstanding accountabilities', 'Funds paid out but not yet accounted for, with days overdue.', 'clipboard'],
];

render_header('Reports', 'reports', ['subtitle' => 'Financial summaries you can filter, print or export to Excel (CSV)']);
?>
<div class="grid grid-2">
    <?php foreach ($reports as [$file, $title, $text, $icon]): ?>
        <a class="card" href="<?= e($file) ?>" style="color:inherit;text-decoration:none">
            <div class="card-body" style="display:flex;gap:1rem;align-items:flex-start">
                <span class="avatar" style="width:44px;height:44px;flex:none"><?= icon($icon) ?></span>
                <div><h3 style="margin-bottom:.25rem"><?= e($title) ?></h3><p class="muted" style="margin:0"><?= e($text) ?></p></div>
            </div>
        </a>
    <?php endforeach; ?>
</div>
<?php
render_footer();
