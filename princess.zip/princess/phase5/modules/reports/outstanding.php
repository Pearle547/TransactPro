<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

Auth::require(['Admin', 'Finance', 'Director']);
$rows    = Reports::outstanding();
$overdue = count(array_filter($rows, static fn (array $r): bool => $r['days_overdue'] > 0));

render_header('Outstanding accountabilities', 'reports', [
    'subtitle' => count($rows) . ' open · ' . $overdue . ' overdue',
    'actions'  => '<a class="btn" href="' . e(url('modules/reports/export.php?report=outstanding')) . '">' . icon('download') . ' Export CSV</a><button class="btn" type="button" data-print>Print</button>',
]);
?>
<div class="card">
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Request</th><th>Staff member</th><th>Project</th><th class="num">Amount received</th><th>Paid</th><th>Due by</th><th>Days overdue</th><th>Progress</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="code"><?= e($r['request_code']) ?></td>
                    <td><?= e($r['staff']) ?></td>
                    <td><?= e($r['project_code']) ?></td>
                    <td class="num"><?= e(money($r['amount_requested'])) ?></td>
                    <td class="nowrap"><?= e(fdate($r['payment_date'])) ?></td>
                    <td class="nowrap"><?= e(fdate($r['due_date'])) ?></td>
                    <td><?= $r['days_overdue'] > 0 ? badge('overdue', $r['days_overdue'] . ' days') : '<span class="muted">Not yet due</span>' ?></td>
                    <td><?= $r['accountability_status'] ? badge($r['accountability_status']) : '<span class="muted">Not started</span>' ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?><tr><td colspan="8" class="table-empty">Every released fund has been accounted for.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php
render_footer();
