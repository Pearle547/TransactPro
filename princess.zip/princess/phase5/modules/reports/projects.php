<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

Auth::require(['Admin', 'Finance', 'Director']);
$rows = Reports::projects();

render_header('Project summary report', 'reports', [
    'subtitle' => 'Funding position of every project',
    'actions'  => '<a class="btn" href="' . e(url('modules/reports/export.php?report=projects')) . '">' . icon('download') . ' Export CSV</a><button class="btn" type="button" data-print>Print</button>',
]);
?>
<div class="card">
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Project</th><th>Donor</th><th>Status</th><th class="num">Allocated</th><th class="num">Committed</th><th class="num">Spent</th><th class="num">Available</th><th class="num">Requests</th><th class="num">Disbursed</th><th class="num">Awaiting accountability</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><a href="<?= e(url('modules/projects/view.php?id=' . (int) $r['project_id'])) ?>"><strong><?= e($r['project_code']) ?></strong></a><br><small class="muted"><?= e($r['project_name']) ?></small></td>
                    <td><?= e($r['donor_name']) ?></td>
                    <td><?= badge($r['status']) ?></td>
                    <td class="num"><?= e(money($r['allocated'])) ?></td>
                    <td class="num"><?= e(money($r['committed'])) ?></td>
                    <td class="num"><?= e(money($r['utilised'])) ?></td>
                    <td class="num"><strong><?= e(money($r['available'])) ?></strong></td>
                    <td class="num"><?= $r['requests'] ?></td>
                    <td class="num"><?= e(money($r['disbursed'])) ?></td>
                    <td class="num"><?= $r['outstanding'] ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?><tr><td colspan="10" class="table-empty">No projects.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php
render_footer();
