<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

Auth::require(['Admin', 'Finance', 'Director']);

switch ((string) input('report', '')) {
    case 'requests':
        $rows = array_map(static fn (array $r): array => [
            $r['request_code'], $r['requester'], $r['project_code'], $r['line_code'], $r['purpose'], $r['amount_requested'], status_label($r['status']),
            $r['submitted_at'], $r['approved_at'], $r['payment_date'], $r['paid_amount'], $r['amount_utilised'],
        ], Reports::requests(Reports::requestFilters()));
        Reports::csv('fund-requests', ['Request', 'Requester', 'Project', 'Budget line', 'Purpose', 'Amount requested (UGX)', 'Status', 'Submitted', 'Approved', 'Paid on', 'Paid (UGX)', 'Verified spend (UGX)'], $rows);

    case 'budget':
        $projectId = (int) input('project', 0);
        $rows = array_map(static fn (array $l): array => [
            $l['project_code'], $l['line_code'], $l['description'], $l['allocated_amount'], $l['committed'], $l['utilised'], $l['available'],
        ], Budget::lines($projectId > 0 ? $projectId : null));
        Reports::csv('budget-utilisation', ['Project', 'Line', 'Description', 'Allocated (UGX)', 'Committed (UGX)', 'Spent (UGX)', 'Available (UGX)'], $rows);

    case 'projects':
        $rows = array_map(static fn (array $r): array => [
            $r['project_code'], $r['project_name'], $r['donor_name'], $r['status'], $r['allocated'], $r['committed'], $r['utilised'], $r['available'], $r['requests'], $r['disbursed'], $r['outstanding'],
        ], Reports::projects());
        Reports::csv('project-summary', ['Code', 'Project', 'Donor', 'Status', 'Allocated (UGX)', 'Committed (UGX)', 'Spent (UGX)', 'Available (UGX)', 'Requests', 'Disbursed (UGX)', 'Awaiting accountability'], $rows);

    case 'outstanding':
        $rows = array_map(static fn (array $r): array => [
            $r['request_code'], $r['staff'], $r['project_code'], $r['amount_requested'], $r['payment_date'], $r['due_date'], $r['days_overdue'], $r['accountability_status'] ?? 'Not started',
        ], Reports::outstanding());
        Reports::csv('outstanding-accountabilities', ['Request', 'Staff member', 'Project', 'Amount received (UGX)', 'Paid on', 'Due by', 'Days overdue', 'Progress'], $rows);

    default:
        abort(404, 'Unknown report.');
}
