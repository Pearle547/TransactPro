<?php
/** @var array $user */
if (!in_array($user['role'], ['Finance', 'Admin'], true)) {
    return;
}
$rows = DB::all(
    "SELECT a.accountability_id, a.total_spent, a.balance_returned, a.submitted_at, fr.request_code, p.project_code, u.full_name
       FROM accountabilities a
       JOIN financial_requests fr ON fr.request_id = a.request_id
       JOIN projects p ON p.project_id = fr.project_id
       JOIN users u ON u.user_id = a.user_id
      WHERE a.status = 'Submitted' ORDER BY a.submitted_at"
);
if (!$rows) {
    return;
}
?>
<div class="card">
    <div class="card-head"><h3>Accountabilities awaiting verification (<?= count($rows) ?>)</h3></div>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Request</th><th>Staff member</th><th>Project</th><th class="num">Spent</th><th class="num">Returned</th><th>Waiting</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="code"><?= e($r['request_code']) ?></td>
                    <td><?= e($r['full_name']) ?></td>
                    <td><?= e($r['project_code']) ?></td>
                    <td class="num"><?= e(money($r['total_spent'])) ?></td>
                    <td class="num"><?= e(money($r['balance_returned'])) ?></td>
                    <td class="nowrap"><?= e(time_ago($r['submitted_at'])) ?></td>
                    <td class="text-right"><a class="btn btn-sm btn-primary" href="<?= e(url('modules/accountabilities/view.php?id=' . (int) $r['accountability_id'])) ?>"><?= $user['role'] === 'Admin' ? 'View' : 'Verify' ?></a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
