<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

Auth::require(['Admin']);

if (is_post()) {
    $data = [
        'director_threshold'     => str_replace(',', '', (string) input('director_threshold', '')),
        'accountability_due_days' => (string) input('accountability_due_days', ''),
    ];
    $errors = Validator::validate($data, [
        'director_threshold'      => 'required|numeric|min_value:100000|max_value:1000000000000',
        'accountability_due_days' => 'required|numeric|min_value:1|max_value:90',
    ], ['director_threshold' => 'Director approval threshold', 'accountability_due_days' => 'Accountability deadline']);
    if (!$errors && (string) (int) $data['accountability_due_days'] !== $data['accountability_due_days']) {
        $errors['accountability_due_days'] = 'Enter a whole number of days.';
    }
    if ($errors) {
        remember_form($data, $errors);
        redirect('modules/settings/index.php');
    }

    $changes = [];
    DB::transaction(function () use ($data, &$changes): void {
        foreach (['director_threshold' => 'Director approval threshold', 'accountability_due_days' => 'Accountability deadline (days)'] as $key => $label) {
            $old = Settings::get($key);
            $new = (string) (int) $data[$key];
            if ($old !== $new) {
                Settings::set($key, $new);
                $changes[] = "$label: $old → $new";
            }
        }
        if ($changes) {
            Audit::log('Settings changed', 'Settings', null, implode('; ', $changes));
        }
    });
    flash('success', $changes ? 'Settings saved.' : 'Nothing was changed.');
    redirect('modules/settings/index.php');
}

$threshold = old('director_threshold', Settings::get('director_threshold', '10000000'));
$days      = old('accountability_due_days', Settings::get('accountability_due_days', '14'));
$pendingFinance = (int) DB::val("SELECT COUNT(*) FROM financial_requests WHERE status = 'Pending_Finance'");

render_header('System settings', 'settings', ['subtitle' => 'Business rules that apply to every user']);
?>
<div class="grid grid-main">
    <div class="card">
        <div class="card-head"><h3>Approval &amp; accountability rules</h3></div>
        <div class="card-body">
            <form method="post" data-once>
                <?= csrf_field() ?>
                <div class="form-grid">
                    <div class="field full">
                        <label for="director_threshold">Director approval threshold (UGX) <span class="req">*</span></label>
                        <input class="input<?= has_error('director_threshold') ? ' invalid' : '' ?>" id="director_threshold" name="director_threshold" inputmode="numeric" value="<?= e(is_numeric($threshold) ? number_format((float) $threshold, 0, '.', '') : $threshold) ?>" required>
                        <span class="hint">All requests go to Finance first. Requests <strong>below</strong> this amount are approved by Finance alone; requests of this amount <strong>or more</strong> also need the Director.</span>
                        <?= field_error('director_threshold') ?>
                    </div>
                    <div class="field full">
                        <label for="accountability_due_days">Accountability deadline (days after payment) <span class="req">*</span></label>
                        <input class="input<?= has_error('accountability_due_days') ? ' invalid' : '' ?>" id="accountability_due_days" name="accountability_due_days" inputmode="numeric" value="<?= e($days) ?>" required>
                        <span class="hint">After this many days an unaccounted payment is flagged as overdue.</span>
                        <?= field_error('accountability_due_days') ?>
                    </div>
                </div>
                <div class="form-actions"><button class="btn btn-primary" type="submit">Save settings</button></div>
            </form>
        </div>
    </div>
    <div class="card">
        <div class="card-head"><h3>Good to know</h3></div>
        <div class="card-body">
            <p>Changing the threshold applies to <strong>future Finance decisions</strong>. A request already approved is not re-routed.</p>
            <?php if ($pendingFinance): ?><p class="panel-note"><?= $pendingFinance ?> request(s) are waiting for Finance right now and will use the new threshold when decided.</p><?php endif; ?>
            <p>Every change is recorded in the audit log with the old and new value.</p>
        </div>
    </div>
</div>
<?php
render_footer();
