# TransactPro — Phase 5: Verification, Reports & Control Centre

The complete system. Builds on Phases 1–4; everything before still works.

## What is new in this phase
| Area | Features |
| :--- | :--- |
| **Verification** | Finance reviews each submitted accountability: receipts attached, figures reconciled, every receipt openable. **Verify & close** or **Return for correction** (comments mandatory). Closing a request records the verified spend and **releases any unspent balance back to the budget line** |
| Returned accountabilities | The requester is notified, the request goes back to *Paid*, and they correct and resubmit |
| Approvals queue | One screen for each approver: plans, fund requests and (for Finance) accountabilities waiting for verification, with a live menu counter |
| **Reports** | *Fund requests*, *Budget utilisation*, *Project summary* and *Outstanding accountabilities* — filterable, printable, and exportable to Excel-friendly **CSV** (exports are logged; spreadsheet-formula injection is neutralised) |
| Dashboards | Budget use by project (spent vs committed), request pipeline by stage, verification workload, funds released back to budgets |
| **Settings (Admin)** | Change the **Director approval threshold** (default UGX 10,000,000) and the **accountability deadline** (default 14 days). Every change is audited with old and new value |

## Install (XAMPP)
1. Copy this folder to `C:\xampp\htdocs\transactpro\phase5\`.
2. Start **Apache** and **MySQL**.
3. phpMyAdmin → **Import** → `database/schema.sql` (creates `transactpro_phase5`).
4. Make sure `storage/receipts/` is writable by Apache.
5. Open `http://localhost/transactpro/phase5/`.

## Demo accounts — password for all: `password123`
| Role | Email |
| :--- | :--- |
| Admin | admin@transactpro.test |
| Staff | staff@transactpro.test, staff2@transactpro.test |
| Manager | manager@transactpro.test |
| Finance | finance@transactpro.test |
| Director | director@transactpro.test |

> Change these passwords (or delete the accounts) and set a MySQL password before real use.

## The full financial workflow
```
PLAN       Staff ─► Manager ─► Finance ─► Approved plan
REQUEST    Staff ─► Manager ─► Finance ──┬─ below UGX 10,000,000 ──► Approved
                                         └─ UGX 10,000,000 or more ─► Director ─► Approved
PAYMENT    Finance records the payment ─► Paid            (budget stays reserved)
ACCOUNT    Staff lists expenses + receipts, returns balance ─► Submitted
VERIFY     Finance verifies ─► Closed   (spent amount recorded, unspent amount released to the budget)
           …or returns it for correction ─► back to the requester
```
Every step is recorded in the approvals history and the audit log, so any transaction can be traced to the person responsible.

## Who can do what
| | Admin | Staff | Manager | Finance | Director |
| :--- | :-: | :-: | :-: | :-: | :-: |
| Users, audit log, settings | ✔ | | | | |
| Projects & budget lines (create / edit) | ✔ | | | ✔ | |
| Create plans, requests, accountabilities | | ✔ | | | |
| Approve plans | | | ✔ | ✔ | |
| Approve requests | | | stage 1 | stage 2 | high-value only |
| Record payments, verify accountabilities | | | | ✔ | |
| Reports & CSV export | ✔ | | | ✔ | ✔ |

## Deploying for real
* Set a MySQL password and update `app/config.php` (`db.pass`), and keep `debug` false.
* Serve over HTTPS (the session cookie becomes `Secure` automatically).
* Back up the database **and** `storage/receipts/` together.
* Make sure Apache has `AllowOverride All` for this folder so the `.htaccess` files that protect `app/`, `database/` and `storage/` take effect.
