<?php
/**
 * TransactPro application configuration.
 *
 * Edit the database credentials below to match your XAMPP / MySQL setup.
 */
return [
    'app_name' => 'TransactPro',
    'org_name' => 'JESE',
    'version'  => '1.5.0',
    'phase'    => 5,
    'debug'    => false,   // set to true while developing to see full error details

    'db' => [
        'host'    => 'localhost',
        'port'    => 3307,          // MySQL Workbench / XAMPP default; change if your server uses another port (e.g. 3307)
        'name'    => 'transactpro_phase5',
        'user'    => 'root',
        'pass'    => '#Bwambale6',
        'charset' => 'utf8mb4',
    ],

    'session' => [
        'name'         => 'transactpro_sid',
        'idle_timeout' => 1800,      // seconds of inactivity before automatic sign-out
    ],

    'security' => [
        'max_failed_logins'   => 5,  // consecutive failures before the account is locked
        'lockout_minutes'     => 15,
        'min_password_length' => 8,
    ],
];
