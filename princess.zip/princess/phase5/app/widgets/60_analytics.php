<?php
/** @var array $user */
if (!in_array($user['role'], ['Admin', 'Finance', 'Director'], true)) {
    return;
}

$projects  = Reports::projects();
$pipeline  = array_column(DB::all("SELECT status, COUNT(*) AS total, COALESCE(SUM(amount_requested), 0) AS amount FROM financial_requests WHERE status <> 'Draft' GROUP BY status"), null, 'status');
$maxCount  = max([1, ...array_map(static fn ($r) => (int) $r['total'], array_values($pipeline))]);
$verifying = $user['role'] === 'Finance' ? Verification::awaitingCount() : null;
$closed    = DB::row("SELECT COUNT(*) AS n, COALESCE(SUM(amount_utilised), 0) AS spent, COALESCE(SUM(amount_requested - amount_utilised), 0) AS released FROM financial_requests WHERE status = 'Closed'");
?>
<?php if ($verifying !== null): ?>
<div class="stats">
    <div class="stat <?= $verifying ? 'warn' : 'ok' ?>"><div class="stat-label">Awaiting verification</div><div class="stat-value"><?= $verifying ?></div><div class="stat-note"><a href="<?= e(url('modules/approvals/index.php')) ?>">Open verification queue</a></div></div>
    <div class="stat ok"><div class="stat-label">Closed requests</div><div class="stat-value"><?= (int) $closed['n'] ?></div><div class="stat-note"><?= e(money($closed['spent'])) ?> verified spend</div></div>
    <div class="stat accent"><div class="stat-label">Released back to budgets</div><div class="stat-value"><?= e(money($closed['released'])) ?></div><div class="stat-note">Unspent balances on closed requests</div></div>
</div>
<?php endif; ?>

<div class="grid grid-2">
    <div class="card">
        <div class="card-head"><h3>Budget use by project</h3><a class="btn btn-sm" href="<?= e(url('modules/reports/projects.php')) ?>">Project report</a></div>
        <div class="card-body bars">
            <?php foreach ($projects as $p):
                $alloc = (float) $p['allocated'];
                $spentPct = $alloc > 0 ? min(100, $p['utilised'] / $alloc * 100) : 0;
                $usedPct  = $alloc > 0 ? min(100, ($p['utilised'] + $p['committed']) / $alloc * 100) : 0; ?>
                <div class="bar-row">
                    <span class="bar-label" title="<?= e($p['project_name']) ?>"><?= e($p['project_code']) ?></span>
                    <div class="progress stack" title="Spent <?= round($spentPct) ?>% · committed <?= round($usedPct - $spentPct) ?>%">
                        <span class="committed" style="width:<?= round($usedPct, 1) ?>%"></span><span class="spent" style="width:<?= round($spentPct, 1) ?>%"></span>
                    </div>
                    <span class="bar-value"><?= e(money($p['available'])) ?> left</span>
                </div>
            <?php endforeach; ?>
            <?php if (!$projects): ?><p class="muted">No projects yet.</p><?php endif; ?>
            <p class="hint"><span class="badge badge-rejected">Spent</span> <span class="badge badge-pending-manager">Committed</span> — share of each project's allocation.</p>
        </div>
    </div>

    <div class="card">
        <div class="card-head"><h3>Request pipeline</h3><a class="btn btn-sm" href="<?= e(url('modules/reports/requests.php')) ?>">Request report</a></div>
        <div class="card-body bars">
            <?php foreach (Reports::REQUEST_STATUSES as $s): if ($s === 'Draft') { continue; } $row = $pipeline[$s] ?? ['total' => 0, 'amount' => 0]; ?>
                <div class="bar-row">
                    <span class="bar-label"><?= e(status_label($s)) ?></span>
                    <div class="progress"><span style="width:<?= round(((int) $row['total']) / $maxCount * 100, 1) ?>%"></span></div>
                    <span class="bar-value"><?= (int) $row['total'] ?> · <?= e(money($row['amount'])) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
