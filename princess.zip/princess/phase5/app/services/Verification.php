<?php
declare(strict_types=1);

/**
 * Final verification of an accountability by Finance.
 *
 *   Submitted ──► Verified   → the request is Closed, the amount actually spent is recorded against the
 *                              budget line and anything unspent is released back to it.
 *   Submitted ──► Revision_Requested → returned to the requester; the request goes back to "Paid".
 */
final class Verification
{
    public static function awaitingCount(): int
    {
        return (int) DB::val("SELECT COUNT(*) FROM accountabilities WHERE status = 'Submitted'");
    }

    public static function canReview(array $acc, array $user): bool
    {
        return $user['role'] === 'Finance' && $acc['status'] === 'Submitted' && (int) $acc['user_id'] !== (int) $user['user_id'];
    }

    public static function verify(int $accountabilityId, string $comments): void
    {
        $user = Auth::user();
        DB::transaction(function () use ($accountabilityId, $comments, $user): void {
            [$acc, $req] = self::lock($accountabilityId, $user);

            // Re-run every check: nothing may have been altered since submission, and the numbers must still reconcile.
            $problems = Accountabilities::problems($acc, Accountabilities::items($accountabilityId));
            if ($problems) {
                throw new DomainException('This accountability cannot be verified: ' . implode(' ', array_slice($problems, 0, 2)));
            }

            DB::exec("UPDATE accountabilities SET status = 'Verified', reviewed_at = NOW(), reviewed_by = ? WHERE accountability_id = ?", [$user['user_id'], $accountabilityId]);
            DB::exec("UPDATE financial_requests SET status = 'Closed', amount_utilised = ? WHERE request_id = ?", [$acc['total_spent'], $req['request_id']]);
            Approvals::record('accountability', $accountabilityId, 'Finance', 'Verified', $comments);
            Audit::log('Accountability verified', 'Accountability', $accountabilityId,
                "Verified {$req['request_code']}: " . money($acc['total_spent']) . ' spent, ' . money((float) $req['amount_requested'] - (float) $acc['total_spent']) . ' released to the budget line; request closed');
            Notify::user((int) $acc['user_id'], 'Accountability verified',
                "Your accountability for {$req['request_code']} was verified and the request is now closed.",
                'modules/accountabilities/view.php?id=' . $accountabilityId);
        });
    }

    public static function returnForCorrection(int $accountabilityId, string $comments): void
    {
        $user = Auth::user();
        if (trim($comments) === '') {
            throw new DomainException('Please explain what needs to be corrected.');
        }
        DB::transaction(function () use ($accountabilityId, $comments, $user): void {
            [$acc, $req] = self::lock($accountabilityId, $user);

            DB::exec("UPDATE accountabilities SET status = 'Revision_Requested', reviewed_at = NOW(), reviewed_by = ? WHERE accountability_id = ?", [$user['user_id'], $accountabilityId]);
            DB::exec("UPDATE financial_requests SET status = 'Paid' WHERE request_id = ?", [$req['request_id']]);
            Approvals::record('accountability', $accountabilityId, 'Finance', 'Revision_Requested', $comments);
            Audit::log('Accountability returned', 'Accountability', $accountabilityId, "Returned {$req['request_code']} for correction");
            Notify::user((int) $acc['user_id'], 'Accountability returned for correction',
                "{$req['request_code']}: " . trim($comments), 'modules/accountabilities/form.php?request_id=' . $req['request_id']);
        });
    }

    /** @return array{0: array, 1: array} the locked accountability and its request */
    private static function lock(int $accountabilityId, array $user): array
    {
        $acc = DB::row('SELECT * FROM accountabilities WHERE accountability_id = ? FOR UPDATE', [$accountabilityId]);
        if (!$acc) {
            throw new DomainException('Accountability not found.');
        }
        $req = DB::row('SELECT * FROM financial_requests WHERE request_id = ? FOR UPDATE', [$acc['request_id']]);
        if (!self::canReview($acc, $user) || !$req || $req['status'] !== 'Accountability_Submitted') {
            throw new DomainException('Only Finance can review an accountability that is waiting for verification.');
        }
        return [$acc, $req];
    }
}

Approvals::registerCounter(static fn (string $role): int => $role === 'Finance' ? Verification::awaitingCount() : 0);
