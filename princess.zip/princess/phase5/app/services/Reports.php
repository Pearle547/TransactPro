<?php
declare(strict_types=1);

/**
 * Report queries shared by the on-screen reports and the CSV exports, so both always show the same numbers.
 */
final class Reports
{
    public const REQUEST_STATUSES = ['Draft', 'Pending_Manager', 'Pending_Finance', 'Pending_Director', 'Approved', 'Rejected', 'Revision_Requested', 'Paid', 'Accountability_Submitted', 'Closed'];

    /** Filters for the requests report, read from the query string. */
    public static function requestFilters(): array
    {
        $status = (string) input('status', '');
        $from   = (string) input('from', '');
        $to     = (string) input('to', '');
        return [
            'project' => (int) input('project', 0),
            'status'  => in_array($status, self::REQUEST_STATUSES, true) ? $status : '',
            'from'    => Validator::isDate($from) ? $from : '',
            'to'      => Validator::isDate($to) ? $to : '',
            'q'       => (string) input('q', ''),
        ];
    }

    private static function requestWhere(array $f): array
    {
        $where  = ['1 = 1'];
        $params = [];
        if ($f['project'] > 0) {
            $where[]  = 'fr.project_id = ?';
            $params[] = $f['project'];
        }
        if ($f['status'] !== '') {
            $where[]  = 'fr.status = ?';
            $params[] = $f['status'];
        }
        if ($f['from'] !== '') {
            $where[]  = 'fr.created_at >= ?';
            $params[] = $f['from'] . ' 00:00:00';
        }
        if ($f['to'] !== '') {
            $where[]  = 'fr.created_at <= ?';
            $params[] = $f['to'] . ' 23:59:59';
        }
        if ($f['q'] !== '') {
            $where[]  = '(fr.request_code LIKE ? OR u.full_name LIKE ? OR fr.purpose LIKE ?)';
            array_push($params, "%{$f['q']}%", "%{$f['q']}%", "%{$f['q']}%");
        }
        return [implode(' AND ', $where), $params];
    }

    private const REQUEST_FROM = 'FROM financial_requests fr
        JOIN users u ON u.user_id = fr.user_id
        JOIN projects p ON p.project_id = fr.project_id
        JOIN budget_lines bl ON bl.budget_line_id = fr.budget_line_id
        LEFT JOIN payments pay ON pay.request_id = fr.request_id';

    public static function requestTotals(array $f): array
    {
        [$where, $params] = self::requestWhere($f);
        return DB::row(
            'SELECT COUNT(*) AS n, COALESCE(SUM(fr.amount_requested), 0) AS requested, COALESCE(SUM(pay.paid_amount), 0) AS paid, COALESCE(SUM(fr.amount_utilised), 0) AS utilised '
            . self::REQUEST_FROM . " WHERE $where",
            $params
        ) ?? ['n' => 0, 'requested' => 0, 'paid' => 0, 'utilised' => 0];
    }

    /** @return array<int, array<string, mixed>> */
    public static function requests(array $f, ?int $limit = null, int $offset = 0): array
    {
        [$where, $params] = self::requestWhere($f);
        $sql = 'SELECT fr.request_code, u.full_name AS requester, p.project_code, bl.line_code, fr.purpose, fr.amount_requested, fr.status,
                       fr.submitted_at, fr.approved_at, pay.payment_date, pay.paid_amount, fr.amount_utilised '
             . self::REQUEST_FROM . " WHERE $where ORDER BY fr.request_id DESC";
        if ($limit !== null) {
            $sql .= ' LIMIT ' . (int) $limit . ' OFFSET ' . (int) $offset;
        }
        return DB::all($sql, $params);
    }

    /** One row per project with money and workload figures. */
    public static function projects(): array
    {
        $summaries = Budget::projectSummaries();
        $rows = [];
        foreach (DB::all('SELECT project_id, project_code, project_name, donor_name, status FROM projects ORDER BY project_name') as $p) {
            $id = (int) $p['project_id'];
            $s  = $summaries[$id] ?? ['allocated' => 0, 'committed' => 0, 'utilised' => 0, 'available' => 0];
            $stats = DB::row(
                "SELECT COUNT(*) AS requests,
                        COALESCE(SUM(CASE WHEN fr.status IN ('Paid','Accountability_Submitted','Closed') THEN fr.amount_requested END), 0) AS disbursed,
                        SUM(fr.status = 'Paid') AS outstanding
                   FROM financial_requests fr WHERE fr.project_id = ? AND fr.status <> 'Draft'",
                [$id]
            );
            $rows[] = $p + $s + ['requests' => (int) $stats['requests'], 'disbursed' => (float) $stats['disbursed'], 'outstanding' => (int) $stats['outstanding']];
        }
        return $rows;
    }

    /** Paid requests that have not been accounted for yet, oldest first. */
    public static function outstanding(): array
    {
        $rows = DB::all(
            "SELECT fr.request_code, u.full_name AS staff, p.project_code, fr.amount_requested, pay.payment_date, a.status AS accountability_status
               FROM financial_requests fr
               JOIN users u ON u.user_id = fr.user_id
               JOIN projects p ON p.project_id = fr.project_id
               JOIN payments pay ON pay.request_id = fr.request_id
          LEFT JOIN accountabilities a ON a.request_id = fr.request_id
              WHERE fr.status = 'Paid' ORDER BY pay.payment_date"
        );
        foreach ($rows as &$r) {
            $r['due_date']     = Accountabilities::dueDate($r['payment_date']);
            $r['days_overdue'] = max(0, (int) floor((strtotime(date('Y-m-d')) - strtotime($r['due_date'])) / 86400));
        }
        unset($r);
        usort($rows, static fn (array $a, array $b): int => $b['days_overdue'] <=> $a['days_overdue']);
        return $rows;
    }

    /** Send a CSV download (Excel-friendly UTF-8) and stop. */
    public static function csv(string $name, array $header, array $rows): never
    {
        Audit::log('Report exported', 'Reports', null, "Exported $name (" . count($rows) . ' rows)');
        header_remove('Content-Security-Policy');
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="transactpro-' . $name . '-' . date('Ymd-His') . '.csv"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, $header);
        foreach ($rows as $row) {
            // Neutralise spreadsheet formula injection in text cells
            fputcsv($out, array_map(static fn ($v) => is_string($v) && $v !== '' && in_array($v[0], ['=', '+', '-', '@'], true) ? "'" . $v : $v, $row));
        }
        fclose($out);
        exit;
    }
}
