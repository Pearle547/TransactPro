# TransactPro — five-phase delivery

Digital Financial Transaction and Approval System for **JESE** (Fort Portal, Uganda).

Each folder is a **complete, runnable application**. Phase *N* contains everything from phases 1 … *N−1* plus its own upgrade, so the client can run, review and sign off one phase at a time.

| Folder | Phase | Adds |
| :--- | :--- | :--- |
| [`phase1`](phase1/README.md) | **Secure access & administration** | Login with lock-out and idle time-out, five roles, user management, forced password change, profile, audit trail |
| [`phase2`](phase2/README.md) | **Projects, budgets & planning** | Projects and donors, budget lines, financial plans with Manager → Finance approval, approvals queue, in-app notifications |
| [`phase3`](phase3/README.md) | **Fund requests & threshold approvals** | Fund requests with live budget control. **Every request goes Manager → Finance; below UGX 10,000,000 Finance's approval is final, UGX 10,000,000 or more continues to the Director** |
| [`phase4`](phase4/README.md) | **Payments & accountability** | Payment recording, accountability with receipt uploads, live reconciliation, expenditure register, deadlines |
| [`phase5`](phase5/README.md) | **Verification, reports & control** | Finance verification and closing (unspent funds released to the budget), reports with CSV export, analytics dashboards, admin settings |

## Quick start (XAMPP)
1. Copy the phase folder you want into `C:\xampp\htdocs\transactpro\` (e.g. `C:\xampp\htdocs\transactpro\phase3`).
2. Start **Apache** and **MySQL**.
3. phpMyAdmin → **Import** → that phase's `database/schema.sql`. Each phase uses its own database (`transactpro_phase1` … `transactpro_phase5`), so phases can sit side by side.
4. Open `http://localhost/transactpro/phase3/`.

Demo accounts — password for all: `password123`

| Role | Email |
| :--- | :--- |
| Admin | admin@transactpro.test |
| Staff | staff@transactpro.test · staff2@transactpro.test |
| Manager | manager@transactpro.test |
| Finance | finance@transactpro.test |
| Director | director@transactpro.test |

## Architecture (the same in every phase)
```
index.php, login.php, dashboard.php, profile.php …   thin pages
modules/<area>/                                      one folder per feature (users, plans, requests, payments …)
app/core/                                            DB, Auth, CSRF, Audit, Validator, layout, helpers
app/services/                                        business rules: PlanWorkflow, RequestWorkflow, Budget, Payments,
                                                     Accountabilities, Verification, Reports …
app/widgets/                                         dashboard tiles — each phase simply drops in new ones
database/schema.sql                                  complete, importable schema for that phase
```
Pages never change a record's status themselves — they call a service, which checks the user's role, the current stage and the business rules inside a database transaction.

## Security highlights
PDO prepared statements everywhere · bcrypt password hashing · CSRF token on every POST · session fixation protection, idle time-out, account lock-out · role checks on every page **and** every action · segregation of duties (nobody approves their own request) · receipts stored outside public access and served only after an access check · strict Content-Security-Policy · complete audit trail.

> The earlier prototype in `transactpro/` is left untouched for reference; the five phase folders replace it.
