# TransactPro — Phase 2: Projects, Budgets & Financial Planning

Builds on Phase 1 (login, roles, users, audit). Everything from Phase 1 still works.

## What is new in this phase
| Area | Features |
| :--- | :--- |
| Projects & donors | Create / edit projects, link each to a donor, track Active / Completed / Suspended |
| Budget lines | Allocate funds per project activity; availability is **calculated**, never typed in, so it cannot drift. An allocation can't be reduced below what is already committed |
| Financial plans | Staff describe a planned activity and its cost, save drafts, and submit |
| Plan approval | **Staff → Manager → Finance → Approved.** Rejection or "revision requested" returns the plan to the author with the reviewer's comments. Authors can never review their own plan |
| Approvals queue | Managers and Finance see exactly what is waiting for them (with a live counter in the menu) |
| Notifications | The next approver — and later the author — is alerted in the app; bell icon with unread count |
| Dashboard | New planning widgets per role |

## Install (XAMPP)
1. Copy this folder to `C:\xampp\htdocs\transactpro\phase2\`.
2. Start **Apache** and **MySQL**.
3. phpMyAdmin → **Import** → `database/schema.sql` (creates `transactpro_phase2` with demo users, 3 projects and 6 budget lines).
4. Adjust `app/config.php` if your MySQL root has a password.
5. Open `http://localhost/transactpro/phase2/`.

Demo accounts and the shared password (`password123`) are the same as Phase 1 — see the table below.

| Role | Email |
| :--- | :--- |
| Admin | admin@transactpro.test |
| Staff | staff@transactpro.test, staff2@transactpro.test |
| Manager | manager@transactpro.test |
| Finance | finance@transactpro.test |
| Director | director@transactpro.test |

## Try it
1. Sign in as **staff** → *Financial plans* → *New plan* → **Submit for approval**.
2. Sign in as **manager** → bell / *Approvals* → open the plan → **Approve**.
3. Sign in as **finance** → approve again. The plan is now *Approved* and the author is notified.

## Who can do what
| | Admin | Staff | Manager | Finance | Director |
| :--- | :-: | :-: | :-: | :-: | :-: |
| Manage users / read audit log | ✔ | | | | |
| Create & edit projects, budget lines | ✔ | | | ✔ | |
| View projects | ✔ | ✔ | ✔ | ✔ | ✔ |
| View budget lines | ✔ | | ✔ | ✔ | ✔ |
| Create & submit plans | | ✔ | | | |
| Approve plans | | | stage 1 | stage 2 | |

## Design notes
* Business rules live in `app/services/` (`PlanWorkflow`, `Budget`, `Approvals`, `Notify`); pages only call them.
* Each state change runs in a database transaction with the row locked, so two reviewers cannot decide the same plan twice.
* Every decision is stored in the shared `approvals` table and in the audit log.
