-- TransactPro — Phase 2 database schema (cumulative)
-- Run in MySQL Workbench (File > Run SQL Script) or phpMyAdmin Import. Never drops anything: to start over, drop transactpro_phase2 yourself first

SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS transactpro_phase2 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE transactpro_phase2;

-- =====================================================================
-- Phase 1 — Authentication, users and audit trail
-- =====================================================================

CREATE TABLE users (
    user_id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    full_name            VARCHAR(100) NOT NULL,
    email                VARCHAR(100) NOT NULL,
    password_hash        VARCHAR(255) NOT NULL,
    role                 ENUM('Admin','Staff','Manager','Finance','Director') NOT NULL,
    phone                VARCHAR(20) NULL,
    department           VARCHAR(100) NULL,
    status               ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
    must_change_password TINYINT(1) NOT NULL DEFAULT 0,
    failed_attempts      TINYINT UNSIGNED NOT NULL DEFAULT 0,
    locked_until         DATETIME NULL,
    last_login           DATETIME NULL,
    created_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id),
    UNIQUE KEY uq_users_email (email),
    KEY idx_users_role_status (role, status)
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
    audit_id    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id     INT UNSIGNED NULL,
    action      VARCHAR(100) NOT NULL,
    module      VARCHAR(100) NOT NULL,
    record_id   INT UNSIGNED NULL,
    description TEXT NULL,
    ip_address  VARCHAR(45) NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (audit_id),
    KEY idx_audit_user (user_id),
    KEY idx_audit_module (module),
    KEY idx_audit_created (created_at),
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Demo accounts. Every account uses the password:  password123
INSERT INTO users (full_name, email, password_hash, role, phone, department, status) VALUES
('System Administrator', 'admin@transactpro.test',    '$2y$10$bnyUsWj.UgNBNzcK6nsuheTeu1n9Mjrr8KR0KceaO0gQGeh98cVq6', 'Admin',    '0700000001', 'IT',               'Active'),
('John Staff',           'staff@transactpro.test',    '$2y$10$bnyUsWj.UgNBNzcK6nsuheTeu1n9Mjrr8KR0KceaO0gQGeh98cVq6', 'Staff',    '0700000002', 'Field Operations', 'Active'),
('Grace Staff',          'staff2@transactpro.test',   '$2y$10$bnyUsWj.UgNBNzcK6nsuheTeu1n9Mjrr8KR0KceaO0gQGeh98cVq6', 'Staff',    '0700000006', 'Field Operations', 'Active'),
('Alice Manager',        'manager@transactpro.test',  '$2y$10$bnyUsWj.UgNBNzcK6nsuheTeu1n9Mjrr8KR0KceaO0gQGeh98cVq6', 'Manager',  '0700000003', 'Field Operations', 'Active'),
('Bob Finance',          'finance@transactpro.test',  '$2y$10$bnyUsWj.UgNBNzcK6nsuheTeu1n9Mjrr8KR0KceaO0gQGeh98cVq6', 'Finance',  '0700000004', 'Finance',          'Active'),
('Charlie Director',     'director@transactpro.test', '$2y$10$bnyUsWj.UgNBNzcK6nsuheTeu1n9Mjrr8KR0KceaO0gQGeh98cVq6', 'Director', '0700000005', 'Executive',        'Active');


-- =====================================================================
-- Phase 2 — Projects, budget lines, financial plans, approvals, notifications
-- =====================================================================

CREATE TABLE projects (
    project_id   INT UNSIGNED NOT NULL AUTO_INCREMENT,
    project_code VARCHAR(30) NOT NULL,
    project_name VARCHAR(200) NOT NULL,
    donor_name   VARCHAR(200) NOT NULL,
    description  TEXT NULL,
    start_date   DATE NOT NULL,
    end_date     DATE NOT NULL,
    status       ENUM('Active','Completed','Suspended') NOT NULL DEFAULT 'Active',
    created_by   INT UNSIGNED NULL,
    created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (project_id),
    UNIQUE KEY uq_project_code (project_code),
    KEY idx_project_status (status),
    CONSTRAINT fk_project_creator FOREIGN KEY (created_by) REFERENCES users (user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Budget availability is always derived (allocated − committed − utilised), never stored,
-- so it cannot drift out of step with the underlying requests.
CREATE TABLE budget_lines (
    budget_line_id   INT UNSIGNED NOT NULL AUTO_INCREMENT,
    project_id       INT UNSIGNED NOT NULL,
    line_code        VARCHAR(30) NOT NULL,
    description      VARCHAR(255) NOT NULL,
    allocated_amount DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (budget_line_id),
    UNIQUE KEY uq_budget_line (project_id, line_code),
    CONSTRAINT fk_budget_project FOREIGN KEY (project_id) REFERENCES projects (project_id) ON DELETE CASCADE,
    CONSTRAINT chk_budget_amount CHECK (allocated_amount >= 0)
) ENGINE=InnoDB;

CREATE TABLE financial_plans (
    plan_id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    plan_code            VARCHAR(30) NOT NULL,
    project_id           INT UNSIGNED NOT NULL,
    created_by           INT UNSIGNED NOT NULL,
    title                VARCHAR(200) NOT NULL,
    activity_description TEXT NOT NULL,
    planned_amount       DECIMAL(15,2) NOT NULL,
    planned_date         DATE NOT NULL,
    status               ENUM('Draft','Pending_Manager','Pending_Finance','Approved','Rejected','Revision_Requested') NOT NULL DEFAULT 'Draft',
    submitted_at         DATETIME NULL,
    reviewed_at          DATETIME NULL,
    created_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (plan_id),
    UNIQUE KEY uq_plan_code (plan_code),
    KEY idx_plan_status (status),
    KEY idx_plan_creator (created_by),
    CONSTRAINT fk_plan_project FOREIGN KEY (project_id) REFERENCES projects (project_id),
    CONSTRAINT fk_plan_creator FOREIGN KEY (created_by) REFERENCES users (user_id),
    CONSTRAINT chk_plan_amount CHECK (planned_amount > 0)
) ENGINE=InnoDB;

-- One decision log shared by plans, fund requests and accountabilities.
CREATE TABLE approvals (
    approval_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    entity_type ENUM('plan','request','accountability') NOT NULL,
    entity_id   INT UNSIGNED NOT NULL,
    stage       ENUM('Manager','Finance','Director') NOT NULL,
    approver_id INT UNSIGNED NOT NULL,
    action      ENUM('Approved','Rejected','Revision_Requested','Verified') NOT NULL,
    comments    TEXT NULL,
    acted_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (approval_id),
    KEY idx_approval_entity (entity_type, entity_id),
    CONSTRAINT fk_approval_user FOREIGN KEY (approver_id) REFERENCES users (user_id)
) ENGINE=InnoDB;

CREATE TABLE notifications (
    notification_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id         INT UNSIGNED NOT NULL,
    title           VARCHAR(200) NOT NULL,
    message         VARCHAR(500) NOT NULL,
    link            VARCHAR(255) NULL,
    is_read         TINYINT(1) NOT NULL DEFAULT 0,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (notification_id),
    KEY idx_notification_user (user_id, is_read),
    CONSTRAINT fk_notification_user FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Sample projects and budget lines (amounts in UGX)
INSERT INTO projects (project_code, project_name, donor_name, description, start_date, end_date, status, created_by) VALUES
('WASH-001', 'Rural Water and Sanitation Project', 'Sample International Donor', 'Improving access to clean water and sanitation in rural communities around Fort Portal.', '2026-01-01', '2026-12-31', 'Active', 1),
('EDU-002',  'Community Education Support',        'Global Education Fund',      'Providing learning materials and teacher support to village schools.',                       '2026-03-01', '2027-02-28', 'Active', 1),
('REL-003',  'Refugee Settlement Relief Support',  'Humanitarian Relief Fund',   'Relief items, shelter kits and protection services for refugee settlements.',                '2026-02-01', '2027-01-31', 'Active', 1);

INSERT INTO budget_lines (project_id, line_code, description, allocated_amount) VALUES
(1, 'B-WASH-01', 'Borehole construction',     50000000.00),
(1, 'B-WASH-02', 'Sanitation training',       20000000.00),
(2, 'B-EDU-01',  'Textbook procurement',      30000000.00),
(2, 'B-EDU-02',  'Teacher stipends',          15000000.00),
(3, 'B-REL-01',  'Food and relief packs',     80000000.00),
(3, 'B-REL-02',  'Shelter kits',              40000000.00);
