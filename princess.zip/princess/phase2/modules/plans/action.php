<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

Auth::require();
if (!is_post()) {
    redirect('modules/plans/index.php');
}

$planId = (int) ($_POST['plan_id'] ?? 0);
$action = (string) ($_POST['action'] ?? '');

try {
    switch ($action) {
        case 'submit':
            PlanWorkflow::submit($planId);
            flash('success', 'Plan submitted to the Manager for approval.');
            break;
        case 'delete':
            PlanWorkflow::delete($planId);
            flash('success', 'Draft deleted.');
            redirect('modules/plans/index.php');
        case 'Approved':
        case 'Rejected':
        case 'Revision_Requested':
            PlanWorkflow::decide($planId, $action, (string) ($_POST['comments'] ?? ''));
            flash('success', 'Your decision has been recorded.');
            break;
        default:
            throw new DomainException('Unknown action.');
    }
} catch (DomainException $e) {
    flash('error', $e->getMessage());
}
redirect('modules/plans/view.php?id=' . $planId);
