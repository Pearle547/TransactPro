<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user = Auth::require();

$q         = (string) input('q', '');
$status    = (string) input('status', '');
$projectId = (int) input('project', 0);
$statuses  = ['Draft', 'Pending_Manager', 'Pending_Finance', 'Approved', 'Rejected', 'Revision_Requested'];

$where  = ['1 = 1'];
$params = [];
if ($user['role'] === 'Staff') {
    $where[]  = 'fp.created_by = ?';
    $params[] = $user['user_id'];
}
if ($q !== '') {
    $where[]  = '(fp.plan_code LIKE ? OR fp.title LIKE ?)';
    $params[] = $params[] = "%$q%";
}
if (in_array($status, $statuses, true)) {
    $where[]  = 'fp.status = ?';
    $params[] = $status;
}
if ($projectId > 0) {
    $where[]  = 'fp.project_id = ?';
    $params[] = $projectId;
}
$whereSql = implode(' AND ', $where);

$page  = paginate((int) DB::val("SELECT COUNT(*) FROM financial_plans fp WHERE $whereSql", $params), 15);
$plans = DB::all(
    "SELECT fp.*, p.project_code, u.full_name AS author
       FROM financial_plans fp JOIN projects p ON p.project_id = fp.project_id JOIN users u ON u.user_id = fp.created_by
      WHERE $whereSql ORDER BY fp.plan_id DESC LIMIT {$page['perPage']} OFFSET {$page['offset']}",
    $params
);
$projects = DB::all('SELECT project_id, project_code, project_name FROM projects ORDER BY project_name');

render_header('Financial plans', 'plans', [
    'subtitle' => $user['role'] === 'Staff' ? 'Your planned activities and their approval status' : 'All planned activities across projects',
    'actions'  => $user['role'] === 'Staff' ? '<a class="btn btn-primary" href="' . e(url('modules/plans/form.php')) . '">+ New plan</a>' : '',
]);
?>
<div class="card">
    <form class="filters" method="get">
        <div class="field grow"><label for="q">Search</label><input class="input" id="q" name="q" value="<?= e($q) ?>" placeholder="Plan code or title"></div>
        <div class="field"><label for="project">Project</label>
            <select class="input" id="project" name="project" data-autosubmit>
                <option value="">All projects</option>
                <?php foreach ($projects as $p): ?><option value="<?= (int) $p['project_id'] ?>"<?= selected($projectId === (int) $p['project_id']) ?>><?= e($p['project_code']) ?></option><?php endforeach; ?>
            </select></div>
        <div class="field"><label for="status">Status</label>
            <select class="input" id="status" name="status" data-autosubmit>
                <option value="">All statuses</option>
                <?php foreach ($statuses as $s): ?><option value="<?= $s ?>"<?= selected($status === $s) ?>><?= e(status_label($s)) ?></option><?php endforeach; ?>
            </select></div>
        <button class="btn" type="submit">Filter</button>
        <a class="btn" href="index.php">Reset</a>
    </form>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Code</th><th>Plan</th><th>Project</th><?php if ($user['role'] !== 'Staff'): ?><th>Author</th><?php endif; ?><th>Activity date</th><th class="num">Amount</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($plans as $pl): ?>
                <tr>
                    <td class="code"><?= e($pl['plan_code']) ?></td>
                    <td><strong><?= e($pl['title']) ?></strong></td>
                    <td><?= e($pl['project_code']) ?></td>
                    <?php if ($user['role'] !== 'Staff'): ?><td><?= e($pl['author']) ?></td><?php endif; ?>
                    <td class="nowrap"><?= e(fdate($pl['planned_date'])) ?></td>
                    <td class="num"><?= e(money($pl['planned_amount'])) ?></td>
                    <td><?= badge($pl['status']) ?></td>
                    <td class="text-right"><a class="btn btn-sm" href="view.php?id=<?= (int) $pl['plan_id'] ?>">Open</a></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$plans): ?><tr><td colspan="8" class="table-empty">No financial plans found.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
    <?= pager($page) ?>
</div>
<?php
render_footer();
