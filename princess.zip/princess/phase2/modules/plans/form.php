<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user    = Auth::require(['Staff']);
$id      = (int) ($_GET['id'] ?? 0);
$editing = $id > 0;
$plan    = $editing ? DB::row('SELECT * FROM financial_plans WHERE plan_id = ?', [$id]) : null;
if ($editing && ($plan === null || (int) $plan['created_by'] !== (int) $user['user_id'])) {
    abort(404, 'That plan does not exist.');
}
if ($editing && !PlanWorkflow::isEditable($plan, $user)) {
    flash('error', 'This plan is already with an approver and can no longer be edited.');
    redirect('modules/plans/view.php?id=' . $id);
}

if (is_post()) {
    $data = [
        'project_id'           => (string) input('project_id', ''),
        'title'                => (string) input('title', ''),
        'activity_description' => (string) input('activity_description', ''),
        'planned_amount'       => str_replace(',', '', (string) input('planned_amount', '')),
        'planned_date'         => (string) input('planned_date', ''),
    ];
    $errors = Validator::validate($data, [
        'project_id'           => 'required|numeric',
        'title'                => 'required|max:200',
        'activity_description' => 'required|min:10',
        'planned_amount'       => 'required|numeric|min_value:1|max_value:9999999999999',
        'planned_date'         => 'required|date',
    ], ['project_id' => 'Project', 'title' => 'Plan title', 'activity_description' => 'Activity description', 'planned_amount' => 'Planned amount', 'planned_date' => 'Activity date']);

    if (!isset($errors['project_id'])) {
        $project = DB::row("SELECT status FROM projects WHERE project_id = ?", [$data['project_id']]);
        if (!$project || $project['status'] !== 'Active') {
            $errors['project_id'] = 'Choose an active project.';
        }
    }
    if ($errors) {
        remember_form($data, $errors);
        redirect('modules/plans/form.php' . ($editing ? "?id=$id" : ''));
    }

    $submit = isset($_POST['submit']);
    try {
        $planId = DB::transaction(function () use ($editing, $id, $data, $submit): int {
            $planId = PlanWorkflow::save($editing ? $id : null, $data);
            if ($submit) {
                PlanWorkflow::submit($planId);
            }
            return $planId;
        });
    } catch (DomainException $e) {
        flash('error', $e->getMessage());
        redirect('modules/plans/index.php');
    }
    flash('success', $submit ? 'Plan submitted to the Manager for approval.' : 'Draft saved.');
    redirect('modules/plans/view.php?id=' . $planId);
}

$v = static fn (string $key, mixed $fallback = '') => old($key, $plan[$key] ?? $fallback);
$projects = DB::all("SELECT project_id, project_code, project_name FROM projects WHERE status = 'Active' ORDER BY project_name");

render_header($editing ? 'Edit plan ' . $plan['plan_code'] : 'New financial plan', 'plans', ['subtitle' => 'Describe the activity and the money you expect to need']);
?>
<?php if ($editing && $plan['status'] === 'Revision_Requested'): ?>
    <div class="alert alert-warning">This plan was returned for revision. Update it and submit it again.</div>
<?php endif; ?>
<div class="card">
    <div class="card-body">
        <form method="post" data-once>
            <?= csrf_field() ?>
            <div class="form-grid">
                <div class="field full">
                    <label for="project_id">Project <span class="req">*</span></label>
                    <select class="input<?= has_error('project_id') ? ' invalid' : '' ?>" id="project_id" name="project_id" required>
                        <option value="">Select a project…</option>
                        <?php foreach ($projects as $p): ?>
                            <option value="<?= (int) $p['project_id'] ?>"<?= selected((string) $v('project_id') === (string) $p['project_id']) ?>><?= e($p['project_code'] . ' — ' . $p['project_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?= field_error('project_id') ?>
                </div>
                <div class="field full">
                    <label for="title">Plan title <span class="req">*</span></label>
                    <input class="input<?= has_error('title') ? ' invalid' : '' ?>" id="title" name="title" value="<?= e($v('title')) ?>" placeholder="e.g. Borehole site assessments — Kabarole" required>
                    <?= field_error('title') ?>
                </div>
                <div class="field">
                    <label for="planned_amount">Planned amount (UGX) <span class="req">*</span></label>
                    <input class="input<?= has_error('planned_amount') ? ' invalid' : '' ?>" id="planned_amount" name="planned_amount" inputmode="decimal" value="<?= e($v('planned_amount')) ?>" required>
                    <?= field_error('planned_amount') ?>
                </div>
                <div class="field">
                    <label for="planned_date">Activity date <span class="req">*</span></label>
                    <input class="input<?= has_error('planned_date') ? ' invalid' : '' ?>" type="date" id="planned_date" name="planned_date" value="<?= e($v('planned_date')) ?>" required>
                    <?= field_error('planned_date') ?>
                </div>
                <div class="field full">
                    <label for="activity_description">Activity description <span class="req">*</span></label>
                    <textarea class="input<?= has_error('activity_description') ? ' invalid' : '' ?>" id="activity_description" name="activity_description" rows="6" required><?= e($v('activity_description')) ?></textarea>
                    <span class="hint">What will be done, where, who is involved and what it will cost.</span>
                    <?= field_error('activity_description') ?>
                </div>
            </div>
            <div class="form-actions">
                <a class="btn" href="<?= e(url('modules/plans/index.php')) ?>">Cancel</a>
                <button class="btn" type="submit" name="draft" value="1">Save draft</button>
                <button class="btn btn-primary" type="submit" name="submit" value="1">Submit for approval</button>
            </div>
        </form>
    </div>
</div>
<?php
render_footer();
