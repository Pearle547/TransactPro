<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user = Auth::require();
$id   = (int) ($_GET['id'] ?? 0);
$plan = DB::row(
    'SELECT fp.*, p.project_code, p.project_name, u.full_name AS author, u.department
       FROM financial_plans fp JOIN projects p ON p.project_id = fp.project_id JOIN users u ON u.user_id = fp.created_by
      WHERE fp.plan_id = ?',
    [$id]
);
if ($plan === null || !PlanWorkflow::canView($plan, $user)) {
    abort(404, 'That plan does not exist.');
}

$editable  = PlanWorkflow::isEditable($plan, $user);
$canDecide = PlanWorkflow::canDecide($plan, $user);
$history   = Approvals::history('plan', $id);

// Approval route: Manager → Finance → Approved
$status = $plan['status'];
$route  = [
    'Manager' => $status === 'Pending_Manager' ? 'current' : (in_array($status, ['Pending_Finance', 'Approved'], true) ? 'done' : ''),
    'Finance' => $status === 'Pending_Finance' ? 'current' : ($status === 'Approved' ? 'done' : ''),
    'Approved' => $status === 'Approved' ? 'done' : '',
];

$actions = '';
if ($editable) {
    $actions .= '<a class="btn" href="' . e(url('modules/plans/form.php?id=' . $id)) . '">Edit</a>';
}
render_header($plan['plan_code'], 'plans', ['subtitle' => $plan['title'], 'actions' => $actions]);
?>
<div class="grid grid-main">
    <div>
        <div class="card">
            <div class="card-head"><h3>Plan details</h3><?= badge($plan['status']) ?></div>
            <div class="card-body">
                <div class="route" aria-label="Approval route">
                    <span class="step done">Author</span><span class="sep">→</span>
                    <?php foreach ($route as $label => $state): ?>
                        <span class="step <?= e($state) ?>"><?= e($label) ?></span><?= $label !== 'Approved' ? '<span class="sep">→</span>' : '' ?>
                    <?php endforeach; ?>
                </div>
                <dl class="kv">
                    <div><dt>Project</dt><dd><a href="<?= e(url('modules/projects/view.php?id=' . (int) $plan['project_id'])) ?>"><?= e($plan['project_code'] . ' — ' . $plan['project_name']) ?></a></dd></div>
                    <div><dt>Planned amount</dt><dd><?= e(money($plan['planned_amount'])) ?></dd></div>
                    <div><dt>Prepared by</dt><dd><?= e($plan['author']) ?><?= $plan['department'] ? ' · ' . e($plan['department']) : '' ?></dd></div>
                    <div><dt>Activity date</dt><dd><?= e(fdate($plan['planned_date'])) ?></dd></div>
                    <div><dt>Submitted</dt><dd><?= e(fdatetime($plan['submitted_at'])) ?></dd></div>
                    <div><dt>Last decision</dt><dd><?= e(fdatetime($plan['reviewed_at'])) ?></dd></div>
                    <div class="wide"><dt>Activity description</dt><dd class="prose"><?= e($plan['activity_description']) ?></dd></div>
                </dl>
            </div>
        </div>

        <?php if ($canDecide): ?>
        <div class="card">
            <div class="card-head"><h3>Your decision — <?= e($user['role']) ?> review</h3></div>
            <div class="card-body">
                <form method="post" action="action.php" data-once>
                    <?= csrf_field() ?>
                    <input type="hidden" name="plan_id" value="<?= $id ?>">
                    <div class="field">
                        <label for="comments">Comments</label>
                        <textarea class="input" id="comments" name="comments" placeholder="Required when rejecting or requesting a revision"></textarea>
                    </div>
                    <div class="form-actions">
                        <button class="btn btn-danger" type="submit" name="action" value="Rejected" data-confirm="Reject this plan?">Reject</button>
                        <button class="btn btn-warning" type="submit" name="action" value="Revision_Requested">Request revision</button>
                        <button class="btn btn-success" type="submit" name="action" value="Approved">Approve</button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($editable): ?>
        <div class="card">
            <div class="card-head"><h3>Ready to go?</h3></div>
            <div class="card-body">
                <p>Submitting sends this plan to the Manager. You will not be able to edit it while it is being reviewed.</p>
                <form method="post" action="action.php" class="btn-row" data-once>
                    <?= csrf_field() ?>
                    <input type="hidden" name="plan_id" value="<?= $id ?>">
                    <button class="btn btn-primary" type="submit" name="action" value="submit">Submit for approval</button>
                    <?php if ($plan['status'] === 'Draft'): ?>
                        <button class="btn btn-danger" type="submit" name="action" value="delete" data-confirm="Delete this draft permanently?">Delete draft</button>
                    <?php endif; ?>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="card">
        <div class="card-head"><h3>Approval history</h3></div>
        <div class="card-body"><?= Approvals::timeline($history, $plan['submitted_at'] ? ['Submitted by ' . $plan['author'], $plan['submitted_at']] : null) ?></div>
    </div>
</div>
<?php
render_footer();
