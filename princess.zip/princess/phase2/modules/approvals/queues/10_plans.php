<?php
/** @var array $user */
$status = match ($user['role']) {
    'Manager' => ['Pending_Manager'],
    'Finance' => ['Pending_Finance'],
    'Admin'   => ['Pending_Manager', 'Pending_Finance'],
    default   => [],
};
if (!$status) {
    return;
}
$marks = implode(',', array_fill(0, count($status), '?'));
$rows  = DB::all(
    "SELECT fp.plan_id, fp.plan_code, fp.title, fp.planned_amount, fp.status, fp.submitted_at, p.project_code, u.full_name AS author
       FROM financial_plans fp JOIN projects p ON p.project_id = fp.project_id JOIN users u ON u.user_id = fp.created_by
      WHERE fp.status IN ($marks) ORDER BY fp.submitted_at",
    $status
);
if (!$rows) {
    return;
}
?>
<div class="card">
    <div class="card-head"><h3>Financial plans (<?= count($rows) ?>)</h3></div>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Code</th><th>Plan</th><th>Project</th><th>Author</th><th class="num">Amount</th><th>Waiting</th><th>Stage</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="code"><?= e($r['plan_code']) ?></td>
                    <td><?= e($r['title']) ?></td>
                    <td><?= e($r['project_code']) ?></td>
                    <td><?= e($r['author']) ?></td>
                    <td class="num"><?= e(money($r['planned_amount'])) ?></td>
                    <td class="nowrap"><?= e(time_ago($r['submitted_at'])) ?></td>
                    <td><?= badge($r['status']) ?></td>
                    <td class="text-right"><a class="btn btn-sm btn-primary" href="<?= e(url('modules/plans/view.php?id=' . (int) $r['plan_id'])) ?>">Review</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
