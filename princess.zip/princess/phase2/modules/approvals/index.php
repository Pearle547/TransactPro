<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user = Auth::require(['Admin', 'Manager', 'Finance', 'Director']);

// Each phase contributes queue sections (queues/*.php). A section prints nothing when it has no items for this role.
$sections = [];
foreach (glob(__DIR__ . '/queues/*.php') ?: [] as $queue) {
    ob_start();
    include $queue;
    $html = trim((string) ob_get_clean());
    if ($html !== '') {
        $sections[] = $html;
    }
}

render_header('Approvals', 'approvals', ['subtitle' => $user['role'] === 'Admin' ? 'Everything currently awaiting a decision (view only)' : 'Items waiting for your decision']);

if ($sections) {
    echo implode("\n", $sections);
} else {
    echo '<div class="card"><div class="card-body empty"><h2>All caught up</h2><p>Nothing is waiting for your approval right now.</p></div></div>';
}
render_footer();
