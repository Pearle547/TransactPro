<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user = Auth::require();
$uid  = (int) $user['user_id'];

if (is_post()) {
    DB::exec('UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0', [$uid]);
    flash('success', 'All notifications marked as read.');
    redirect('modules/notifications/index.php');
}

$page = paginate((int) DB::val('SELECT COUNT(*) FROM notifications WHERE user_id = ?', [$uid]), 20);
$rows = DB::all("SELECT * FROM notifications WHERE user_id = ? ORDER BY notification_id DESC LIMIT {$page['perPage']} OFFSET {$page['offset']}", [$uid]);
$unread = Notify::unreadCount($uid);

$actions = $unread > 0
    ? '<form method="post" class="inline">' . csrf_field() . '<button class="btn" type="submit">Mark all as read</button></form>'
    : '';
render_header('Notifications', 'notifications', ['subtitle' => $unread . ' unread', 'actions' => $actions]);
?>
<div class="card">
    <div class="card-body flush">
        <?php foreach ($rows as $n): ?>
            <a class="notice<?= $n['is_read'] ? '' : ' unread' ?>" href="<?= e(url('modules/notifications/open.php?id=' . (int) $n['notification_id'])) ?>">
                <div>
                    <strong><?= e($n['title']) ?></strong>
                    <div><?= e($n['message']) ?></div>
                </div>
                <small class="muted nowrap"><?= e(time_ago($n['created_at'])) ?></small>
            </a>
        <?php endforeach; ?>
        <?php if (!$rows): ?><div class="empty"><h2>No notifications</h2><p>You will be alerted here when something needs your attention.</p></div><?php endif; ?>
    </div>
    <?= pager($page) ?>
</div>
<?php
render_footer();
