<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

Auth::require();
$id = (int) ($_GET['id'] ?? 0);
$n  = DB::row('SELECT * FROM notifications WHERE notification_id = ? AND user_id = ?', [$id, Auth::id()]);
if ($n === null) {
    redirect('modules/notifications/index.php');
}
DB::exec('UPDATE notifications SET is_read = 1 WHERE notification_id = ?', [$id]);

// Links are stored by the application itself; still, only follow simple relative paths.
$link = $n['link'] ?? '';
redirect(preg_match('#^[A-Za-z0-9_\-./]+(\?[A-Za-z0-9_=&%\-]*)?$#', $link) ? $link : 'modules/notifications/index.php');
