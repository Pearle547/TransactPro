<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user      = Auth::require(['Admin', 'Finance', 'Manager', 'Director']);
$canManage = in_array($user['role'], ['Admin', 'Finance'], true);

$projectId = (int) input('project', 0);
$lines     = Budget::lines($projectId > 0 ? $projectId : null);
$projects  = DB::all('SELECT project_id, project_code, project_name FROM projects ORDER BY project_name');

$totals = ['allocated' => 0.0, 'committed' => 0.0, 'utilised' => 0.0, 'available' => 0.0];
foreach ($lines as $l) {
    $totals['allocated'] += (float) $l['allocated_amount'];
    $totals['committed'] += (float) $l['committed'];
    $totals['utilised']  += (float) $l['utilised'];
    $totals['available'] += (float) $l['available'];
}

render_header('Budget lines', 'budgets', [
    'subtitle' => 'Allocated funds per project activity and how much is left',
    'actions'  => $canManage ? '<a class="btn btn-primary" href="' . e(url('modules/budgets/form.php')) . '">+ New budget line</a>' : '',
]);
?>
<div class="card">
    <form class="filters" method="get">
        <div class="field grow"><label for="project">Project</label>
            <select class="input" id="project" name="project" data-autosubmit>
                <option value="">All projects</option>
                <?php foreach ($projects as $p): ?><option value="<?= (int) $p['project_id'] ?>"<?= selected($projectId === (int) $p['project_id']) ?>><?= e($p['project_code'] . ' — ' . $p['project_name']) ?></option><?php endforeach; ?>
            </select></div>
        <a class="btn" href="index.php">Reset</a>
    </form>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Project</th><th>Line</th><th>Description</th><th class="num">Allocated</th><th class="num">Committed</th><th class="num">Spent</th><th class="num">Available</th><th>Used</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($lines as $l): $pct = Budget::usedPercent($l); ?>
                <tr>
                    <td><?= e($l['project_code']) ?></td>
                    <td class="code"><?= e($l['line_code']) ?></td>
                    <td><?= e($l['description']) ?></td>
                    <td class="num"><?= e(money($l['allocated_amount'])) ?></td>
                    <td class="num"><?= e(money($l['committed'])) ?></td>
                    <td class="num"><?= e(money($l['utilised'])) ?></td>
                    <td class="num"><strong><?= e(money($l['available'])) ?></strong></td>
                    <td><div class="progress<?= $pct > 90 ? ' danger' : ($pct > 70 ? ' warn' : '') ?>" title="<?= round($pct) ?>% used"><span style="width:<?= round($pct, 1) ?>%"></span></div></td>
                    <td class="text-right"><?php if ($canManage): ?><a class="btn btn-sm" href="form.php?id=<?= (int) $l['budget_line_id'] ?>">Edit</a><?php endif; ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$lines): ?><tr><td colspan="9" class="table-empty">No budget lines found.</td></tr><?php endif; ?>
            </tbody>
            <?php if ($lines): ?>
            <tfoot><tr>
                <td colspan="3">Total</td>
                <td class="num"><?= e(money($totals['allocated'])) ?></td>
                <td class="num"><?= e(money($totals['committed'])) ?></td>
                <td class="num"><?= e(money($totals['utilised'])) ?></td>
                <td class="num"><?= e(money($totals['available'])) ?></td>
                <td colspan="2"></td>
            </tr></tfoot>
            <?php endif; ?>
        </table>
    </div>
</div>
<?php
render_footer();
