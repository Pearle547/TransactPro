<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

Auth::require(['Admin', 'Finance']);
$id      = (int) ($_GET['id'] ?? 0);
$editing = $id > 0;
$line    = $editing ? Budget::find($id) : null;
if ($editing && $line === null) {
    abort(404, 'That budget line does not exist.');
}
$projects = DB::all("SELECT project_id, project_code, project_name FROM projects WHERE status <> 'Completed' ORDER BY project_name");

if (is_post()) {
    $data = [
        'project_id'       => (string) input('project_id', ''),
        'line_code'        => strtoupper((string) input('line_code', '')),
        'description'      => (string) input('description', ''),
        'allocated_amount' => str_replace(',', '', (string) input('allocated_amount', '')),
    ];
    if ($editing) {
        $data['project_id'] = (string) $line['project_id'];   // a line never moves between projects
    }
    $errors = Validator::validate($data, [
        'project_id'       => 'required|numeric',
        'line_code'        => 'required|max:30',
        'description'      => 'required|max:255',
        'allocated_amount' => 'required|numeric|min_value:0|max_value:9999999999999',
    ], ['project_id' => 'Project', 'line_code' => 'Line code', 'allocated_amount' => 'Allocated amount']);

    if (!isset($errors['project_id']) && !DB::val('SELECT COUNT(*) FROM projects WHERE project_id = ?', [$data['project_id']])) {
        $errors['project_id'] = 'Choose a valid project.';
    }
    if (!isset($errors['line_code']) && !isset($errors['project_id']) &&
        DB::val('SELECT COUNT(*) FROM budget_lines WHERE project_id = ? AND line_code = ? AND budget_line_id <> ?', [$data['project_id'], $data['line_code'], $id]) > 0) {
        $errors['line_code'] = 'This code is already used in the project.';
    }
    if ($editing && !isset($errors['allocated_amount'])) {
        $inUse = (float) $line['committed'] + (float) $line['utilised'];
        if ((float) $data['allocated_amount'] < $inUse) {
            $errors['allocated_amount'] = 'Cannot be less than the ' . money($inUse) . ' already committed or spent on this line.';
        }
    }
    if ($errors) {
        remember_form($data, $errors);
        redirect('modules/budgets/form.php' . ($editing ? "?id=$id" : ($data['project_id'] !== '' ? '?project_id=' . (int) $data['project_id'] : '')));
    }

    if ($editing) {
        DB::exec('UPDATE budget_lines SET line_code = ?, description = ?, allocated_amount = ? WHERE budget_line_id = ?',
            [$data['line_code'], $data['description'], $data['allocated_amount'], $id]);
        Audit::log('Budget line updated', 'Budgets', $id, "{$data['line_code']}: allocation " . money($line['allocated_amount']) . ' → ' . money($data['allocated_amount']));
        flash('success', 'Budget line updated.');
    } else {
        $id = DB::insert('INSERT INTO budget_lines (project_id, line_code, description, allocated_amount) VALUES (?, ?, ?, ?)',
            [$data['project_id'], $data['line_code'], $data['description'], $data['allocated_amount']]);
        Audit::log('Budget line created', 'Budgets', $id, "{$data['line_code']} allocated " . money($data['allocated_amount']));
        flash('success', 'Budget line created.');
    }
    redirect('modules/projects/view.php?id=' . (int) $data['project_id']);
}

$v = static fn (string $key, mixed $fallback = '') => old($key, $line[$key] ?? $fallback);
$preselected = $editing ? (int) $line['project_id'] : (int) old('project_id', $_GET['project_id'] ?? 0);

render_header($editing ? 'Edit budget line' : 'New budget line', 'budgets');
?>
<div class="card">
    <div class="card-body">
        <form method="post" data-once>
            <?= csrf_field() ?>
            <div class="form-grid">
                <div class="field full">
                    <label for="project_id">Project <span class="req">*</span></label>
                    <select class="input<?= has_error('project_id') ? ' invalid' : '' ?>" id="project_id" name="project_id" <?= $editing ? 'disabled' : 'required' ?>>
                        <option value="">Select a project…</option>
                        <?php foreach ($projects as $p): ?>
                            <option value="<?= (int) $p['project_id'] ?>"<?= selected($preselected === (int) $p['project_id']) ?>><?= e($p['project_code'] . ' — ' . $p['project_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?= field_error('project_id') ?>
                </div>
                <div class="field">
                    <label for="line_code">Line code <span class="req">*</span></label>
                    <input class="input<?= has_error('line_code') ? ' invalid' : '' ?>" id="line_code" name="line_code" value="<?= e($v('line_code')) ?>" placeholder="e.g. B-WASH-01" required>
                    <?= field_error('line_code') ?>
                </div>
                <div class="field">
                    <label for="allocated_amount">Allocated amount (UGX) <span class="req">*</span></label>
                    <input class="input<?= has_error('allocated_amount') ? ' invalid' : '' ?>" id="allocated_amount" name="allocated_amount" inputmode="decimal" value="<?= e($v('allocated_amount')) ?>" required>
                    <?= field_error('allocated_amount') ?>
                </div>
                <div class="field full">
                    <label for="description">Description <span class="req">*</span></label>
                    <input class="input<?= has_error('description') ? ' invalid' : '' ?>" id="description" name="description" value="<?= e($v('description')) ?>" required>
                    <?= field_error('description') ?>
                </div>
            </div>
            <div class="form-actions">
                <a class="btn" href="<?= e(url('modules/budgets/index.php')) ?>">Cancel</a>
                <button class="btn btn-primary" type="submit"><?= $editing ? 'Save changes' : 'Create budget line' ?></button>
            </div>
        </form>
    </div>
</div>
<?php
render_footer();
