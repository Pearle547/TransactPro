<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user      = Auth::require();
$canManage = in_array($user['role'], ['Admin', 'Finance'], true);

$id      = (int) ($_GET['id'] ?? 0);
$project = DB::row('SELECT p.*, u.full_name AS creator FROM projects p LEFT JOIN users u ON u.user_id = p.created_by WHERE p.project_id = ?', [$id]);
if ($project === null) {
    abort(404, 'That project does not exist.');
}

$lines   = Budget::lines($id);
$summary = Budget::projectSummaries()[$id] ?? ['allocated' => 0, 'committed' => 0, 'utilised' => 0, 'available' => 0];

$planSql    = 'SELECT plan_id, plan_code, title, planned_amount, status FROM financial_plans WHERE project_id = ?';
$planParams = [$id];
if ($user['role'] === 'Staff') {
    $planSql    .= ' AND created_by = ?';
    $planParams[] = $user['user_id'];
}
$plans = DB::all($planSql . ' ORDER BY plan_id DESC LIMIT 8', $planParams);

$actions = '';
if ($canManage) {
    $actions = '<a class="btn" href="' . e(url('modules/budgets/form.php?project_id=' . $id)) . '">+ Add budget line</a>'
        . '<a class="btn btn-primary" href="' . e(url('modules/projects/form.php?id=' . $id)) . '">Edit project</a>';
}
render_header($project['project_code'] . ' — ' . $project['project_name'], 'projects', ['subtitle' => 'Funded by ' . $project['donor_name'], 'actions' => $actions]);
?>
<div class="stats">
    <div class="stat"><div class="stat-label">Allocated</div><div class="stat-value"><?= e(money($summary['allocated'])) ?></div><div class="stat-note"><?= count($lines) ?> budget line(s)</div></div>
    <div class="stat warn"><div class="stat-label">Committed</div><div class="stat-value"><?= e(money($summary['committed'])) ?></div><div class="stat-note">Requested &amp; awaiting accountability</div></div>
    <div class="stat danger"><div class="stat-label">Spent &amp; verified</div><div class="stat-value"><?= e(money($summary['utilised'])) ?></div><div class="stat-note">Closed and reconciled</div></div>
    <div class="stat ok"><div class="stat-label">Available</div><div class="stat-value"><?= e(money($summary['available'])) ?></div><div class="stat-note">Free to request</div></div>
</div>

<div class="grid grid-main">
    <div>
        <div class="card">
            <div class="card-head"><h3>Budget lines</h3></div>
            <div class="card-body flush table-wrap">
                <table class="table">
                    <thead><tr><th>Code</th><th>Description</th><th class="num">Allocated</th><th class="num">Available</th><th>Used</th></tr></thead>
                    <tbody>
                    <?php foreach ($lines as $l): $pct = Budget::usedPercent($l); ?>
                        <tr>
                            <td class="code"><?= e($l['line_code']) ?></td>
                            <td><?= e($l['description']) ?></td>
                            <td class="num"><?= e(money($l['allocated_amount'])) ?></td>
                            <td class="num"><?= e(money($l['available'])) ?></td>
                            <td><div class="progress<?= $pct > 90 ? ' danger' : ($pct > 70 ? ' warn' : '') ?>" title="<?= round($pct) ?>% used"><span style="width:<?= round($pct, 1) ?>%"></span></div></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$lines): ?><tr><td colspan="5" class="table-empty">No budget lines yet.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php foreach (glob(__DIR__ . '/panels/*.php') ?: [] as $panel) { include $panel; } ?>
    </div>

    <div>
        <div class="card">
            <div class="card-head"><h3>Project details</h3><?= badge($project['status']) ?></div>
            <div class="card-body">
                <dl class="kv">
                    <div><dt>Start</dt><dd><?= e(fdate($project['start_date'])) ?></dd></div>
                    <div><dt>End</dt><dd><?= e(fdate($project['end_date'])) ?></dd></div>
                    <div class="wide"><dt>Donor</dt><dd><?= e($project['donor_name']) ?></dd></div>
                    <div class="wide"><dt>Description</dt><dd class="prose"><?= e($project['description'] ?: '—') ?></dd></div>
                    <div class="wide"><dt>Created by</dt><dd><?= e($project['creator'] ?? '—') ?>, <?= e(fdate($project['created_at'])) ?></dd></div>
                </dl>
            </div>
        </div>
        <div class="card">
            <div class="card-head"><h3>Recent financial plans</h3></div>
            <div class="card-body flush">
                <table class="table">
                    <tbody>
                    <?php foreach ($plans as $pl): ?>
                        <tr>
                            <td><a href="<?= e(url('modules/plans/view.php?id=' . (int) $pl['plan_id'])) ?>"><?= e($pl['plan_code']) ?></a><br><small class="muted"><?= e($pl['title']) ?></small></td>
                            <td class="num"><?= e(money($pl['planned_amount'])) ?><br><?= badge($pl['status']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$plans): ?><tr><td class="table-empty">No plans for this project.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
render_footer();
