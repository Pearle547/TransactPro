<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user      = Auth::require();
$canManage = in_array($user['role'], ['Admin', 'Finance'], true);

$q      = (string) input('q', '');
$status = (string) input('status', '');

$where  = ['1 = 1'];
$params = [];
if ($q !== '') {
    $where[]  = '(project_code LIKE ? OR project_name LIKE ? OR donor_name LIKE ?)';
    $params[] = $params[] = $params[] = "%$q%";
}
if (in_array($status, ['Active', 'Completed', 'Suspended'], true)) {
    $where[]  = 'status = ?';
    $params[] = $status;
}
$projects  = DB::all('SELECT * FROM projects WHERE ' . implode(' AND ', $where) . ' ORDER BY project_name', $params);
$summaries = Budget::projectSummaries();

render_header('Projects & donors', 'projects', [
    'subtitle' => 'Donor-funded projects and their budgets',
    'actions'  => $canManage ? '<a class="btn btn-primary" href="' . e(url('modules/projects/form.php')) . '">+ New project</a>' : '',
]);
?>
<div class="card">
    <form class="filters" method="get">
        <div class="field grow"><label for="q">Search</label><input class="input" id="q" name="q" value="<?= e($q) ?>" placeholder="Code, name or donor"></div>
        <div class="field"><label for="status">Status</label>
            <select class="input" id="status" name="status" data-autosubmit>
                <option value="">All</option>
                <?php foreach (['Active', 'Completed', 'Suspended'] as $s): ?><option<?= selected($status === $s) ?>><?= $s ?></option><?php endforeach; ?>
            </select></div>
        <button class="btn" type="submit">Filter</button>
        <a class="btn" href="index.php">Reset</a>
    </form>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Code</th><th>Project</th><th>Donor</th><th>Period</th><th class="num">Allocated</th><th class="num">Available</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($projects as $p): $s = $summaries[(int) $p['project_id']] ?? ['allocated' => 0, 'available' => 0]; ?>
                <tr>
                    <td class="code"><?= e($p['project_code']) ?></td>
                    <td><strong><?= e($p['project_name']) ?></strong></td>
                    <td><?= e($p['donor_name']) ?></td>
                    <td class="nowrap"><?= e(fdate($p['start_date'])) ?> – <?= e(fdate($p['end_date'])) ?></td>
                    <td class="num"><?= e(money($s['allocated'])) ?></td>
                    <td class="num"><?= e(money($s['available'])) ?></td>
                    <td><?= badge($p['status']) ?></td>
                    <td class="text-right nowrap">
                        <a class="btn btn-sm" href="view.php?id=<?= (int) $p['project_id'] ?>">View</a>
                        <?php if ($canManage): ?><a class="btn btn-sm" href="form.php?id=<?= (int) $p['project_id'] ?>">Edit</a><?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$projects): ?><tr><td colspan="8" class="table-empty">No projects found.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php
render_footer();
