<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

Auth::require(['Admin', 'Finance']);
$id      = (int) ($_GET['id'] ?? 0);
$editing = $id > 0;
$project = $editing ? DB::row('SELECT * FROM projects WHERE project_id = ?', [$id]) : null;
if ($editing && $project === null) {
    abort(404, 'That project does not exist.');
}

if (is_post()) {
    $data = [
        'project_code' => strtoupper((string) input('project_code', '')),
        'project_name' => (string) input('project_name', ''),
        'donor_name'   => (string) input('donor_name', ''),
        'description'  => (string) input('description', ''),
        'start_date'   => (string) input('start_date', ''),
        'end_date'     => (string) input('end_date', ''),
        'status'       => (string) input('status', 'Active'),
    ];
    $errors = Validator::validate($data, [
        'project_code' => 'required|max:30',
        'project_name' => 'required|max:200',
        'donor_name'   => 'required|max:200',
        'start_date'   => 'required|date',
        'end_date'     => 'required|date',
        'status'       => 'required|in:Active,Completed,Suspended',
    ], ['project_code' => 'Project code', 'project_name' => 'Project name', 'donor_name' => 'Donor']);

    if (!isset($errors['end_date']) && !isset($errors['start_date']) && $data['end_date'] < $data['start_date']) {
        $errors['end_date'] = 'End date cannot be earlier than the start date.';
    }
    if (!isset($errors['project_code']) && DB::val('SELECT COUNT(*) FROM projects WHERE project_code = ? AND project_id <> ?', [$data['project_code'], $id]) > 0) {
        $errors['project_code'] = 'This project code is already in use.';
    }
    if ($errors) {
        remember_form($data, $errors);
        redirect('modules/projects/form.php' . ($editing ? "?id=$id" : ''));
    }

    if ($editing) {
        DB::exec(
            'UPDATE projects SET project_code = ?, project_name = ?, donor_name = ?, description = ?, start_date = ?, end_date = ?, status = ? WHERE project_id = ?',
            [$data['project_code'], $data['project_name'], $data['donor_name'], $data['description'] ?: null, $data['start_date'], $data['end_date'], $data['status'], $id]
        );
        Audit::log('Project updated', 'Projects', $id, "Updated project {$data['project_code']}");
        flash('success', 'Project updated.');
    } else {
        $id = DB::insert(
            'INSERT INTO projects (project_code, project_name, donor_name, description, start_date, end_date, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [$data['project_code'], $data['project_name'], $data['donor_name'], $data['description'] ?: null, $data['start_date'], $data['end_date'], $data['status'], Auth::id()]
        );
        Audit::log('Project created', 'Projects', $id, "Created project {$data['project_code']} — {$data['project_name']}");
        flash('success', 'Project created. Add its budget lines next.');
    }
    redirect('modules/projects/view.php?id=' . $id);
}

$v = static fn (string $key, mixed $fallback = '') => old($key, $project[$key] ?? $fallback);

render_header($editing ? 'Edit project' : 'New project', 'projects');
?>
<div class="card">
    <div class="card-body">
        <form method="post" data-once>
            <?= csrf_field() ?>
            <div class="form-grid">
                <div class="field">
                    <label for="project_code">Project code <span class="req">*</span></label>
                    <input class="input<?= has_error('project_code') ? ' invalid' : '' ?>" id="project_code" name="project_code" value="<?= e($v('project_code')) ?>" placeholder="e.g. WASH-001" required>
                    <?= field_error('project_code') ?>
                </div>
                <div class="field">
                    <label for="status">Status</label>
                    <select class="input" id="status" name="status">
                        <?php foreach (['Active', 'Completed', 'Suspended'] as $s): ?><option<?= selected($v('status', 'Active') === $s) ?>><?= $s ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="field full">
                    <label for="project_name">Project name <span class="req">*</span></label>
                    <input class="input<?= has_error('project_name') ? ' invalid' : '' ?>" id="project_name" name="project_name" value="<?= e($v('project_name')) ?>" required>
                    <?= field_error('project_name') ?>
                </div>
                <div class="field full">
                    <label for="donor_name">Donor <span class="req">*</span></label>
                    <input class="input<?= has_error('donor_name') ? ' invalid' : '' ?>" id="donor_name" name="donor_name" value="<?= e($v('donor_name')) ?>" required>
                    <?= field_error('donor_name') ?>
                </div>
                <div class="field">
                    <label for="start_date">Start date <span class="req">*</span></label>
                    <input class="input<?= has_error('start_date') ? ' invalid' : '' ?>" type="date" id="start_date" name="start_date" value="<?= e($v('start_date')) ?>" required>
                    <?= field_error('start_date') ?>
                </div>
                <div class="field">
                    <label for="end_date">End date <span class="req">*</span></label>
                    <input class="input<?= has_error('end_date') ? ' invalid' : '' ?>" type="date" id="end_date" name="end_date" value="<?= e($v('end_date')) ?>" required>
                    <?= field_error('end_date') ?>
                </div>
                <div class="field full">
                    <label for="description">Description</label>
                    <textarea class="input" id="description" name="description"><?= e($v('description')) ?></textarea>
                </div>
            </div>
            <div class="form-actions">
                <a class="btn" href="<?= e(url('modules/projects/index.php')) ?>">Cancel</a>
                <button class="btn btn-primary" type="submit"><?= $editing ? 'Save changes' : 'Create project' ?></button>
            </div>
        </form>
    </div>
</div>
<?php
render_footer();
