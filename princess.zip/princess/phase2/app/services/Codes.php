<?php
declare(strict_types=1);

/**
 * Human-readable record codes such as FP-2026-00012.
 *
 * The code is derived from the auto-increment id, so two people saving at the same moment can never collide.
 */
final class Codes
{
    public static function make(string $prefix, int $id): string
    {
        return sprintf('%s-%s-%05d', $prefix, date('Y'), $id);
    }

    /** Throw-away unique value used between INSERT and the follow-up UPDATE that sets the real code. */
    public static function placeholder(): string
    {
        return 'TMP-' . bin2hex(random_bytes(8));
    }
}
