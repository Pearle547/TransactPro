<?php
declare(strict_types=1);

/**
 * Financial plan lifecycle:
 *
 *   Draft → Pending_Manager → Pending_Finance → Approved
 *                 ↘ Rejected / Revision_Requested (back to the author) ↙
 *
 * Business-rule failures throw DomainException; the message is safe to show to the user.
 */
final class PlanWorkflow
{
    /** Role that must act while the plan is in the given status. */
    public static function stageRole(string $status): ?string
    {
        return match ($status) {
            'Pending_Manager' => 'Manager',
            'Pending_Finance' => 'Finance',
            default           => null,
        };
    }

    public static function canView(array $plan, array $user): bool
    {
        return $user['role'] !== 'Staff' || (int) $plan['created_by'] === (int) $user['user_id'];
    }

    public static function isEditable(array $plan, array $user): bool
    {
        return (int) $plan['created_by'] === (int) $user['user_id']
            && in_array($plan['status'], ['Draft', 'Revision_Requested'], true);
    }

    public static function canDecide(array $plan, array $user): bool
    {
        return self::stageRole($plan['status']) === $user['role']
            && (int) $plan['created_by'] !== (int) $user['user_id'];
    }

    /** Insert or update a plan owned by the signed-in user. Returns the plan id. */
    public static function save(?int $planId, array $data): int
    {
        $user = Auth::user();
        if ($planId === null) {
            $id = DB::insert(
                'INSERT INTO financial_plans (plan_code, project_id, created_by, title, activity_description, planned_amount, planned_date)
                 VALUES (?, ?, ?, ?, ?, ?, ?)',
                [Codes::placeholder(), $data['project_id'], $user['user_id'], $data['title'], $data['activity_description'], $data['planned_amount'], $data['planned_date']]
            );
            DB::exec('UPDATE financial_plans SET plan_code = ? WHERE plan_id = ?', [Codes::make('FP', $id), $id]);
            Audit::log('Plan created', 'Financial plans', $id, "Created plan '{$data['title']}' for " . money($data['planned_amount']));
            return $id;
        }

        $plan = DB::row('SELECT * FROM financial_plans WHERE plan_id = ?', [$planId]);
        if (!$plan || !self::isEditable($plan, $user)) {
            throw new DomainException('This plan can no longer be edited.');
        }
        DB::exec(
            'UPDATE financial_plans SET project_id = ?, title = ?, activity_description = ?, planned_amount = ?, planned_date = ? WHERE plan_id = ?',
            [$data['project_id'], $data['title'], $data['activity_description'], $data['planned_amount'], $data['planned_date'], $planId]
        );
        Audit::log('Plan updated', 'Financial plans', $planId, "Edited plan {$plan['plan_code']}");
        return $planId;
    }

    public static function submit(int $planId): void
    {
        $user = Auth::user();
        DB::transaction(function () use ($planId, $user): void {
            $plan = DB::row('SELECT * FROM financial_plans WHERE plan_id = ? FOR UPDATE', [$planId]);
            if (!$plan || !self::isEditable($plan, $user)) {
                throw new DomainException('Only your own draft or returned plans can be submitted.');
            }
            DB::exec("UPDATE financial_plans SET status = 'Pending_Manager', submitted_at = NOW(), reviewed_at = NULL WHERE plan_id = ?", [$planId]);
            Audit::log('Plan submitted', 'Financial plans', $planId, "Submitted {$plan['plan_code']} to the Manager");
            Notify::role('Manager', 'Plan awaiting your review', "{$plan['plan_code']} — {$plan['title']} (" . money($plan['planned_amount']) . ') was submitted by ' . $user['full_name'] . '.', 'modules/plans/view.php?id=' . $planId);
        });
    }

    public static function delete(int $planId): void
    {
        $user = Auth::user();
        DB::transaction(function () use ($planId, $user): void {
            $plan = DB::row('SELECT * FROM financial_plans WHERE plan_id = ? FOR UPDATE', [$planId]);
            if (!$plan || (int) $plan['created_by'] !== (int) $user['user_id'] || $plan['status'] !== 'Draft') {
                throw new DomainException('Only your own draft plans can be deleted.');
            }
            DB::exec('DELETE FROM financial_plans WHERE plan_id = ?', [$planId]);
            Audit::log('Plan deleted', 'Financial plans', $planId, "Deleted draft {$plan['plan_code']}");
        });
    }

    public static function decide(int $planId, string $decision, string $comments): void
    {
        $user = Auth::user();
        if (!in_array($decision, ['Approved', 'Rejected', 'Revision_Requested'], true)) {
            throw new DomainException('Invalid decision.');
        }
        if ($decision !== 'Approved' && trim($comments) === '') {
            throw new DomainException('Please explain your decision in the comments box.');
        }

        DB::transaction(function () use ($planId, $decision, $comments, $user): void {
            $plan = DB::row('SELECT * FROM financial_plans WHERE plan_id = ? FOR UPDATE', [$planId]);
            if (!$plan) {
                throw new DomainException('Plan not found.');
            }
            $stage = self::stageRole($plan['status']);
            if ($stage === null) {
                throw new DomainException('This plan is not awaiting a decision.');
            }
            if ($user['role'] !== $stage) {
                throw new DomainException("This plan is waiting for a $stage decision.");
            }
            if ((int) $plan['created_by'] === (int) $user['user_id']) {
                throw new DomainException('You cannot review a plan you created.');
            }

            $next = match ($decision) {
                'Approved'           => $stage === 'Manager' ? 'Pending_Finance' : 'Approved',
                'Rejected'           => 'Rejected',
                'Revision_Requested' => 'Revision_Requested',
            };
            DB::exec('UPDATE financial_plans SET status = ?, reviewed_at = NOW() WHERE plan_id = ?', [$next, $planId]);
            Approvals::record('plan', $planId, $stage, $decision, $comments);
            Audit::log("Plan $decision", 'Financial plans', $planId, "$stage decision on {$plan['plan_code']}: " . status_label($next));

            $link = 'modules/plans/view.php?id=' . $planId;
            if ($next === 'Pending_Finance') {
                Notify::role('Finance', 'Plan awaiting your review', "{$plan['plan_code']} — {$plan['title']} was approved by the Manager.", $link);
                Notify::user((int) $plan['created_by'], 'Plan moved forward', "{$plan['plan_code']} was approved by the Manager and is now with Finance.", $link);
            } elseif ($next === 'Approved') {
                Notify::user((int) $plan['created_by'], 'Plan approved', "{$plan['plan_code']} — {$plan['title']} is fully approved.", $link);
            } else {
                $what = $next === 'Rejected' ? 'rejected' : 'returned for revision';
                Notify::user((int) $plan['created_by'], "Plan $what", "{$plan['plan_code']} was $what by $stage: " . trim($comments), $link);
            }
        });
    }
}

Approvals::registerCounter(static function (string $role): int {
    $status = match ($role) {
        'Manager' => 'Pending_Manager',
        'Finance' => 'Pending_Finance',
        default   => null,
    };
    return $status ? (int) DB::val('SELECT COUNT(*) FROM financial_plans WHERE status = ? AND created_by <> ?', [$status, Auth::id() ?? 0]) : 0;
});
