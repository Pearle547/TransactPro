<?php
declare(strict_types=1);

/**
 * In-app notifications. Used to alert the next responsible person in a workflow.
 */
final class Notify
{
    /** @param string|null $link application-relative path, e.g. "modules/plans/view.php?id=4" */
    public static function user(int $userId, string $title, string $message, ?string $link = null): void
    {
        DB::run(
            'INSERT INTO notifications (user_id, title, message, link) VALUES (?, ?, ?, ?)',
            [$userId, $title, mb_substr($message, 0, 500), $link]
        );
    }

    /** Notify every active user holding $role. */
    public static function role(string $role, string $title, string $message, ?string $link = null): void
    {
        DB::run(
            "INSERT INTO notifications (user_id, title, message, link)
             SELECT user_id, ?, ?, ? FROM users WHERE role = ? AND status = 'Active'",
            [$title, mb_substr($message, 0, 500), $link, $role]
        );
    }

    public static function unreadCount(int $userId): int
    {
        return (int) DB::val('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0', [$userId]);
    }
}
