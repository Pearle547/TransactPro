<?php
declare(strict_types=1);

/**
 * Shared decision log for plans, fund requests and accountabilities.
 */
final class Approvals
{
    /** @var array<int, callable(string): int> */
    private static array $counters = [];

    public static function record(string $type, int $id, string $stage, string $action, ?string $comments): void
    {
        DB::run(
            'INSERT INTO approvals (entity_type, entity_id, stage, approver_id, action, comments) VALUES (?, ?, ?, ?, ?, ?)',
            [$type, $id, $stage, Auth::id(), $action, $comments !== null && trim($comments) !== '' ? trim($comments) : null]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public static function history(string $type, int $id): array
    {
        return DB::all(
            'SELECT a.*, u.full_name, u.role FROM approvals a JOIN users u ON u.user_id = a.approver_id
              WHERE a.entity_type = ? AND a.entity_id = ? ORDER BY a.approval_id',
            [$type, $id]
        );
    }

    /** HTML timeline of decisions; $first optionally prepends the "submitted" event: [label, datetime]. */
    public static function timeline(array $history, ?array $first = null): string
    {
        if (!$history && !$first) {
            return '<p class="muted">No decisions have been recorded yet.</p>';
        }
        $html = '<ul class="timeline">';
        if ($first) {
            $html .= '<li><strong>' . e($first[0]) . '</strong><div class="when">' . e(fdatetime($first[1])) . '</div></li>';
        }
        foreach ($history as $h) {
            $class = match ($h['action']) {
                'Approved', 'Verified' => 'approved',
                'Rejected'             => 'rejected',
                default                => 'revision',
            };
            $verb = match ($h['action']) {
                'Approved'           => 'approved',
                'Verified'           => 'verified',
                'Rejected'           => 'rejected',
                'Revision_Requested' => 'requested a revision',
            };
            $html .= '<li class="' . $class . '"><strong>' . e($h['full_name']) . '</strong> (' . e($h['stage']) . ') ' . $verb
                . '<div class="when">' . e(fdatetime($h['acted_at'])) . '</div>'
                . ($h['comments'] ? '<div class="note">' . e($h['comments']) . '</div>' : '') . '</li>';
        }
        return $html . '</ul>';
    }

    /** Services register a callback that returns how many items await the given role. */
    public static function registerCounter(callable $counter): void
    {
        self::$counters[] = $counter;
    }

    public static function pendingFor(string $role): int
    {
        $total = 0;
        foreach (self::$counters as $counter) {
            $total += $counter($role);
        }
        return $total;
    }
}

/** Sidebar counter for the Approvals menu item (see nav_sections()). */
function nav_badge_approvals(): int
{
    return Approvals::pendingFor((string) Auth::role());
}
