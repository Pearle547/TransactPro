<?php
declare(strict_types=1);

/**
 * Budget calculations.
 *
 *   available = allocated − committed − utilised
 *
 * In this phase nothing has been committed yet; later phases extend this class as requests are introduced.
 */
final class Budget
{
    private const SELECT = 'SELECT bl.*, p.project_code, p.project_name, p.status AS project_status,
                                   0 AS committed, 0 AS utilised,
                                   bl.allocated_amount AS available
                              FROM budget_lines bl JOIN projects p ON p.project_id = bl.project_id';

    /** @return array<int, array<string, mixed>> budget lines with their committed / utilised / available amounts */
    public static function lines(?int $projectId = null): array
    {
        if ($projectId !== null) {
            return DB::all(self::SELECT . ' WHERE bl.project_id = ? ORDER BY bl.line_code', [$projectId]);
        }
        return DB::all(self::SELECT . ' ORDER BY p.project_name, bl.line_code');
    }

    public static function find(int $lineId): ?array
    {
        return DB::row(self::SELECT . ' WHERE bl.budget_line_id = ?', [$lineId]);
    }

    /** Lock the budget line for the rest of the transaction, then return its current figures. */
    public static function lockAndFind(int $lineId): ?array
    {
        DB::val('SELECT budget_line_id FROM budget_lines WHERE budget_line_id = ? FOR UPDATE', [$lineId]);
        return self::find($lineId);
    }

    /** @return array<int, array{allocated: float, committed: float, utilised: float, available: float}> keyed by project id */
    public static function projectSummaries(): array
    {
        $out = [];
        foreach (self::lines() as $line) {
            $s = &$out[(int) $line['project_id']];
            $s ??= ['allocated' => 0.0, 'committed' => 0.0, 'utilised' => 0.0, 'available' => 0.0];
            $s['allocated'] += (float) $line['allocated_amount'];
            $s['committed'] += (float) $line['committed'];
            $s['utilised']  += (float) $line['utilised'];
            $s['available'] += (float) $line['available'];
            unset($s);
        }
        return $out;
    }

    /** Percentage of the allocation that is committed or spent. */
    public static function usedPercent(array $line): float
    {
        $allocated = (float) $line['allocated_amount'];
        return $allocated > 0 ? min(100, (((float) $line['committed'] + (float) $line['utilised']) / $allocated) * 100) : 0;
    }
}
