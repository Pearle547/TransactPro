<?php
/** @var array $user */
$uid  = (int) $user['user_id'];
$role = $user['role'];

$activeProjects = (int) DB::val("SELECT COUNT(*) FROM projects WHERE status = 'Active'");
$summary        = array_reduce(Budget::projectSummaries(), static function (array $c, array $s): array {
    $c['allocated'] += $s['allocated'];
    $c['available'] += $s['available'];
    return $c;
}, ['allocated' => 0.0, 'available' => 0.0]);

$mine = $role === 'Staff';
$counts = DB::all(
    'SELECT status, COUNT(*) AS total, COALESCE(SUM(planned_amount), 0) AS amount FROM financial_plans' . ($mine ? ' WHERE created_by = ?' : '') . ' GROUP BY status',
    $mine ? [$uid] : []
);
$byStatus = array_column($counts, null, 'status');
$n = static fn (string ...$s): int => array_sum(array_map(static fn ($k) => (int) ($byStatus[$k]['total'] ?? 0), $s));

$planStage = ['Manager' => 'Pending_Manager', 'Finance' => 'Pending_Finance'][$role] ?? null;
$awaiting  = $planStage ? (int) DB::val('SELECT COUNT(*) FROM financial_plans WHERE status = ? AND created_by <> ?', [$planStage, $uid]) : null;
?>
<div class="stats">
    <div class="stat"><div class="stat-label">Active projects</div><div class="stat-value"><?= $activeProjects ?></div><div class="stat-note">Allocated <?= e(money($summary['allocated'])) ?></div></div>
    <div class="stat accent"><div class="stat-label">Budget available</div><div class="stat-value"><?= e(money($summary['available'])) ?></div><div class="stat-note">Across all budget lines</div></div>
    <?php if ($mine): ?>
        <div class="stat"><div class="stat-label">My plans</div><div class="stat-value"><?= $n('Draft', 'Pending_Manager', 'Pending_Finance', 'Approved', 'Rejected', 'Revision_Requested') ?></div><div class="stat-note"><?= $n('Draft') ?> draft(s)</div></div>
        <div class="stat warn"><div class="stat-label">In review</div><div class="stat-value"><?= $n('Pending_Manager', 'Pending_Finance') ?></div><div class="stat-note">With Manager or Finance</div></div>
        <div class="stat ok"><div class="stat-label">Approved plans</div><div class="stat-value"><?= $n('Approved') ?></div><div class="stat-note"><?= $n('Revision_Requested') ?> need revision</div></div>
    <?php else: ?>
        <div class="stat"><div class="stat-label">Plans in system</div><div class="stat-value"><?= $n('Draft', 'Pending_Manager', 'Pending_Finance', 'Approved', 'Rejected', 'Revision_Requested') ?></div><div class="stat-note"><?= $n('Approved') ?> approved</div></div>
        <?php if ($awaiting !== null): ?>
            <div class="stat warn"><div class="stat-label">Plans awaiting your decision</div><div class="stat-value"><?= $awaiting ?></div><div class="stat-note"><a href="<?= e(url('modules/approvals/index.php')) ?>">Open approvals queue</a></div></div>
        <?php endif; ?>
    <?php endif; ?>
</div>
