<?php
declare(strict_types=1);

/**
 * Key/value system settings stored in the database.
 */
final class Settings
{
    /** @var array<string, string>|null */
    private static ?array $cache = null;

    public static function get(string $key, string $default = ''): string
    {
        if (self::$cache === null) {
            self::$cache = array_column(DB::all('SELECT setting_key, setting_value FROM settings'), 'setting_value', 'setting_key');
        }
        return self::$cache[$key] ?? $default;
    }

    public static function set(string $key, string $value): void
    {
        DB::exec(
            'INSERT INTO settings (setting_key, setting_value, updated_by) VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_by = VALUES(updated_by)',
            [$key, $value, Auth::id()]
        );
        self::$cache = null;
    }

    /** Requests of this amount (UGX) or more need Director approval after Finance. */
    public static function directorThreshold(): float
    {
        return (float) self::get('director_threshold', '10000000');
    }
}
