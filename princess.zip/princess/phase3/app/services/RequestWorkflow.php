<?php
declare(strict_types=1);

/**
 * Fund request lifecycle and approval routing.
 *
 *   Draft → Pending_Manager → Pending_Finance ─┬─ amount below the threshold ─→ Approved
 *                                              └─ amount at/above threshold ─→ Pending_Director → Approved
 *
 * EVERY request is reviewed by Finance first. Only high-value requests continue to the Director.
 * Rejected / Revision_Requested return the request to the requester; resubmitting restarts the chain.
 *
 * Budget: a request reserves its amount on the budget line from the moment it is submitted until it is
 * rejected or returned (see Budget). Submission is validated against the available balance under a row lock.
 *
 * Business-rule failures throw DomainException; the message is safe to show to the user.
 */
final class RequestWorkflow
{
    /** Statuses in which a request still counts against its approved plan. */
    private const PLAN_COUNTED = ['Pending_Manager', 'Pending_Finance', 'Pending_Director', 'Approved', 'Paid', 'Accountability_Submitted', 'Closed'];

    public static function stageRole(string $status): ?string
    {
        return match ($status) {
            'Pending_Manager'  => 'Manager',
            'Pending_Finance'  => 'Finance',
            'Pending_Director' => 'Director',
            default            => null,
        };
    }

    public static function needsDirector(float|string $amount): bool
    {
        return (float) $amount >= Settings::directorThreshold();
    }

    /** Approval stages a request of this amount passes through. */
    public static function route(float|string $amount): array
    {
        return self::needsDirector($amount) ? ['Manager', 'Finance', 'Director'] : ['Manager', 'Finance'];
    }

    public static function canView(array $req, array $user): bool
    {
        return $user['role'] !== 'Staff' || (int) $req['user_id'] === (int) $user['user_id'];
    }

    public static function isOwner(array $req, array $user): bool
    {
        return (int) $req['user_id'] === (int) $user['user_id'];
    }

    public static function isEditable(array $req, array $user): bool
    {
        return self::isOwner($req, $user) && in_array($req['status'], ['Draft', 'Revision_Requested'], true);
    }

    public static function canDecide(array $req, array $user): bool
    {
        return self::stageRole($req['status']) === $user['role'] && !self::isOwner($req, $user);
    }

    /** Insert or update a request owned by the signed-in user. Returns the request id. */
    public static function save(?int $requestId, array $d): int
    {
        $user = Auth::user();

        $line = DB::row('SELECT project_id FROM budget_lines WHERE budget_line_id = ?', [$d['budget_line_id']]);
        if (!$line || (int) $line['project_id'] !== (int) $d['project_id']) {
            throw new DomainException('The selected budget line does not belong to the selected project.');
        }
        $project = DB::row('SELECT status FROM projects WHERE project_id = ?', [$d['project_id']]);
        if (!$project || $project['status'] !== 'Active') {
            throw new DomainException('Funds can only be requested against an active project.');
        }
        if (!empty($d['plan_id'])) {
            $plan = DB::row('SELECT project_id, status FROM financial_plans WHERE plan_id = ?', [$d['plan_id']]);
            if (!$plan || (int) $plan['project_id'] !== (int) $d['project_id'] || $plan['status'] !== 'Approved') {
                throw new DomainException('Only an approved plan of the same project can be linked.');
            }
        }
        $planId = !empty($d['plan_id']) ? (int) $d['plan_id'] : null;

        if ($requestId === null) {
            $id = DB::insert(
                'INSERT INTO financial_requests (request_code, user_id, project_id, budget_line_id, plan_id, amount_requested, purpose, required_date)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [Codes::placeholder(), $user['user_id'], $d['project_id'], $d['budget_line_id'], $planId, $d['amount_requested'], $d['purpose'], $d['required_date']]
            );
            DB::exec('UPDATE financial_requests SET request_code = ? WHERE request_id = ?', [Codes::make('FR', $id), $id]);
            Audit::log('Request created', 'Fund requests', $id, 'Drafted a request for ' . money($d['amount_requested']));
            return $id;
        }

        $req = DB::row('SELECT * FROM financial_requests WHERE request_id = ?', [$requestId]);
        if (!$req || !self::isEditable($req, $user)) {
            throw new DomainException('This request can no longer be edited.');
        }
        DB::exec(
            'UPDATE financial_requests SET project_id = ?, budget_line_id = ?, plan_id = ?, amount_requested = ?, purpose = ?, required_date = ? WHERE request_id = ?',
            [$d['project_id'], $d['budget_line_id'], $planId, $d['amount_requested'], $d['purpose'], $d['required_date'], $requestId]
        );
        Audit::log('Request updated', 'Fund requests', $requestId, "Edited {$req['request_code']}");
        return $requestId;
    }

    public static function submit(int $requestId): void
    {
        $user = Auth::user();
        DB::transaction(function () use ($requestId, $user): void {
            $req = DB::row('SELECT * FROM financial_requests WHERE request_id = ? FOR UPDATE', [$requestId]);
            if (!$req || !self::isEditable($req, $user)) {
                throw new DomainException('Only your own draft or returned requests can be submitted.');
            }
            if ($req['required_date'] < date('Y-m-d')) {
                throw new DomainException('The required date is in the past. Please update it before submitting.');
            }

            // Lock the budget line, then check what is really available right now.
            $line = Budget::lockAndFind((int) $req['budget_line_id']);
            if (!$line || $line['project_status'] !== 'Active') {
                throw new DomainException('The project for this request is no longer active.');
            }
            $amount = (float) $req['amount_requested'];
            if ($amount > (float) $line['available'] + 0.001) {
                throw new DomainException(
                    'The amount requested (' . money($amount) . ') is more than the ' . money(max(0, (float) $line['available']))
                    . " still available on budget line {$line['line_code']}."
                );
            }

            if ($req['plan_id']) {
                $marks   = implode(',', array_fill(0, count(self::PLAN_COUNTED), '?'));
                $planned = (float) DB::val('SELECT planned_amount FROM financial_plans WHERE plan_id = ?', [$req['plan_id']]);
                $already = (float) DB::val(
                    "SELECT COALESCE(SUM(amount_requested), 0) FROM financial_requests WHERE plan_id = ? AND request_id <> ? AND status IN ($marks)",
                    array_merge([$req['plan_id'], $requestId], self::PLAN_COUNTED)
                );
                if ($already + $amount > $planned + 0.001) {
                    throw new DomainException('Together with earlier requests (' . money($already) . '), this would exceed the approved plan amount of ' . money($planned) . '.');
                }
            }

            DB::exec("UPDATE financial_requests SET status = 'Pending_Manager', submitted_at = NOW() WHERE request_id = ?", [$requestId]);
            Audit::log('Request submitted', 'Fund requests', $requestId, "Submitted {$req['request_code']} for " . money($amount) . " against {$line['line_code']}");
            Notify::role('Manager', 'Fund request awaiting your approval', "{$req['request_code']} for " . money($amount) . " was submitted by {$user['full_name']}.", 'modules/requests/view.php?id=' . $requestId);
        });
    }

    public static function delete(int $requestId): void
    {
        $user = Auth::user();
        DB::transaction(function () use ($requestId, $user): void {
            $req = DB::row('SELECT * FROM financial_requests WHERE request_id = ? FOR UPDATE', [$requestId]);
            if (!$req || !self::isOwner($req, $user) || $req['status'] !== 'Draft') {
                throw new DomainException('Only your own draft requests can be deleted.');
            }
            DB::exec('DELETE FROM financial_requests WHERE request_id = ?', [$requestId]);
            Audit::log('Request deleted', 'Fund requests', $requestId, "Deleted draft {$req['request_code']}");
        });
    }

    public static function decide(int $requestId, string $decision, string $comments): void
    {
        $user = Auth::user();
        if (!in_array($decision, ['Approved', 'Rejected', 'Revision_Requested'], true)) {
            throw new DomainException('Invalid decision.');
        }
        if ($decision !== 'Approved' && trim($comments) === '') {
            throw new DomainException('Please explain your decision in the comments box.');
        }

        DB::transaction(function () use ($requestId, $decision, $comments, $user): void {
            $req = DB::row('SELECT * FROM financial_requests WHERE request_id = ? FOR UPDATE', [$requestId]);
            if (!$req) {
                throw new DomainException('Request not found.');
            }
            $stage = self::stageRole($req['status']);
            if ($stage === null) {
                throw new DomainException('This request is not awaiting a decision.');
            }
            if ($user['role'] !== $stage) {
                throw new DomainException("This request is waiting for a $stage decision.");
            }
            if (self::isOwner($req, $user)) {
                throw new DomainException('You cannot approve or reject your own request.');
            }

            $next = match ($decision) {
                'Approved'           => match ($stage) {
                    'Manager'  => 'Pending_Finance',
                    'Finance'  => self::needsDirector($req['amount_requested']) ? 'Pending_Director' : 'Approved',
                    'Director' => 'Approved',
                },
                'Rejected'           => 'Rejected',
                'Revision_Requested' => 'Revision_Requested',
            };

            DB::exec(
                'UPDATE financial_requests SET status = ?, approved_at = ' . ($next === 'Approved' ? 'NOW()' : 'NULL') . ' WHERE request_id = ?',
                [$next, $requestId]
            );
            Approvals::record('request', $requestId, $stage, $decision, $comments);
            Audit::log("Request $decision", 'Fund requests', $requestId, "$stage decision on {$req['request_code']}: " . status_label($next));

            $link   = 'modules/requests/view.php?id=' . $requestId;
            $amount = money($req['amount_requested']);
            $owner  = (int) $req['user_id'];
            switch ($next) {
                case 'Pending_Finance':
                    Notify::role('Finance', 'Fund request awaiting your review', "{$req['request_code']} for $amount was approved by the Manager.", $link);
                    Notify::user($owner, 'Request moved forward', "{$req['request_code']} was approved by the Manager and is now with Finance.", $link);
                    break;
                case 'Pending_Director':
                    Notify::role('Director', 'High-value request awaiting your approval', "{$req['request_code']} for $amount has cleared Finance and needs your approval.", $link);
                    Notify::user($owner, 'Request moved forward', "{$req['request_code']} cleared Finance. Because it is " . money(Settings::directorThreshold()) . ' or more, it now needs Director approval.', $link);
                    break;
                case 'Approved':
                    Notify::user($owner, 'Request approved', "{$req['request_code']} for $amount has been fully approved.", $link);
                    if (class_exists('Payments')) {
                        Notify::role('Finance', 'Approved request ready for payment', "{$req['request_code']} for $amount is approved and awaiting payment.", $link);
                    }
                    break;
                default:
                    $what = $next === 'Rejected' ? 'rejected' : 'returned for revision';
                    Notify::user($owner, "Request $what", "{$req['request_code']} was $what by $stage: " . trim($comments), $link);
            }
        });
    }
}

Approvals::registerCounter(static function (string $role): int {
    $status = match ($role) {
        'Manager'  => 'Pending_Manager',
        'Finance'  => 'Pending_Finance',
        'Director' => 'Pending_Director',
        default    => null,
    };
    return $status ? (int) DB::val('SELECT COUNT(*) FROM financial_requests WHERE status = ? AND user_id <> ?', [$status, Auth::id() ?? 0]) : 0;
});
