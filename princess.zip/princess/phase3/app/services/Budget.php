<?php
declare(strict_types=1);

/**
 * Budget calculations.
 *
 *   available = allocated − committed − utilised
 *
 *   committed : money reserved by requests that are in approval, approved, paid, or awaiting verification
 *   utilised  : amount actually spent on requests whose accountability has been verified (Closed)
 *
 * Draft, rejected and returned requests reserve nothing. A request that is closed releases whatever was
 * not spent back to the budget line.
 */
final class Budget
{
    /** Request statuses that hold (reserve) their full amount against the budget line. */
    public const RESERVING = ['Pending_Manager', 'Pending_Finance', 'Pending_Director', 'Approved', 'Paid', 'Accountability_Submitted'];

    private static function select(string $where): string
    {
        $reserving = "'" . implode("','", self::RESERVING) . "'";
        $committed = "COALESCE(SUM(CASE WHEN fr.status IN ($reserving) THEN fr.amount_requested ELSE 0 END), 0)";
        $utilised  = "COALESCE(SUM(CASE WHEN fr.status = 'Closed' THEN fr.amount_utilised ELSE 0 END), 0)";
        return "SELECT bl.*, p.project_code, p.project_name, p.status AS project_status,
                       $committed AS committed, $utilised AS utilised,
                       bl.allocated_amount - $committed - $utilised AS available
                  FROM budget_lines bl
                  JOIN projects p ON p.project_id = bl.project_id
             LEFT JOIN financial_requests fr ON fr.budget_line_id = bl.budget_line_id
                 $where
              GROUP BY bl.budget_line_id, p.project_id";
    }

    /** @return array<int, array<string, mixed>> */
    public static function lines(?int $projectId = null): array
    {
        if ($projectId !== null) {
            return DB::all(self::select('WHERE bl.project_id = ?') . ' ORDER BY bl.line_code', [$projectId]);
        }
        return DB::all(self::select('') . ' ORDER BY p.project_name, bl.line_code');
    }

    public static function find(int $lineId): ?array
    {
        return DB::row(self::select('WHERE bl.budget_line_id = ?'), [$lineId]);
    }

    /** Lock the budget line for the rest of the transaction, then return its current figures. */
    public static function lockAndFind(int $lineId): ?array
    {
        DB::val('SELECT budget_line_id FROM budget_lines WHERE budget_line_id = ? FOR UPDATE', [$lineId]);
        return self::find($lineId);
    }

    /** @return array<int, array{allocated: float, committed: float, utilised: float, available: float}> keyed by project id */
    public static function projectSummaries(): array
    {
        $out = [];
        foreach (self::lines() as $line) {
            $s = &$out[(int) $line['project_id']];
            $s ??= ['allocated' => 0.0, 'committed' => 0.0, 'utilised' => 0.0, 'available' => 0.0];
            $s['allocated'] += (float) $line['allocated_amount'];
            $s['committed'] += (float) $line['committed'];
            $s['utilised']  += (float) $line['utilised'];
            $s['available'] += (float) $line['available'];
            unset($s);
        }
        return $out;
    }

    /** Percentage of the allocation that is committed or spent. */
    public static function usedPercent(array $line): float
    {
        $allocated = (float) $line['allocated_amount'];
        return $allocated > 0 ? min(100, (((float) $line['committed'] + (float) $line['utilised']) / $allocated) * 100) : 0;
    }
}
