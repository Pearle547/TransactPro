<?php
/** @var array $user */
$uid  = (int) $user['user_id'];
$role = $user['role'];
$mine = $role === 'Staff';

$rows   = DB::all(
    'SELECT status, COUNT(*) AS total, COALESCE(SUM(amount_requested), 0) AS amount FROM financial_requests' . ($mine ? ' WHERE user_id = ?' : '') . ' GROUP BY status',
    $mine ? [$uid] : []
);
$by     = array_column($rows, null, 'status');
$count  = static fn (string ...$s): int => array_sum(array_map(static fn ($k) => (int) ($by[$k]['total'] ?? 0), $s));
$amount = static fn (string ...$s): float => array_sum(array_map(static fn ($k) => (float) ($by[$k]['amount'] ?? 0), $s));
$inFlow = ['Pending_Manager', 'Pending_Finance', 'Pending_Director'];

$recent = DB::all(
    'SELECT fr.request_id, fr.request_code, fr.amount_requested, fr.status, fr.created_at, p.project_code, u.full_name
       FROM financial_requests fr JOIN projects p ON p.project_id = fr.project_id JOIN users u ON u.user_id = fr.user_id'
    . ($mine ? ' WHERE fr.user_id = ?' : '') . ' ORDER BY fr.request_id DESC LIMIT 6',
    $mine ? [$uid] : []
);
$stage     = ['Manager' => 'Pending_Manager', 'Finance' => 'Pending_Finance', 'Director' => 'Pending_Director'][$role] ?? null;
$awaiting  = $stage ? (int) DB::val('SELECT COUNT(*) FROM financial_requests WHERE status = ? AND user_id <> ?', [$stage, $uid]) : null;
?>
<div class="stats">
    <?php if ($mine): ?>
        <div class="stat"><div class="stat-label">My requests</div><div class="stat-value"><?= array_sum(array_column($rows, 'total')) ?></div><div class="stat-note"><?= $count('Draft') ?> draft(s)</div></div>
        <div class="stat warn"><div class="stat-label">In approval</div><div class="stat-value"><?= $count(...$inFlow) ?></div><div class="stat-note"><?= e(money($amount(...$inFlow))) ?> reserved</div></div>
        <div class="stat ok"><div class="stat-label">Approved</div><div class="stat-value"><?= $count('Approved') ?></div><div class="stat-note"><?= e(money($amount('Approved'))) ?></div></div>
        <div class="stat danger"><div class="stat-label">Returned / rejected</div><div class="stat-value"><?= $count('Revision_Requested', 'Rejected') ?></div><div class="stat-note">Need your attention</div></div>
    <?php else: ?>
        <div class="stat"><div class="stat-label">Requests in system</div><div class="stat-value"><?= array_sum(array_column($rows, 'total')) ?></div><div class="stat-note"><?= e(money(array_sum(array_column($rows, 'amount')) - $amount('Draft', 'Rejected', 'Revision_Requested'))) ?> in progress or approved</div></div>
        <?php if ($awaiting !== null): ?>
            <div class="stat warn"><div class="stat-label">Requests awaiting your decision</div><div class="stat-value"><?= $awaiting ?></div><div class="stat-note"><a href="<?= e(url('modules/approvals/index.php')) ?>">Open approvals queue</a></div></div>
        <?php endif; ?>
        <div class="stat"><div class="stat-label">In approval</div><div class="stat-value"><?= $count(...$inFlow) ?></div><div class="stat-note"><?= e(money($amount(...$inFlow))) ?></div></div>
        <div class="stat ok"><div class="stat-label">Approved</div><div class="stat-value"><?= $count('Approved') ?></div><div class="stat-note"><?= e(money($amount('Approved'))) ?></div></div>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-head"><h3><?= $mine ? 'My recent requests' : 'Recent fund requests' ?></h3><a class="btn btn-sm" href="<?= e(url('modules/requests/index.php')) ?>">View all</a></div>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Code</th><?php if (!$mine): ?><th>Requester</th><?php endif; ?><th>Project</th><th class="num">Amount</th><th>Status</th><th>Raised</th></tr></thead>
            <tbody>
            <?php foreach ($recent as $r): ?>
                <tr>
                    <td class="code"><a href="<?= e(url('modules/requests/view.php?id=' . (int) $r['request_id'])) ?>"><?= e($r['request_code']) ?></a></td>
                    <?php if (!$mine): ?><td><?= e($r['full_name']) ?></td><?php endif; ?>
                    <td><?= e($r['project_code']) ?></td>
                    <td class="num"><?= e(money($r['amount_requested'])) ?></td>
                    <td><?= badge($r['status']) ?></td>
                    <td class="nowrap"><?= e(time_ago($r['created_at'])) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$recent): ?><tr><td colspan="6" class="table-empty">No fund requests yet.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
