/* Fund request form: filters budget lines / plans by project and shows a live budget check. */
document.addEventListener('DOMContentLoaded', function () {
    var form = document.getElementById('request-form');
    if (!form) { return; }

    var catalog = JSON.parse(form.dataset.catalog || '{}');
    var threshold = parseFloat(form.dataset.threshold || '0');
    var project = document.getElementById('project_id');
    var line = document.getElementById('budget_line_id');
    var plan = document.getElementById('plan_id');
    var amount = document.getElementById('amount_requested');
    var box = document.getElementById('budget-box');
    var selectedLine = form.dataset.selectedLine || '';
    var selectedPlan = form.dataset.selectedPlan || '';

    function fmt(n) { return 'UGX ' + Math.round(n).toLocaleString('en-US'); }
    function option(value, text, selected) {
        var o = document.createElement('option');
        o.value = value; o.textContent = text; o.selected = !!selected;
        return o;
    }

    function fillProject() {
        var p = catalog[project.value];
        line.innerHTML = ''; plan.innerHTML = '';
        plan.appendChild(option('', 'Not linked to a plan'));
        if (!p) { line.appendChild(option('', 'Select a project first')); update(); return; }
        line.appendChild(option('', p.lines.length ? 'Select a budget line…' : 'This project has no budget lines'));
        p.lines.forEach(function (l) { line.appendChild(option(l.id, l.label, String(l.id) === selectedLine)); });
        p.plans.forEach(function (pl) { plan.appendChild(option(pl.id, pl.label, String(pl.id) === selectedPlan)); });
        selectedLine = ''; selectedPlan = '';
        update();
    }

    function currentLine() {
        var p = catalog[project.value];
        if (!p) { return null; }
        for (var i = 0; i < p.lines.length; i++) { if (String(p.lines[i].id) === line.value) { return p.lines[i]; } }
        return null;
    }

    function update() {
        var l = currentLine();
        var value = parseFloat((amount.value || '').replace(/,/g, '')) || 0;
        var html = '';
        box.className = 'budget-box';
        if (!l) {
            box.textContent = 'Choose a budget line to see the funds available.';
        } else {
            var remaining = l.available - value;
            html = 'Allocated: <strong>' + fmt(l.allocated) + '</strong> &nbsp;·&nbsp; Available now: <strong>' + fmt(l.available) + '</strong>';
            if (value > 0) {
                html += ' &nbsp;·&nbsp; After this request: <strong>' + fmt(remaining) + '</strong>';
                box.classList.add(remaining < 0 ? 'bad' : 'good');
                if (remaining < 0) { html += '<br>This request is more than the funds available on the line and cannot be submitted.'; }
            }
            box.innerHTML = html;
        }
        if (value > 0 && threshold > 0) {
            var route = document.createElement('div');
            route.style.marginTop = '.4rem';
            route.textContent = value >= threshold
                ? 'Approval route: Manager → Finance → Director (amount is ' + fmt(threshold) + ' or more).'
                : 'Approval route: Manager → Finance (Finance approval is final below ' + fmt(threshold) + ').';
            box.appendChild(route);
        }
    }

    project.addEventListener('change', function () { selectedLine = ''; selectedPlan = ''; fillProject(); });
    line.addEventListener('change', update);
    amount.addEventListener('input', update);
    fillProject();
});
