<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user    = Auth::require(['Staff']);
$id      = (int) ($_GET['id'] ?? 0);
$editing = $id > 0;
$req     = $editing ? DB::row('SELECT * FROM financial_requests WHERE request_id = ?', [$id]) : null;
if ($editing && ($req === null || !RequestWorkflow::isOwner($req, $user))) {
    abort(404, 'That request does not exist.');
}
if ($editing && !RequestWorkflow::isEditable($req, $user)) {
    flash('error', 'This request is already in the approval process and can no longer be edited.');
    redirect('modules/requests/view.php?id=' . $id);
}

if (is_post()) {
    $data = [
        'project_id'       => (string) input('project_id', ''),
        'budget_line_id'   => (string) input('budget_line_id', ''),
        'plan_id'          => (string) input('plan_id', ''),
        'amount_requested' => str_replace(',', '', (string) input('amount_requested', '')),
        'required_date'    => (string) input('required_date', ''),
        'purpose'          => (string) input('purpose', ''),
    ];
    $errors = Validator::validate($data, [
        'project_id'       => 'required|numeric',
        'budget_line_id'   => 'required|numeric',
        'plan_id'          => 'numeric',
        'amount_requested' => 'required|numeric|min_value:1|max_value:9999999999999',
        'required_date'    => 'required|date',
        'purpose'          => 'required|min:10',
    ], ['project_id' => 'Project', 'budget_line_id' => 'Budget line', 'plan_id' => 'Plan', 'amount_requested' => 'Amount requested', 'required_date' => 'Required date']);

    if ($errors) {
        remember_form($data, $errors);
        redirect('modules/requests/form.php' . ($editing ? "?id=$id" : ''));
    }

    try {
        $requestId = DB::transaction(static fn (): int => RequestWorkflow::save($editing ? $id : null, $data));
    } catch (DomainException $e) {
        // keep what the user typed and tell them why it was refused
        flash('error', $e->getMessage());
        remember_form($data, []);
        redirect('modules/requests/form.php' . ($editing ? "?id=$id" : ''));
    }

    if (!isset($_POST['submit'])) {
        flash('success', 'Draft saved.');
        redirect('modules/requests/view.php?id=' . $requestId);
    }

    // The work is saved first, so a refused submission (e.g. not enough budget) never loses what was typed.
    try {
        RequestWorkflow::submit($requestId);
    } catch (DomainException $e) {
        flash('error', 'Your request was saved as a draft but could not be submitted: ' . $e->getMessage());
        redirect('modules/requests/form.php?id=' . $requestId);
    }
    $route = RequestWorkflow::needsDirector($data['amount_requested']) ? 'the Manager, then Finance, then the Director' : 'the Manager, then Finance';
    flash('success', "Request submitted. It will be reviewed by $route.");
    redirect('modules/requests/view.php?id=' . $requestId);
}

$v = static fn (string $key, mixed $fallback = '') => old($key, $req[$key] ?? $fallback);

// Everything the form needs to filter budget lines and plans by project, without extra round trips.
$catalog = [];
foreach (DB::all("SELECT project_id, project_code, project_name FROM projects WHERE status = 'Active' ORDER BY project_name") as $p) {
    $catalog[(int) $p['project_id']] = ['label' => $p['project_code'] . ' — ' . $p['project_name'], 'lines' => [], 'plans' => []];
}
foreach (Budget::lines() as $l) {
    if (isset($catalog[(int) $l['project_id']])) {
        $catalog[(int) $l['project_id']]['lines'][] = [
            'id' => (int) $l['budget_line_id'], 'label' => $l['line_code'] . ' — ' . $l['description'],
            'allocated' => (float) $l['allocated_amount'], 'available' => (float) $l['available'],
        ];
    }
}
foreach (DB::all("SELECT plan_id, project_id, plan_code, title, planned_amount FROM financial_plans WHERE status = 'Approved' ORDER BY plan_id DESC") as $pl) {
    if (isset($catalog[(int) $pl['project_id']])) {
        $catalog[(int) $pl['project_id']]['plans'][] = ['id' => (int) $pl['plan_id'], 'label' => $pl['plan_code'] . ' — ' . $pl['title'] . ' (' . money($pl['planned_amount']) . ')'];
    }
}
$lastComment = null;
if ($editing && $req['status'] === 'Revision_Requested') {
    $hist = Approvals::history('request', $id);
    $lastComment = $hist ? end($hist) : null;
}

render_header($editing ? 'Edit request ' . $req['request_code'] : 'New fund request', 'requests', ['subtitle' => 'Request money for an approved activity']);
?>
<?php if ($lastComment): ?>
    <div class="alert alert-warning"><strong><?= e($lastComment['full_name']) ?> (<?= e($lastComment['stage']) ?>) returned this request:</strong> <?= e($lastComment['comments']) ?></div>
<?php endif; ?>
<div class="panel-note">
    Every request is reviewed by the Manager and then Finance. Requests of <strong><?= e(money(Settings::directorThreshold())) ?></strong> or more also need Director approval.
    Submitting reserves the amount on the budget line.
</div>
<div class="card">
    <div class="card-body">
        <form method="post" id="request-form" data-once
              data-catalog="<?= e(json_encode($catalog, JSON_UNESCAPED_UNICODE)) ?>"
              data-threshold="<?= e((string) Settings::directorThreshold()) ?>"
              data-selected-line="<?= e((string) $v('budget_line_id')) ?>"
              data-selected-plan="<?= e((string) $v('plan_id')) ?>">
            <?= csrf_field() ?>
            <div class="form-grid">
                <div class="field">
                    <label for="project_id">Project <span class="req">*</span></label>
                    <select class="input<?= has_error('project_id') ? ' invalid' : '' ?>" id="project_id" name="project_id" required>
                        <option value="">Select a project…</option>
                        <?php foreach ($catalog as $pid => $p): ?>
                            <option value="<?= $pid ?>"<?= selected((string) $v('project_id') === (string) $pid) ?>><?= e($p['label']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?= field_error('project_id') ?>
                </div>
                <div class="field">
                    <label for="budget_line_id">Budget line <span class="req">*</span></label>
                    <select class="input<?= has_error('budget_line_id') ? ' invalid' : '' ?>" id="budget_line_id" name="budget_line_id" required>
                        <option value="">Select a project first</option>
                    </select>
                    <?= field_error('budget_line_id') ?>
                </div>
                <div class="field full">
                    <label for="plan_id">Linked financial plan <span class="muted">(optional)</span></label>
                    <select class="input" id="plan_id" name="plan_id"><option value="">Not linked to a plan</option></select>
                    <span class="hint">Only approved plans of the chosen project are listed. The total requested under a plan cannot exceed its approved amount.</span>
                    <?= field_error('plan_id') ?>
                </div>
                <div class="field">
                    <label for="amount_requested">Amount requested (UGX) <span class="req">*</span></label>
                    <input class="input<?= has_error('amount_requested') ? ' invalid' : '' ?>" id="amount_requested" name="amount_requested" inputmode="decimal" value="<?= e($v('amount_requested')) ?>" required>
                    <?= field_error('amount_requested') ?>
                </div>
                <div class="field">
                    <label for="required_date">Required by <span class="req">*</span></label>
                    <input class="input<?= has_error('required_date') ? ' invalid' : '' ?>" type="date" id="required_date" name="required_date" value="<?= e($v('required_date')) ?>" min="<?= date('Y-m-d') ?>" required>
                    <?= field_error('required_date') ?>
                </div>
                <div class="field full"><div class="budget-box" id="budget-box">Choose a budget line to see the funds available.</div></div>
                <div class="field full">
                    <label for="purpose">Purpose <span class="req">*</span></label>
                    <textarea class="input<?= has_error('purpose') ? ' invalid' : '' ?>" id="purpose" name="purpose" rows="5" required><?= e($v('purpose')) ?></textarea>
                    <span class="hint">Explain what the money will be used for.</span>
                    <?= field_error('purpose') ?>
                </div>
            </div>
            <div class="form-actions">
                <a class="btn" href="<?= e(url('modules/requests/index.php')) ?>">Cancel</a>
                <button class="btn" type="submit" name="draft" value="1">Save draft</button>
                <button class="btn btn-primary" type="submit" name="submit" value="1">Submit request</button>
            </div>
        </form>
    </div>
</div>
<?php
render_footer(['request-form.js']);
