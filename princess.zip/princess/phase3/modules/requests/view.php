<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user = Auth::require();
$id   = (int) ($_GET['id'] ?? 0);
$req  = DB::row(
    'SELECT fr.*, p.project_code, p.project_name, p.donor_name, bl.line_code, bl.description AS line_description,
            u.full_name AS requester, u.department,
            fp.plan_code, fp.title AS plan_title
       FROM financial_requests fr
       JOIN projects p ON p.project_id = fr.project_id
       JOIN budget_lines bl ON bl.budget_line_id = fr.budget_line_id
       JOIN users u ON u.user_id = fr.user_id
  LEFT JOIN financial_plans fp ON fp.plan_id = fr.plan_id
      WHERE fr.request_id = ?',
    [$id]
);
if ($req === null || !RequestWorkflow::canView($req, $user)) {
    abort(404, 'That request does not exist.');
}

$history = Approvals::history('request', $id);
$line    = Budget::find((int) $req['budget_line_id']);
$status  = $req['status'];

// Approval route: Manager → Finance → (Director when the amount is at/above the threshold) → Approved
$needsDirector = RequestWorkflow::needsDirector($req['amount_requested']);
$stageState = static function (string $stage) use ($status, $needsDirector): string {
    $order     = ['Pending_Manager' => 1, 'Pending_Finance' => 2, 'Pending_Director' => 3];
    $stageNo   = ['Manager' => 1, 'Finance' => 2, 'Director' => 3][$stage];
    if ($stage === 'Director' && !$needsDirector) {
        return 'skipped';
    }
    if (isset($order[$status])) {
        return $order[$status] === $stageNo ? 'current' : ($order[$status] > $stageNo ? 'done' : '');
    }
    return in_array($status, ['Approved', 'Paid', 'Accountability_Submitted', 'Closed'], true) ? 'done' : '';
};
$finalApproved = in_array($status, ['Approved', 'Paid', 'Accountability_Submitted', 'Closed'], true);

render_header($req['request_code'], 'requests', [
    'subtitle' => $req['project_code'] . ' · ' . money($req['amount_requested']),
    'actions'  => RequestWorkflow::isEditable($req, $user) ? '<a class="btn" href="' . e(url('modules/requests/form.php?id=' . $id)) . '">Edit request</a>' : '',
]);
?>
<div class="grid grid-main">
    <div>
        <div class="card">
            <div class="card-head"><h3>Request details</h3><?= badge($status) ?></div>
            <div class="card-body">
                <div class="route" aria-label="Approval route">
                    <span class="step done">Requester</span><span class="sep">→</span>
                    <span class="step <?= e($stageState('Manager')) ?>">Manager</span><span class="sep">→</span>
                    <span class="step <?= e($stageState('Finance')) ?>">Finance</span><span class="sep">→</span>
                    <span class="step <?= e($stageState('Director')) ?>" title="<?= $needsDirector ? 'Required: amount is ' . e(money(Settings::directorThreshold())) . ' or more' : 'Not required below ' . e(money(Settings::directorThreshold())) ?>">Director</span><span class="sep">→</span>
                    <span class="step <?= $finalApproved ? 'done' : '' ?>">Approved</span>
                </div>
                <dl class="kv">
                    <div><dt>Requested by</dt><dd><?= e($req['requester']) ?><?= $req['department'] ? ' · ' . e($req['department']) : '' ?></dd></div>
                    <div><dt>Amount requested</dt><dd><?= e(money($req['amount_requested'])) ?></dd></div>
                    <div><dt>Project</dt><dd><a href="<?= e(url('modules/projects/view.php?id=' . (int) $req['project_id'])) ?>"><?= e($req['project_code'] . ' — ' . $req['project_name']) ?></a></dd></div>
                    <div><dt>Donor</dt><dd><?= e($req['donor_name']) ?></dd></div>
                    <div><dt>Budget line</dt><dd><?= e($req['line_code'] . ' — ' . $req['line_description']) ?></dd></div>
                    <div><dt>Linked plan</dt><dd><?= $req['plan_id'] ? '<a href="' . e(url('modules/plans/view.php?id=' . (int) $req['plan_id'])) . '">' . e($req['plan_code'] . ' — ' . $req['plan_title']) . '</a>' : '—' ?></dd></div>
                    <div><dt>Required by</dt><dd><?= e(fdate($req['required_date'])) ?></dd></div>
                    <div><dt>Submitted</dt><dd><?= e(fdatetime($req['submitted_at'])) ?></dd></div>
                    <div class="wide"><dt>Purpose</dt><dd class="prose"><?= e($req['purpose']) ?></dd></div>
                    <?php if ($status === 'Closed' && $req['amount_utilised'] !== null): ?>
                        <div><dt>Amount spent (verified)</dt><dd><?= e(money($req['amount_utilised'])) ?></dd></div>
                        <div><dt>Returned to budget</dt><dd><?= e(money((float) $req['amount_requested'] - (float) $req['amount_utilised'])) ?></dd></div>
                    <?php endif; ?>
                </dl>
            </div>
        </div>

        <?php if ($line && !in_array($status, ['Closed', 'Rejected'], true) && $user['role'] !== 'Staff'): ?>
        <div class="card">
            <div class="card-head"><h3>Budget position — <?= e($line['line_code']) ?></h3></div>
            <div class="card-body">
                <dl class="kv cols-3">
                    <div><dt>Allocated</dt><dd><?= e(money($line['allocated_amount'])) ?></dd></div>
                    <div><dt>Committed (incl. this request)</dt><dd><?= e(money($line['committed'])) ?></dd></div>
                    <div><dt>Available</dt><dd><?= e(money($line['available'])) ?></dd></div>
                </dl>
            </div>
        </div>
        <?php endif; ?>

        <?php foreach (glob(__DIR__ . '/panels/*.php') ?: [] as $panel) { include $panel; } ?>
    </div>

    <div class="card">
        <div class="card-head"><h3>Approval history</h3></div>
        <div class="card-body"><?= Approvals::timeline($history, $req['submitted_at'] ? ['Submitted by ' . $req['requester'], $req['submitted_at']] : null) ?></div>
    </div>
</div>
<?php
render_footer();
