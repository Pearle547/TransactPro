<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

$user = Auth::require();

$q         = (string) input('q', '');
$status    = (string) input('status', '');
$projectId = (int) input('project', 0);
$statuses  = ['Draft', 'Pending_Manager', 'Pending_Finance', 'Pending_Director', 'Approved', 'Rejected', 'Revision_Requested', 'Paid', 'Accountability_Submitted', 'Closed'];

$where  = ['1 = 1'];
$params = [];
if ($user['role'] === 'Staff') {
    $where[]  = 'fr.user_id = ?';
    $params[] = $user['user_id'];
}
if ($q !== '') {
    $where[]  = '(fr.request_code LIKE ? OR fr.purpose LIKE ?)';
    $params[] = $params[] = "%$q%";
}
if (in_array($status, $statuses, true)) {
    $where[]  = 'fr.status = ?';
    $params[] = $status;
}
if ($projectId > 0) {
    $where[]  = 'fr.project_id = ?';
    $params[] = $projectId;
}
$whereSql = implode(' AND ', $where);

$page = paginate((int) DB::val("SELECT COUNT(*) FROM financial_requests fr WHERE $whereSql", $params), 15);
$rows = DB::all(
    "SELECT fr.*, p.project_code, bl.line_code, u.full_name AS requester
       FROM financial_requests fr
       JOIN projects p ON p.project_id = fr.project_id
       JOIN budget_lines bl ON bl.budget_line_id = fr.budget_line_id
       JOIN users u ON u.user_id = fr.user_id
      WHERE $whereSql ORDER BY fr.request_id DESC LIMIT {$page['perPage']} OFFSET {$page['offset']}",
    $params
);
$projects = DB::all('SELECT project_id, project_code FROM projects ORDER BY project_code');

render_header('Fund requests', 'requests', [
    'subtitle' => $user['role'] === 'Staff' ? 'Requests you have raised' : 'All fund requests',
    'actions'  => $user['role'] === 'Staff' ? '<a class="btn btn-primary" href="' . e(url('modules/requests/form.php')) . '">+ New request</a>' : '',
]);
?>
<div class="card">
    <form class="filters" method="get">
        <div class="field grow"><label for="q">Search</label><input class="input" id="q" name="q" value="<?= e($q) ?>" placeholder="Request code or purpose"></div>
        <div class="field"><label for="project">Project</label>
            <select class="input" id="project" name="project" data-autosubmit>
                <option value="">All projects</option>
                <?php foreach ($projects as $p): ?><option value="<?= (int) $p['project_id'] ?>"<?= selected($projectId === (int) $p['project_id']) ?>><?= e($p['project_code']) ?></option><?php endforeach; ?>
            </select></div>
        <div class="field"><label for="status">Status</label>
            <select class="input" id="status" name="status" data-autosubmit>
                <option value="">All statuses</option>
                <?php foreach ($statuses as $s): ?><option value="<?= $s ?>"<?= selected($status === $s) ?>><?= e(status_label($s)) ?></option><?php endforeach; ?>
            </select></div>
        <button class="btn" type="submit">Filter</button>
        <a class="btn" href="index.php">Reset</a>
    </form>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Code</th><?php if ($user['role'] !== 'Staff'): ?><th>Requester</th><?php endif; ?><th>Project / line</th><th>Purpose</th><th class="num">Amount</th><th>Needed by</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="code"><?= e($r['request_code']) ?></td>
                    <?php if ($user['role'] !== 'Staff'): ?><td><?= e($r['requester']) ?></td><?php endif; ?>
                    <td><?= e($r['project_code']) ?> · <?= e($r['line_code']) ?></td>
                    <td><?= e(mb_strimwidth($r['purpose'], 0, 60, '…')) ?></td>
                    <td class="num"><?= e(money($r['amount_requested'])) ?></td>
                    <td class="nowrap"><?= e(fdate($r['required_date'])) ?></td>
                    <td><?= badge($r['status']) ?></td>
                    <td class="text-right"><a class="btn btn-sm" href="view.php?id=<?= (int) $r['request_id'] ?>">Open</a></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?><tr><td colspan="8" class="table-empty">No fund requests found.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
    <?= pager($page) ?>
</div>
<?php
render_footer();
