<?php
/** @var array $req @var array $user @var int $id */
if (!RequestWorkflow::canDecide($req, $user)) {
    return;
}
$highValue = RequestWorkflow::needsDirector($req['amount_requested']);
?>
<div class="card">
    <div class="card-head"><h3>Your decision — <?= e($user['role']) ?> review</h3></div>
    <div class="card-body">
        <?php if ($user['role'] === 'Finance'): ?>
            <div class="panel-note">
                <?= $highValue
                    ? 'This request is ' . e(money(Settings::directorThreshold())) . ' or more. If you approve, it goes to the Director for final approval.'
                    : 'This request is below ' . e(money(Settings::directorThreshold())) . '. Your approval is final.' ?>
            </div>
        <?php endif; ?>
        <form method="post" action="action.php" data-once>
            <?= csrf_field() ?>
            <input type="hidden" name="request_id" value="<?= $id ?>">
            <div class="field">
                <label for="comments">Comments</label>
                <textarea class="input" id="comments" name="comments" placeholder="Required when rejecting or requesting a revision"></textarea>
            </div>
            <div class="form-actions">
                <button class="btn btn-danger" type="submit" name="action" value="Rejected" data-confirm="Reject this request?">Reject</button>
                <button class="btn btn-warning" type="submit" name="action" value="Revision_Requested">Request revision</button>
                <button class="btn btn-success" type="submit" name="action" value="Approved">Approve</button>
            </div>
        </form>
    </div>
</div>
