<?php
/** @var array $req @var array $user @var int $id */
if (!RequestWorkflow::isEditable($req, $user)) {
    return;
}
?>
<div class="card">
    <div class="card-head"><h3>Ready to submit?</h3></div>
    <div class="card-body">
        <?php if ($req['status'] === 'Revision_Requested'): ?>
            <p>This request was returned to you. Review the comments in the history, edit it if needed, then submit it again.</p>
        <?php else: ?>
            <p>Submitting reserves <?= e(money($req['amount_requested'])) ?> on the budget line and sends the request to the Manager.</p>
        <?php endif; ?>
        <form method="post" action="action.php" class="btn-row" data-once>
            <?= csrf_field() ?>
            <input type="hidden" name="request_id" value="<?= $id ?>">
            <button class="btn btn-primary" type="submit" name="action" value="submit">Submit for approval</button>
            <?php if ($req['status'] === 'Draft'): ?>
                <button class="btn btn-danger" type="submit" name="action" value="delete" data-confirm="Delete this draft permanently?">Delete draft</button>
            <?php endif; ?>
        </form>
    </div>
</div>
