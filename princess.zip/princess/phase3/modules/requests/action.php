<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

Auth::require();
if (!is_post()) {
    redirect('modules/requests/index.php');
}

$requestId = (int) ($_POST['request_id'] ?? 0);
$action    = (string) ($_POST['action'] ?? '');

try {
    switch ($action) {
        case 'submit':
            RequestWorkflow::submit($requestId);
            flash('success', 'Request submitted for approval.');
            break;
        case 'delete':
            RequestWorkflow::delete($requestId);
            flash('success', 'Draft deleted.');
            redirect('modules/requests/index.php');
        case 'Approved':
        case 'Rejected':
        case 'Revision_Requested':
            RequestWorkflow::decide($requestId, $action, (string) ($_POST['comments'] ?? ''));
            flash('success', 'Your decision has been recorded.');
            break;
        default:
            throw new DomainException('Unknown action.');
    }
} catch (DomainException $e) {
    flash('error', $e->getMessage());
}
redirect('modules/requests/view.php?id=' . $requestId);
