<?php
/** @var array $user */
$status = match ($user['role']) {
    'Manager'  => ['Pending_Manager'],
    'Finance'  => ['Pending_Finance'],
    'Director' => ['Pending_Director'],
    'Admin'    => ['Pending_Manager', 'Pending_Finance', 'Pending_Director'],
    default    => [],
};
if (!$status) {
    return;
}
$marks = implode(',', array_fill(0, count($status), '?'));
$rows  = DB::all(
    "SELECT fr.request_id, fr.request_code, fr.amount_requested, fr.required_date, fr.status, fr.submitted_at, p.project_code, u.full_name AS requester
       FROM financial_requests fr JOIN projects p ON p.project_id = fr.project_id JOIN users u ON u.user_id = fr.user_id
      WHERE fr.status IN ($marks) ORDER BY fr.submitted_at",
    $status
);
if (!$rows) {
    return;
}
?>
<div class="card">
    <div class="card-head"><h3>Fund requests (<?= count($rows) ?>)</h3></div>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Code</th><th>Requester</th><th>Project</th><th class="num">Amount</th><th>Needed by</th><th>Waiting</th><th>Stage</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="code"><?= e($r['request_code']) ?></td>
                    <td><?= e($r['requester']) ?></td>
                    <td><?= e($r['project_code']) ?></td>
                    <td class="num"><?= e(money($r['amount_requested'])) ?><?= RequestWorkflow::needsDirector($r['amount_requested']) ? ' <span class="badge badge-info" title="Needs Director approval">High value</span>' : '' ?></td>
                    <td class="nowrap"><?= e(fdate($r['required_date'])) ?></td>
                    <td class="nowrap"><?= e(time_ago($r['submitted_at'])) ?></td>
                    <td><?= badge($r['status']) ?></td>
                    <td class="text-right"><a class="btn btn-sm btn-primary" href="<?= e(url('modules/requests/view.php?id=' . (int) $r['request_id'])) ?>"><?= $user['role'] === 'Admin' ? 'View' : 'Review' ?></a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
