<?php
/** @var array $user @var array $project @var int $id */
$sql    = 'SELECT fr.request_id, fr.request_code, fr.amount_requested, fr.status, u.full_name FROM financial_requests fr JOIN users u ON u.user_id = fr.user_id WHERE fr.project_id = ?';
$params = [$id];
if ($user['role'] === 'Staff') {
    $sql     .= ' AND fr.user_id = ?';
    $params[] = $user['user_id'];
}
$rows = DB::all($sql . ' ORDER BY fr.request_id DESC LIMIT 8', $params);
?>
<div class="card">
    <div class="card-head"><h3>Recent fund requests</h3><a class="btn btn-sm" href="<?= e(url('modules/requests/index.php?project=' . $id)) ?>">View all</a></div>
    <div class="card-body flush table-wrap">
        <table class="table">
            <thead><tr><th>Code</th><th>Requester</th><th class="num">Amount</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="code"><a href="<?= e(url('modules/requests/view.php?id=' . (int) $r['request_id'])) ?>"><?= e($r['request_code']) ?></a></td>
                    <td><?= e($r['full_name']) ?></td>
                    <td class="num"><?= e(money($r['amount_requested'])) ?></td>
                    <td><?= badge($r['status']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?><tr><td colspan="4" class="table-empty">No requests for this project yet.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
