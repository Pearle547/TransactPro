# TransactPro — Phase 3: Fund Requests & Threshold Approvals

Builds on Phases 1–2. Login, users, projects, budgets and financial plans all still work.

## What is new in this phase
| Area | Features |
| :--- | :--- |
| Fund requests | Staff request money against a project **budget line**, optionally linked to an approved financial plan. Save drafts, edit, submit, delete drafts |
| Live budget control | The form shows allocated / available / remaining-after-request while you type. On submission the server re-checks under a database lock, then **reserves** the amount. Rejected or returned requests release it automatically |
| Plan ceiling | Requests linked to a plan can never total more than the plan's approved amount |
| **Approval routing** | **Every request goes Manager → Finance first.** If the amount is **below UGX 10,000,000**, Finance's approval is final. If it is **UGX 10,000,000 or more**, it continues to the **Director** |
| Decisions | Approve, reject, or request a revision (comments mandatory). Nobody can approve their own request. Returned requests restart the chain when resubmitted |
| Approvals queue | Each approver sees only what is waiting at their stage, with high-value requests flagged |
| Notifications | Requester and next approver are alerted at every step |
| Dashboard | Request statistics per role, recent requests, awaiting-your-decision counter |

## Install (XAMPP)
1. Copy this folder to `C:\xampp\htdocs\transactpro\phase3\`.
2. Start **Apache** and **MySQL**.
3. phpMyAdmin → **Import** → `database/schema.sql` (creates `transactpro_phase3`).
4. Adjust `app/config.php` if your MySQL root has a password.
5. Open `http://localhost/transactpro/phase3/`.

Demo accounts (password `password123`): `admin@`, `staff@`, `staff2@`, `manager@`, `finance@`, `director@` + `transactpro.test`.

## The approval rule
```
Staff ──► Manager ──► Finance ──┬── amount < 10,000,000  ──► APPROVED
                                └── amount ≥ 10,000,000  ──► Director ──► APPROVED
```
The threshold is stored in the `settings` table (`director_threshold`). To change it in this phase:
```sql
UPDATE settings SET setting_value = '15000000' WHERE setting_key = 'director_threshold';
```
(Phase 5 adds a Settings screen for administrators.)

> **Boundary:** exactly UGX 10,000,000 is treated as "10 million *or more*" and therefore goes to the Director.

## Try it
1. **staff** → *Fund requests* → *New request*: project WASH-001, line B-WASH-01, UGX 5,000,000 → Submit.
2. **manager** → Approvals → Approve. **finance** → Approve → status becomes **Approved** (no Director needed).
3. Repeat with UGX 12,000,000: after Finance it moves to **Pending Director**; sign in as **director** to finish it.
4. Watch *Budget lines* (as finance) — available funds fall on submission and rise again if a request is rejected.

## Design notes
* `RequestWorkflow` is the only code that changes a request's status; every transition checks the user's role, the current stage, and that the approver is not the requester — all inside one transaction with the row locked.
* Budget availability is calculated from requests (`Budget` service) rather than stored, so it can never drift.
